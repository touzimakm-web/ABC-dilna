<?php
declare(strict_types=1);
require __DIR__.'/app/bootstrap.php';require __DIR__.'/app/layout.php';$u=login_required();require_role($u,['owner']);page_header('Provoz servisu',$u,'settings');
?><h1>Nastavení servisu</h1><p>Platí pouze pro tento autoservis. U pneuservisu rozlišujte cenu za kolo/kus a za celou sadu podle jednotky ceníku. Bez nastavené varianty se cena nevymýšlí.</p><p><a class="button" href="catalog.php">Ceník a propojení karet</a></p><div id="a-settings-notice" class="notice" hidden role="status"></div><div id="a-settings-app">Načítám…</div><script>window.ABC_MECH=<?=json_encode(auth_payload($u),JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT)?>;</script><script src="assets/workshop.js?v=350" defer></script><?php page_footer();
