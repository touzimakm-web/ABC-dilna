# ABC Dílna – SaaS 3.1 + pracovní karta M01 (vývoj M02)

**POUZE VÝVOJOVÁ VERZE. NENAHRAZOVAT stávající web na WEDOSu.**

## Co jsme spojili

- Základem je vámi dodaný SaaS 3.1.0, **nikoliv** starý jednofiremní ZIP 2.1.0.
- Zachovali jsme SaaS správu více servisů, oddělené databáze, přihlášení, zákazníky/vozidla, ceník, faktury, hotovost i další finanční logiku.
- Do jeho **skutečné** pracovní karty `mechanic_work.php` a `assets/mechanic_work.js` jsme přenesli styl objednávkových řádků M01: **Práce** a **Díly**, přímá úprava názvu, množství, jednotky a prodejní ceny a smazání s potvrzením.
- Jednotky: `ks`, `l`, `hod`, `úkon`, `sada`, `bal`, `kg`, `m`. Výchozí práce ručně: `hod`; katalogová práce: `úkon`.
- **Požadavky zákazníka** (červená/servisní kategorie při příjmu) zůstávají oddělené od skutečně účtovaných prací; nepřidávají se automaticky do faktury.
- Cena může zůstat prázdná. Nákupní cena se v mechanikovi nezobrazuje ani nepřepisuje při úpravě řádku.
- Již fakturované nebo zaplacené položky nelze prostřednictvím pracovní karty změnit. Změny se zapisují do historie cen a událostí. Opakování stejného API požadavku je chráněno klíčem.
- Na nových fakturách se jednotka uchovává v neměnném snímku; starší doklady s chybějícím polem `unit` jsou stále tisknutelné.

## Databáze – zásadní

**Každý autoservis má VLASTNÍ databázi.** Změna `unit` se týká jeho tabulek `items` a `abc_quick_tasks`. Neměňte platformní databázi.

**Nový servis na prázdné DB:** používá nové `sql/schema.sql` s jednotkami. **Známa samostatná kopie SaaS 3.0 připojovaná přes platformu:** `app/platform_actions.php` spustí idempotentní M02 migraci po ověřené v3.0 migraci.

**Stávající 3.1.0 testovací servis:** před použitím nového PHP/JS proveďte zálohu **testovací** DB a použijte jednorázový `sql/upgrade_m02_mechanik_radky.sql`. SQL použije `ALTER TABLE`, proto ho nespouštějte opakovaně. Alternativní vývojový postup `abc_migrate_m02()` v `app/migrations.php` kontroluje existenci sloupců a je opakovatelný, ale není vystaven veřejnou migrační stránkou. **NEMIGROVAT produkci bez validační zkoušky.**

Původní práce bez údaje jednotky se nastaví na **`úkon`**, nikoliv automaticky na hodinovou sazbu. Jejich peněžní hodnoty se nemění.

## Jak otestovat

1. Otevřete samostatný soubor `ABC_Dilna_SaaS_M02_klikaci_pracovni_karta.html` mimo ZIP. Je to offline náhled se **stejným upraveným JS/CSS**, ale s ukázkovými odpověďmi místo PHP a MariaDB.
2. Změňte množství a jednotkovou cenu oleje, přidejte díl, smažte díl; porovnejte součet.
3. Na izolované kopii s MariaDB ověřte: tenant A/B oddělení, vytvoření zakázky, nový díl bez ceny, desetinné litry, změnu množství po nacenění, jednotku na faktuře, zachování `unit_cost`, opakované požadavky, odmítnutí změny po fakturaci či platbě.
4. Před nasazením zopakujte původní SaaS 3.1 integrační sady a přidejte cílené M02 scénáře. Přiložené původní výsledky 3.1 se **nevztahují** automaticky na tuto úpravu.

## Omezení dosavadního ověření

- Kontrola syntaxe PHP a JavaScriptu prošla.
- Chromium/Playwright na zkušebních datech prošlo scénářem úpravy množství/ceny, přidání a smazání položky bez JS chyby.
- **Nebyl** proveden nový integrační běh PHP+MariaDB, WEDOS ani test na skutečném Samsungu. Nejde o schválené ostré vydání ani hotovou hlasovou AI.

## Příští vývoj

Po schválení mechanikovy karty dokončit jednoduchý příjem, potom AI rozpoznání fotografií a hlasové zadávání do stejných řádků; Kancelář bude sdílet zakázky a doplňovat identifikaci a nákupní cenu dílů. Veškerá konfigurace každého servisu zůstane variabilní.
