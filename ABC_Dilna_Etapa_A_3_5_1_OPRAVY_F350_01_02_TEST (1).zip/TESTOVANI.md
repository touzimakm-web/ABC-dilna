Aktuální vydání: **3.3.1 – opravy F01–F06 v Etapě A**.

Postup: `CTI_ME_331.txt`; rozsah: `ZMENY_331.txt`; skutečné zkoušky: `TESTOVANI_331.txt`; migrace: `sql/MIGRACE_331.txt`. Kód i testy lze porovnat přes `DIFF_330_331.patch`. Texty níže dokumentují předchozí milníky. Na WEDOS nebylo nasazeno.

Aktuální vydání: **Etapa A / 3.3.0**, pokračování SaaS 3.1 + M02.

Začněte v `CTI_ME_ETAPA_A.txt`. Rozsah je v `ZMENY_ETAPA_A.txt`, skutečné výsledky v `TESTOVANI_ETAPA_A.txt`, přejímka v `SCENARE_ETAPA_A.txt` a migrace v `sql/MIGRACE_ETAPA_A.txt`. Starší text níže dokumentuje historii základu. Na WEDOS nebylo nasazeno.

# Testování aktuálního milníku A1/A2

Aktuální skutečné běhy a omezení jsou v [TESTOVANI_A12.txt](TESTOVANI_A12.txt). Níže zůstává historický protokol výchozí verze 3.1; jeho počty nejsou výsledky této nové úpravy.

# Ověření ABC Dílny SaaS 3.1.0

Ověřeno 16. 11. 2026 na skutečném PHP 8.4.24, MariaDB 11.8.6 a Chromium 156 (Playwright 1.62). Nejde o samotnou kontrolu syntaxe: aplikace ukládala do dočasných SQL databází přes skutečné HTTP požadavky a prohlížeč prošel uživatelské obrazovky. Databáze byly po zkoušce odstraněné, bez připojení k živému WEDOSu.

| Sada | Výsledek | Protokol |
| --- | --- | --- |
| Pracovní postup mechanika a recepce v běžné cestě | 94 kontrol prošlo | tests/evidence/results.json |
| Stejný postup s veřejným /nova/ a interním SCRIPT_NAME přepisem WEDOS | 94 kontrol prošlo | tests/evidence/results-wedos.json |
| Více servisů, předplatné a skutečné browserové obrazovky | 82 kontrol prošlo | tests/evidence/saas-results.json |
| Stejný SaaS postup s přepisem WEDOS | 82 kontrol prošlo | tests/evidence/saas-results-wedos.json |
| Odhady, změny oprávnění a odvolání relací | 11 kontrol prošlo | tests/evidence/security-estimates.json |

Obě varianty SaaS byly spuštěné na zvláštní dočasné databázi platformy a samostatných klientských databázích. Čísla kontrol se vztahují k uvedeným sadám; varianty obsahují opakované scénáře, nejde o tolik různých vlastností produktu. Přiložené textové final-run protokoly obsahují skutečný výstup posledních běhů. PHP a dodaný JavaScript prošly také kontrolou syntaxe.

## Více servisů a peníze

Založili jsme platformu, jejího samostatného provozovatele, tarif a dva servisy s různými DB a SQL účty. Majitelé použili stejný přihlašovací e-mail, zákaznické auto stejnou SPZ a zakázka/faktura/položka stejné číselné ID v obou databázích. Každý servis viděl vlastní zákazníky, ceny, součty a dodavatele na faktuře. Běžný SQL účet servisu A byl při pokusu o SELECT z DB B odmítnutý také samotným MariaDB serverem.

Podstrčené tenant_id v obchodním POST nezvolilo jinou databázi, změna kódu servisu přes API byla odmítnutá a přihlášený uživatel nemohl potichu přepnout jinam. Provozovatel nepoužil svou relaci jako klientského majitele, klientský majitel se nestal provozovatelem, mechanik nemohl otevřít nastavení firmy, předplatné nebo celkový export. Browserový koncept rozepsaný v A se v B neobjevil a API požadavek staré záložky s jiným kontextem server odmítl. Uložené DB heslo nebylo v registru čitelné; kryptografické ověření odmítlo použití šifrovaného připojení s jinou identitou servisu.

Interní předpis předplatného neprodloužil přístup a nevytvořil skutečnou platbu. Částečná potvrzená úhrada také neprodloužila celý měsíc, doplacení ano. Opakování stejného potvrzení nevytvořilo další peníze a přeplatek byl odmítnutý. Evidence předplatného servisu A se neobjevila v B ani v zákaznických platbách dílny. Výslovné pozastavení a expirace blokovaly obchodní změny i po novém přihlášení, ale zachovaly čtení, tisk a export; druhý servis pracoval dál.

Majitelský JSON export obsahoval vlastní obchodní data bez druhého klienta a bez přihlašovacích hashů či DB přístupů. Připojení známé samostatné kopie 3.0 zachovalo původní zákaznické ID a účet majitele. Již přiřazená databáze byla při pokusu o přiřazení jinému klientovi odmítnutá. Veřejná žádost o přístup se skutečně uložila do evidence provozovatele.

## Doklady a hlavní pracovní tok

U neplátce se vytiskl neplátcovský text. U plátce vznikla při konečné ceně 1210 Kč faktura se základem 1000 Kč a DPH 210 Kč, DIČ a datem plnění. Změna firemních údajů po vystavení původní fakturu nepřepsala. U plátce nebylo možné vydávat samotné potvrzení platby za fakturu: bez vystavené faktury se platba odmítla; po vystavení bylo možné zaznamenat část hotově a vytisknout správné potvrzení. PDF plátce skutečně vytvořil Chromium a jeho obsah byl přečtený. Podpora se omezuje na popsané tuzemské 21% plnění, jiné režimy nebyly ověřovány ani implementovány.

Základní browserová sada prošla mobilní příjem pouze SPZ + tři požadavky bez termínu/ceny, autocomplete SPZ i jména, návrat k rozpracované kartě, skutečnou nabídku ceníku, ruční práci a díl bez skladu, desetinné množství, pozdější cenu, odškrtnutí prací, slevu, dokončení, neuhrazenou fakturu, částečnou hotovost/kartu a majitelem potvrzený převod. Mechanik předal pouze hotovost, majitel potvrdil skutečnou částku; příjem se nezapočítal znovu. Replay skutečného částečného platebního požadavku ani souběžné konečné úhrady neumožnily zduplikovat nebo přeplatit peníze.

Kalendář propojil volitelnou rezervaci se stejnou zakázkou, bez termínu se neobjevila falešná rezervace. Sady prověřily i neznámou cenu na zakázkovém listu, přetrvání přihlášení po obnově, vlastní přístup jiného mechanika, oddělení odhadu od účtování, okamžitý účinek oprávnění, deaktivace a resetu hesla. Přidávací migrace původního schématu zachovala ID a hodnoty zákazníka/zakázky/platby a opakované spuštění nic neduplikovalo.

Mobilní Chromium s dotykem změřilo hlavní tok na 320/360/412 px bez vodorovného přesahu. Nová SaaS sada použila současně mobilního mechanika 360 px, desktopového majitele 1440 px a třetí nezávislý kontext provozovatele. Nebyly zachycené nezpracované JS chyby ani PHP warnings/fatal errors.

## Snímky a spuštění

- `tests/evidence/saas/` a `saas-wedos/`: skutečné snímky mobilního mechanika, klientské recepce, správy platformy a PDF faktury plátce.
- `tests/evidence/` a `wedos/`: původní hlavní pracovní tok, faktura neplátce, zakázkový list a potvrzení platby.
- Všechna jména, ceny a doklady v těchto důkazech jsou testovací. Čistá instalace jimi aplikaci nenaplní.

Pro místní opakování je nutné mít PHP s rozšířeními, binárky MariaDB (`mariadb-install-db`, `mariadbd`, `mariadb`), Python a pro browser část Playwright + Chromium. Testy nepoužívají app/config.php; vytvářejí vlastní dočasný server a DB a vyžadují oprávnění spouštět lokální procesy/sokety. Parametry jsou `ABC_TEST_PHP`, `ABC_TEST_PHP_INI`, `ABC_TEST_MARIADB_BASE`, `ABC_TEST_BROWSER=1` a pro přepis `ABC_TEST_WEDOS_REWRITE=1`. Chromium cesta v testech je `/usr/bin/chromium`.

Příkazy: `python tests/integration.py`, `python tests/saas_integration.py`, `python tests/security_and_estimates.py`. Nespouštějte je na produkční databázi; fixture Runtime vytváří vlastní izolované DB. Přijetí na hostingu proveďte podle `docs/PREJIMACI_ZKOUSKA_SAAS.md`.

## Co ověřené není

Přímý provoz na skutečném WEDOSu, jeho Apache/.htaccess/session.save_path a limity tarifu, fyzický Samsung a tiskárna, rozsáhlý produkční export/import vašich současných zákaznických dat ani zátěž stovek servisů. Samostatný runtime PHP 8.1 nebo MySQL nebyl použit; běhy byly PHP 8.4 a MariaDB. Testovaný přepis je místní model veřejné cesty WEDOS, nikoli vzdálené nasazení.

Obnovu ostrých záloh, automatické platby kartou, bankovní párování, automatické zřizování DB a e-mailů, integrace EET/iDoklad/registru vozidel/dodavatelů tyto testy nepotvrzují. Tyto služby nejsou připojené. Způsob platby „karta“ u zákaznické zakázky je evidence příjmu z vlastního terminálu, nikoli vestavěný platební terminál nebo gateway.
