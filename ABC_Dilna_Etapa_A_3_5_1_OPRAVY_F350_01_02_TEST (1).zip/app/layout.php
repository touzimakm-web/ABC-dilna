<?php
declare(strict_types=1);
function page_header(string $title,array $u,string $active=''): void {
    global $config;
    $ui=basename($_SERVER['SCRIPT_FILENAME']??'')==='upgrade.php'?a_defaults():a_settings();
    ?><!doctype html><html lang="cs"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><meta name="abc-scope" content="<?=e(db_scope())?>"><title><?=e($title)?> · ABC Dílna</title><link rel="stylesheet" href="assets/mechanic.css?v=350"><link rel="stylesheet" href="assets/phase_a.css?v=350"></head><body data-theme="<?=e($ui['theme'])?>" class="<?= $u['role']==='owner'?'owner-view':'mechanic-view' ?>">
    <header class="header"><div class="header-inner"><a class="brand" href="<?=$u['role']==='owner'?'office.php':'mechanic.php'?>">ABC <span>DÍLNA</span><small><?=e($config['company_name'])?> · servisní systém</small></a><div class="header-links"><a href="mechanic.php">Dílna</a><?php if($u['role']==='owner'):?><a href="office.php">Recepce</a><?php endif;?><?php if(d_may_view($u)||abc_perm($u,'print_documents')):?><a href="documents.php">Dokumenty</a><?php endif;?><?php if(abc_perm($u,'manage_catalog')):?><a href="catalog.php">Ceník</a><?php endif;?><span><?=e($u['name'])?></span><form method="post" action="logout.php"><input type="hidden" name="csrf" value="<?=e(csrf())?>"><button class="text-button">Odhlásit</button></form></div></div></header>
    <?php if($u['role']==='owner'):?><nav class="office-nav" aria-label="Hlavní navigace"><?php foreach(['overview'=>'Přehled','jobs'=>'Zakázky','calendar'=>'Kalendář','customers'=>'Zákazníci a auta','catalog'=>'Ceník','documents'=>'Dokumenty','payments'=>'Platby a faktury','team'=>'Tým','settings'=>'Nastavení'] as $key=>$label):?><a class="<?=$active===$key?'active':''?>" href="office.php?view=<?=e($key)?>"><?=e($label)?></a><?php endforeach;?></nav><?php endif;?><main class="main-wrap">
    <div class="a-accessibility"><label>Písmo <select id="a-font" aria-label="Velikost písma"><option value="normal">Aa</option><option value="large">Aa velké</option><option value="extra">Aa extra velké</option></select></label><label>Vzhled <select id="a-theme" aria-label="Vzhled"><option value="workshop">Podle servisu</option><option value="navy">Modrý</option><option value="light">Světlý</option></select></label></div><script>window.ABC_PREF_KEY=<?=json_encode(db_scope().':'.$u['id'])?>;</script><script src="assets/preferences.js?v=350"></script>
    <?php if(tenant_readonly()):?><div class="notice">Přístup pro změny je pozastavený. Data můžeš prohlížet a tisknout. <?php if($u['role']==='owner'):?><a href="subscription.php">Předplatné a export dat</a><?php endif;?></div><?php endif;?>
    <?php if(isset($_SESSION['flash'])):?><div class="notice"><?=e($_SESSION['flash'])?></div><?php unset($_SESSION['flash']);endif;
}
function page_footer(): void {
 $script=basename($_SERVER['SCRIPT_FILENAME']??'');
 if(in_array($script,['mechanic.php','mechanic_work.php','mechanic_estimate.php'],true)){
  $active=$script==='mechanic_work.php'?'jobs':($_GET['view']??'home');
  echo '<nav class="a-bottom" aria-label="Práce mechanika">';foreach(['home'=>'Domů','jobs'=>'Zakázky','calendar'=>'Kalendář','cars'=>'Auta'] as $key=>$label)echo '<a '.($active===$key?'aria-current="page"':'').' href="mechanic.php'.($key==='home'?'':'?view='.$key).'">'.$label.'</a>';echo '</nav>';
 }
 echo '</main><footer class="site-footer">ABC Dílna · Etapa A · 3.5.1 · konečné ceny v Kč</footer></body></html>';
}
