<?php
declare(strict_types=1);
const OPS_SCHEMA='3.4.0-a-v2';
function ops_migrate(PDO $db): void {
    $add=['jobs'=>['location_state'=>"VARCHAR(20) NOT NULL DEFAULT 'unknown'",'received_at'=>'DATETIME NULL','preparation_assigned_to'=>'INT NULL'],
      'office_appointments'=>['work_mode'=>"VARCHAR(12) NOT NULL DEFAULT 'inside'"],
      'abc_quick_tasks'=>['procurement_stage'=>"VARCHAR(20) NOT NULL DEFAULT 'unknown'",'ordered_quantity'=>'DECIMAL(10,3) NULL','expected_on'=>'DATE NULL','supplier_name'=>"VARCHAR(160) NOT NULL DEFAULT ''",'order_reference'=>"VARCHAR(120) NOT NULL DEFAULT ''",'supplier_url'=>"VARCHAR(500) NOT NULL DEFAULT ''",'procurement_note'=>"VARCHAR(1000) NOT NULL DEFAULT ''",'required_for_start'=>'TINYINT NOT NULL DEFAULT 1']];
    foreach($add as $table=>$cols){$found=array_column($db->query('SHOW COLUMNS FROM `'.$table.'`')->fetchAll(),'Field');foreach($cols as $col=>$sql)if(!in_array($col,$found,true))$db->exec('ALTER TABLE `'.$table.'` ADD COLUMN `'.$col.'` '.$sql);}
    $db->exec("CREATE TABLE IF NOT EXISTS abc_job_presence(id BIGINT AUTO_INCREMENT PRIMARY KEY,job_id INT NOT NULL,vehicle_id INT NULL,mode VARCHAR(20) NOT NULL,resource_id INT NULL,mechanic_id INT NULL,started_at DATETIME NOT NULL,expected_end DATETIME NULL,ended_at DATETIME NULL,opened_by INT NOT NULL,closed_by INT NULL,reason VARCHAR(300) NOT NULL DEFAULT '',active_job_id INT AS (CASE WHEN ended_at IS NULL THEN job_id ELSE NULL END) STORED,active_vehicle_id INT AS (CASE WHEN ended_at IS NULL THEN vehicle_id ELSE NULL END) STORED,UNIQUE KEY one_active_job(active_job_id),UNIQUE KEY one_active_vehicle(active_vehicle_id),INDEX presence_resource(resource_id,ended_at),FOREIGN KEY(job_id) REFERENCES jobs(id),FOREIGN KEY(vehicle_id) REFERENCES crm_vehicles(id),FOREIGN KEY(resource_id) REFERENCES abc_resources(id),FOREIGN KEY(opened_by) REFERENCES users(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $db->exec("CREATE TABLE IF NOT EXISTS abc_part_receipts(id BIGINT AUTO_INCREMENT PRIMARY KEY,task_id INT NOT NULL,quantity DECIMAL(10,3) NOT NULL,unit VARCHAR(12) NOT NULL,source VARCHAR(20) NOT NULL,received_at DATETIME NOT NULL,received_by INT NOT NULL,note VARCHAR(500) NOT NULL DEFAULT '',INDEX receipt_task(task_id),FOREIGN KEY(task_id) REFERENCES abc_quick_tasks(id),FOREIGN KEY(received_by) REFERENCES users(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $db->beginTransaction();try{
        if(!$db->query("SELECT version FROM schema_meta WHERE version='3.4.0-permissions'")->fetchColumn()){
            foreach($db->query('SELECT id,permissions FROM users FOR UPDATE')->fetchAll() as $row){$p=json_decode($row['permissions'],true)?:[];$old=$p;if(in_array('edit_jobs',$p,true)&&in_array('change_status',$p,true))$p[]='move_vehicles';if(in_array('edit_jobs',$p,true)&&in_array('edit_lines',$p,true))$p[]='prepare_jobs';$p=array_values(array_unique($p));if($p!==$old){$s=$db->prepare('UPDATE users SET permissions=? WHERE id=?');$s->execute([json_encode($p),$row['id']]);}}
            $db->exec("INSERT IGNORE INTO schema_meta(version) VALUES ('3.4.0-permissions')");
        }
        $db->exec("INSERT IGNORE INTO schema_meta(version) VALUES ('3.4.0-a-v2')");$db->commit();
    }catch(Throwable $e){if($db->inTransaction())$db->rollBack();throw $e;}
}
function ops_now(): string {return (string)query('SELECT NOW()')->fetchColumn();}
function ops_active(int $job): ?array {return query('SELECT p.*,r.name resource_name,r.kind resource_kind,u.name mechanic_name FROM abc_job_presence p LEFT JOIN abc_resources r ON r.id=p.resource_id LEFT JOIN users u ON u.id=p.mechanic_id WHERE p.job_id=? AND p.ended_at IS NULL',[$job])->fetch()?:null;}
function ops_car_key(int $job): string {static $keys=[];if(!isset($keys[$job])){$v=query('SELECT vehicle_id FROM crm_vehicle_jobs WHERE job_id=?',[$job])->fetchColumn();$keys[$job]=$v?'vehicle:'.$v:'job:'.$job;}return $keys[$job];}
function ops_booking_key(array $a): string {return !empty($a['job_id'])?ops_car_key((int)$a['job_id']):'appointment:'.$a['id'];}
/** Překryvy plánu a pobytu stejného auta sloučíme před počítáním kapacity. */
function ops_peak(array $intervals,string $start,string $end): int {
    $by=[];foreach($intervals as $i){$a=max($start,$i[1]);$b=min($end,$i[2]);if($a<$b)$by[$i[0]][]=[$a,$b];}
    $merged=[];foreach($by as $rows){usort($rows,fn($a,$b)=>$a[0]<=>$b[0]);$last=null;foreach($rows as $r){if($last&&$r[0]<=$last[1])$last[1]=max($last[1],$r[1]);else{if($last)$merged[]=$last;$last=$r;}}if($last)$merged[]=$last;}return a_interval_max($merged,$start,$end);
}
function ops_projection_end(array $p,string $now,bool $actual): string {return !$actual&&!empty($p['expected_end'])&&$p['expected_end']>$now?$p['expected_end']:'9999-12-31 23:59:59';}
function ops_capacity_intervals(string $start,string $end,int $excludeAppointment=0,?int $resource=null,bool $actual=false): array {
    $rows=query("SELECT a.* FROM office_appointments a WHERE a.id<>? AND a.status IN ('confirmed','requested') AND a.work_mode='inside' AND a.start_at<? AND COALESCE(a.end_at,'9999-12-31 23:59:59')>?",[$excludeAppointment,$end,$start])->fetchAll();$intervals=[];
    foreach($rows as $a){if($resource!==null){if((int)$a['resource_id']!==$resource)continue;$from=$a['resource_start'];$to=$a['resource_end'];if(!$from||!$to)continue;}else{$from=$a['start_at'];$to=a_calendar_end($from,$a['end_at']);}$intervals[]=[ops_booking_key($a),$from,$to];}
    $now=ops_now();foreach(query("SELECT * FROM abc_job_presence WHERE mode='inside' AND ended_at IS NULL")->fetchAll() as $p){if($resource!==null&&(int)$p['resource_id']!==$resource)continue;$intervals[]=[ops_car_key((int)$p['job_id']),$p['started_at'],ops_projection_end($p,$now,$actual)];}return $intervals;
}
function ops_resource(int $id): array {$r=query('SELECT * FROM abc_resources WHERE id=? AND active=1',[$id])->fetch();if(!$r)throw new OfficeRule('Pracoviště není aktivní.');return $r;}
function ops_calendar_check(PDO $db,string $start,?string $end,int $exclude,int $mechanic,?int $resource,?string $rs,?string $re,string $mode,int $job=0): void {
    if(!in_array($mode,['inside','outside'],true))throw new OfficeRule('Vyber opravu uvnitř nebo mimo dílnu.');
    $s=a_settings();$limit=a_calendar_end($start,$end);$weekday=(string)date('N',strtotime($start));$hours=$s['hours'][$weekday]??null;
    if($s['hours']){if(!$hours)throw new OfficeRule('V tento den má servis zavřeno.');$open=substr($start,0,10).' '.$hours[0].':00';$close=substr($start,0,10).' '.$hours[1].':00';if($start<$open||$start>=$close||($end&&$end>$close))throw new OfficeRule('Termín je mimo pracovní dobu.');}
    if(!$job&&$exclude)$job=(int)query('SELECT job_id FROM office_appointments WHERE id=?',[$exclude])->fetchColumn();
    $collision=query("SELECT id,job_id,end_at FROM office_appointments WHERE id<>? AND mechanic_id=? AND status IN ('confirmed','requested') AND start_at<? AND COALESCE(end_at,'9999-12-31 23:59:59')>?",[$exclude,$mechanic,$limit,$start])->fetchAll();
    foreach($collision as $a)if(!$job||(int)$a['job_id']!==$job)throw new OfficeRule(!$end||!$a['end_at']?'Kolize mechanika: chybí délka některého plánu.':'Mechanik už má v tomto čase plánovanou práci.');
    if($mode==='outside'){if($resource||$rs||$re)throw new OfficeRule('Oprava mimo dílnu nerezervuje vnitřní pracoviště.');return;}
    $key=$job?ops_car_key($job):'new-job';
    if($s['car_capacity']){$iv=ops_capacity_intervals($start,$limit,$exclude);$iv[]=[$key,$start,$limit];if(ops_peak($iv,$start,$limit)>(int)$s['car_capacity'])throw new OfficeRule('Kolize vnitřní kapacity. Některé auto může stále držet pracoviště bez potvrzeného uvolnění.');}
    if($resource){$r=ops_resource($resource);if(!$rs||!$re||!$end||$rs<$start||$re>$end||$rs>=$re)throw new OfficeRule('Pro hever zadej známý interval uvnitř plánu opravy.');$iv=ops_capacity_intervals($rs,$re,$exclude,$resource);$iv[]=[$key,$rs,$re];if(ops_peak($iv,$rs,$re)>(int)$r['capacity'])throw new OfficeRule('Pracoviště '.$r['name'].' je obsazené nebo má jinou rezervaci.');}
    elseif($rs||$re)throw new OfficeRule('Pro interval vyber pracoviště.');
}
function ops_expected_end(array $p,string $now): ?string {
    $v=post_str($p,'expected_end',19);if(!$v)return null;$v=str_replace('T',' ',$v);$d=DateTimeImmutable::createFromFormat('!Y-m-d H:i',$v);
    if(!$d||$d->format('Y-m-d H:i')!==$v||$d->format('Y-m-d H:i:s')<=$now)fail('Odhad uvolnění musí být platný budoucí čas.');return $d->format('Y-m-d H:i:s');
}
/** Nástup kontroluje skutečné držení nyní i pozdější potvrzené rezervace. */
function ops_check_start(array $j,?int $resource,?string $expected,string $now,string $mode): void {
    $mechanic=(int)($j['assigned_to']?:0);if(!$mechanic)fail('Nejdřív přiřaď mechanika.');
    $busy=query("SELECT id,job_id FROM office_appointments WHERE mechanic_id=? AND job_id<>? AND status IN ('confirmed','requested') AND start_at<=? AND COALESCE(end_at,'9999-12-31 23:59:59')>?",[$mechanic,$j['id'],$now,$now])->fetch();
    if($busy)fail('Mechanik má právě jinou výslovně naplánovanou práci.',409,['code'=>'mechanic_busy']);
    if($mode==='outside_work')return;
    if(!$resource)fail('Vyber skutečné dostupné pracoviště.');$r=ops_resource($resource);$end=$expected?:'9999-12-31 23:59:59';$key=ops_car_key((int)$j['id']);
    // Nyní nevěříme uplynutí žádného odhadu jiného fyzicky drženého místa.
    $actual=query("SELECT * FROM abc_job_presence WHERE mode='inside' AND ended_at IS NULL AND job_id<>?",[$j['id']])->fetchAll();$iv=[];$resourceIv=[];
    foreach($actual as $p){$i=[ops_car_key((int)$p['job_id']),$p['started_at'],'9999-12-31 23:59:59'];$iv[]=$i;if((int)$p['resource_id']===$resource)$resourceIv[]=$i;}
    $iv[]=[$key,$now,$end];$resourceIv[]=[$key,$now,$end];$cap=a_settings()['car_capacity'];
    if($cap&&ops_peak($iv,$now,$end)>(int)$cap)fail('Vnitřní kapacita je skutečně obsazená. Odstavení musí potvrdit pracovník.',409,['code'=>'inside_full']);
    if(ops_peak($resourceIv,$now,$end)>(int)$r['capacity'])fail('Pracoviště '.$r['name'].' je stále fyzicky obsazené.',409,['code'=>'resource_occupied']);
    $future=query("SELECT * FROM office_appointments WHERE job_id<>? AND work_mode='inside' AND status IN ('confirmed','requested') AND start_at<? AND COALESCE(end_at,'9999-12-31 23:59:59')>?",[$j['id'],$end,$now])->fetchAll();
    foreach($future as $a){$i=[ops_booking_key($a),$a['start_at'],a_calendar_end($a['start_at'],$a['end_at'])];$iv[]=$i;if((int)$a['resource_id']===$resource&&$a['resource_start']&&$a['resource_end'])$resourceIv[]=[ops_booking_key($a),$a['resource_start'],$a['resource_end']];}
    if(($cap&&ops_peak($iv,$now,$end)>(int)$cap)||ops_peak($resourceIv,$now,$end)>(int)$r['capacity'])fail('Nástup by zasáhl následující rezervaci. Zadej poctivý odhad, zvol jiné místo nebo nejprve ručně uprav plán.',409,['code'=>'following_booking_conflict']);
}
function ops_close_presence(array $p,array $u,string $now): void {query('UPDATE abc_job_presence SET ended_at=?,closed_by=? WHERE id=? AND ended_at IS NULL',[$now,$u['id'],$p['id']]);}
function ops_open_presence(array $j,array $u,string $mode,?int $resource,?string $expected,string $now,string $reason): array {
    $vehicle=query('SELECT vehicle_id FROM crm_vehicle_jobs WHERE job_id=?',[$j['id']])->fetchColumn();
    if($vehicle&&query('SELECT id FROM abc_job_presence WHERE vehicle_id=? AND ended_at IS NULL',[$vehicle])->fetch())fail('Toto vozidlo už má aktivní pobyt u jiné zakázky.',409);
    query('INSERT INTO abc_job_presence(job_id,vehicle_id,mode,resource_id,mechanic_id,started_at,expected_end,opened_by,reason) VALUES (?,?,?,?,?,?,?,?,?)',[$j['id'],$vehicle?:null,$mode,$resource,$j['assigned_to'],$now,$expected,$u['id'],$reason]);
    query('UPDATE jobs SET location_state=?,received_at=COALESCE(received_at,?) WHERE id=?',[$mode==='inside'?'inside':'outside_work',$now,$j['id']]);return ops_active((int)$j['id']);
}
function ops_transition(array $u,array $j,array $p,string $action): void {
    a_edit($u,$action==='wait_parts'?'change_status':'move_vehicles');$id=(int)$j['id'];$current=ops_active($id);$now=ops_now();$location=$j['location_state'];$before=$current;
    if($action==='wait_parts'){
        a_edit($u,'change_status');card_mutable($id,$j);$choice=post_str($p,'release_choice',20);
        if($current&&$current['mode']==='inside'){
            if(!in_array($choice,['keep','yard','move'],true))fail('Uvolnilo se pracoviště '.$current['resource_name'].'? Vyber výslovně, co se skutečně stalo.',409,['code'=>'release_decision_required','resource_name'=>$current['resource_name']]);
            if($choice==='yard'){$action='move_yard';$p['move_confirmed']=true;}
            elseif($choice==='move'){$action='move_inside';$p['move_confirmed']=true;}
            // keep záměrně nic neukončuje, ani po půlnoci či po odhadu.
        }
        query("UPDATE jobs SET status='parts' WHERE id=?",[$id]);
    }
    if($action!=='wait_parts')a_edit($u,'move_vehicles');
    if($action==='update_expected'){
        if(!$current)fail('Auto nemá aktivní pobyt.',409);$expected=ops_expected_end($p,$now);query('UPDATE abc_job_presence SET expected_end=? WHERE id=?',[$expected,$current['id']]);
    }elseif(in_array($action,['move_yard','depart'],true)){
        if(empty($p['move_confirmed']))fail('Potvrď skutečné fyzické odstavení nebo předání auta.');
        if($current)ops_close_presence($current,$u,$now);$location=$action==='depart'?'departed':'yard';query('UPDATE jobs SET location_state=?,received_at=COALESCE(received_at,?) WHERE id=?',[$location,$now,$id]);
    }elseif(in_array($action,['take_inside','move_inside','start_outside'],true)){
        if($action!=='move_inside')card_mutable($id,$j);
        if($current&&empty($p['move_confirmed']))fail('Potvrď skutečný přesun ze současného místa.');
        $mode=$action==='start_outside'?'outside_work':'inside';$resource=$mode==='inside'?positive_id($p['resource_id']??null):null;$expected=ops_expected_end($p,$now);
        if($current&&$mode===$current['mode']&&($mode!=='inside'||$resource===(int)$current['resource_id']))fail('Auto už na tomto místě je. Původní pobyt zůstává aktivní.',409);
        ops_check_start($j,$resource,$expected,$now,$mode);
        if($current)ops_close_presence($current,$u,$now);ops_open_presence($j,$u,$mode,$resource,$expected,$now,post_str($p,'reason',300));$location=$mode==='inside'?'inside':'outside_work';
        if($action!=='move_inside'&&in_array($j['status'],['new','done','closed','parts'],true))query("UPDATE jobs SET status='work' WHERE id=?",[$id]);
    }elseif($action==='receive_yard'){
        if($current)fail('Auto už má aktivní pobyt. Použij skutečný přesun.',409);query("UPDATE jobs SET location_state='yard',received_at=COALESCE(received_at,?) WHERE id=?",[$now,$id]);$location='yard';
    }
    a_reset_queue($j);query('UPDATE jobs SET revision=revision+1 WHERE id=?',[$id]);
    log_event((int)$u['id'],$id,'physical_operation',$action,['before'=>['location'=>$j['location_state'],'presence'=>$before,'status'=>$j['status']],'after'=>['location'=>$location,'presence'=>ops_active($id),'status'=>query('SELECT status FROM jobs WHERE id=?',[$id])->fetchColumn()],'recorded_at'=>$now]);
}
function ops_parts(int $job): array {return query("SELECT t.id,t.job_id,t.description,t.quantity,t.unit,t.status,t.revision,t.part_code,t.procurement_stage,t.ordered_quantity,t.expected_on,t.supplier_name,t.order_reference,t.supplier_url,t.procurement_note,t.required_for_start,COALESCE((SELECT SUM(r.quantity) FROM abc_part_receipts r WHERE r.task_id=t.id),0) received_quantity FROM abc_quick_tasks t WHERE t.job_id=? AND t.kind='part' AND t.entry_type='work' AND t.status<>'cancelled' ORDER BY t.id",[$job])->fetchAll();}
function ops_readiness(array $parts): array {
    $needed=array_values(array_filter($parts,fn($p)=>(bool)$p['required_for_start']&&$p['status']!=='done'));$total=count($needed);$ready=0;$received=false;$ordered=false;$identify=false;$dates=[];$unknown=false;
    foreach($needed as $p){if((float)$p['received_quantity']+.0001>=(float)$p['quantity']){$ready++;continue;}if((float)$p['received_quantity']>0)$received=true;if($p['procurement_stage']==='ordered')$ordered=true;if(in_array($p['procurement_stage'],['unknown','identify'],true))$identify=true;if($p['expected_on'])$dates[]=$p['expected_on'];else$unknown=true;}
    $state=!$total?'not_required':($ready===$total?'ready':(($ready||$received)?'partial':($identify?'identify':($ordered?'ordered':'to_order'))));
    return ['state'=>$state,'required_items'=>$total,'ready_items'=>$ready,'expected_on'=>$dates?max($dates):null,'unknown_expected'=>$unknown,'label'=>match($state){'not_required'=>'Bez dalších požadavků na díly','ready'=>'Potřebné díly připravené','partial'=>'Částečně připravené díly','identify'=>'Díly určit / ověřit','ordered'=>'Ručně evidovaná objednávka','to_order'=>'Díly k objednání',default=>'Příprava neověřená'}];
}
function ops_summary(array $j): array {$active=ops_active((int)$j['id']);$prep=$j['preparation_assigned_to']?query('SELECT name FROM users WHERE id=?',[$j['preparation_assigned_to']])->fetchColumn():null;return ['location'=>$j['location_state'],'received_at'=>$j['received_at'],'presence'=>$active,'readiness'=>ops_readiness(ops_parts((int)$j['id'])),'preparation_assigned_to'=>$j['preparation_assigned_to'],'preparation_name'=>$prep?:null,'assigned_name'=>$j['assigned_to']?query('SELECT name FROM users WHERE id=?',[$j['assigned_to']])->fetchColumn():null];}
/** Plán nepřepisujeme: fyzické držení se promítne jako nejistota nebo konflikt. */
function ops_conflicts(array $u): array {
    $now=ops_now();$result=[];$active=query("SELECT p.*,r.name resource_name FROM abc_job_presence p LEFT JOIN abc_resources r ON r.id=p.resource_id WHERE p.ended_at IS NULL AND p.mode='inside'")->fetchAll();$cap=a_settings()['car_capacity'];if(!$active)return [];
    foreach(query("SELECT * FROM office_appointments WHERE work_mode='inside' AND status IN ('confirmed','requested') AND COALESCE(end_at,'9999-12-31 23:59:59')>NOW() ORDER BY start_at")->fetchAll() as $a){
        $end=a_calendar_end($a['start_at'],$a['end_at']);$key=ops_booking_key($a);$iv=ops_capacity_intervals($a['start_at'],$end,0,null,true);
        $global=$cap&&ops_peak($iv,$a['start_at'],$end)>(int)$cap;$resource=false;
        if($a['resource_id']&&$a['resource_start']&&$a['resource_end']){$r=ops_resource((int)$a['resource_id']);$resource=ops_peak(ops_capacity_intervals($a['resource_start'],$a['resource_end'],0,(int)$a['resource_id'],true),$a['resource_start'],$a['resource_end'])>(int)$r['capacity'];}
        if(!$global&&!$resource)continue;
        foreach($active as $p){if(ops_car_key((int)$p['job_id'])===$key||$p['started_at']>=$end||(!$global&&(int)$p['resource_id']!==(int)$a['resource_id']))continue;
            $j=query('SELECT * FROM jobs WHERE id=?',[$a['job_id']])->fetch();$holder=query('SELECT * FROM jobs WHERE id=?',[$p['job_id']])->fetch();if(!($j&&a_can_view($u,$j))&&!a_can_view($u,$holder))continue;
            $blocking=$a['start_at']<=$now||(!empty($p['expected_end'])&&$p['expected_end']<=$now)||(!empty($p['expected_end'])&&$p['expected_end']>$a['start_at']);
            $result[]=['resource_id'=>$p['resource_id'],'resource_name'=>$p['resource_name'],'holder_job_id'=>a_can_view($u,$holder)?(int)$p['job_id']:null,'booking_job_id'=>$j&&a_can_view($u,$j)?(int)$a['job_id']:null,'booking_start'=>$a['start_at'],'severity'=>$blocking?'conflict':'uncertain','label'=>$blocking?'Auto stále drží kapacitu proti navazujícímu plánu. Vyřeš přesun nebo termín.':'Uvolnění kapacity před navazujícím plánem zatím není potvrzené'];
        }
    }return $result;
}
function ops_calendar_days(string $from,string $until,array $all,array $resources): array {
    $days=[];$settings=a_settings();$holds=query("SELECT * FROM abc_job_presence WHERE mode='inside' AND ended_at IS NULL")->fetchAll();$capacity=ops_capacity_intervals($from,$until,0,null,true);$resourceIntervals=[];foreach($resources as $r)$resourceIntervals[$r['id']]=ops_capacity_intervals($from,$until,0,(int)$r['id'],true);
    for($day=$from;$day<$until;$day=(new DateTimeImmutable($day))->modify('+1 day')->format('Y-m-d')){
        $start=$day.' 00:00:00';$end=$day.' 23:59:59';$rows=array_values(array_filter($all,fn($a)=>$a['start_at']<$end&&a_calendar_end($a['start_at'],$a['end_at'])>$start));$inside=array_values(array_filter($rows,fn($a)=>$a['work_mode']==='inside'));$active=array_values(array_filter($holds,fn($p)=>$p['started_at']<$end));
        if(!$rows&&!$active&&!array_filter($capacity,fn($i)=>$i[1]<$end&&$i[2]>$start))continue;$peak=ops_peak($capacity,$start,$end);$unknown=(bool)$active||(bool)array_filter($rows,fn($a)=>!$a['end_at']);$full=$settings['car_capacity']&&$peak>=(int)$settings['car_capacity'];$rp=[];
        foreach($resources as $r){$rp[$r['id']]=ops_peak($resourceIntervals[$r['id']],$start,$end);if($rp[$r['id']]>=(int)$r['capacity'])$full=true;}
        $days[$day]=['count'=>count($rows),'unknown'=>$unknown,'peak'=>$peak,'resource_peaks'=>$rp,'active_holds'=>count($active),'state'=>$unknown?'unknown':($full?'full':(!$inside?'free':(!$settings['car_capacity']?'unset':'partial')))];
    }return $days;
}
function ops_info(array $j,array $u): array {
    $s=ops_summary($j);$now=ops_now();$key=ops_car_key((int)$j['id']);$available=[];
    foreach(query('SELECT id,name,kind,capacity FROM abc_resources WHERE active=1 ORDER BY name')->fetchAll() as $r){$rows=query("SELECT job_id,started_at FROM abc_job_presence WHERE ended_at IS NULL AND mode='inside' AND resource_id=? AND job_id<>?",[$r['id'],$j['id']])->fetchAll();$iv=array_map(fn($p)=>[ops_car_key((int)$p['job_id']),$p['started_at'],'9999-12-31 23:59:59'],$rows);$iv[]=[$key,$now,'9999-12-31 23:59:59'];$cap=a_settings()['car_capacity'];$all=query("SELECT job_id,started_at FROM abc_job_presence WHERE ended_at IS NULL AND mode='inside' AND job_id<>?",[$j['id']])->fetchAll();$allIv=array_map(fn($p)=>[ops_car_key((int)$p['job_id']),$p['started_at'],'9999-12-31 23:59:59'],$all);$allIv[]=[$key,$now,'9999-12-31 23:59:59'];$r['available_now']=ops_peak($iv,$now,'9999-12-31 23:59:59')<=(int)$r['capacity']&&(!$cap||ops_peak($allIv,$now,'9999-12-31 23:59:59')<=(int)$cap);$available[]=$r;}
    $staff=($u['role']==='owner'||abc_perm($u,'assign_jobs')||abc_perm($u,'share_jobs'))?query('SELECT id,name FROM users WHERE active=1 ORDER BY name')->fetchAll():[['id'=>$u['id'],'name'=>$u['name']]];
    return ['job_id'=>$j['id'],'revision'=>$j['revision'],'status'=>$j['status'],'work_day'=>$j['work_day'],'appointment'=>query("SELECT * FROM office_appointments WHERE job_id=? AND status IN ('confirmed','requested') ORDER BY start_at LIMIT 1",[$j['id']])->fetch()?:null,'assigned_to'=>$j['assigned_to'],...$s,'parts'=>ops_parts((int)$j['id']),'receipts'=>query('SELECT r.* FROM abc_part_receipts r JOIN abc_quick_tasks t ON t.id=r.task_id WHERE t.job_id=? ORDER BY r.id DESC',[$j['id']])->fetchAll(),'resources'=>$available,'staff'=>$staff,'history'=>query('SELECT p.*,r.name resource_name FROM abc_job_presence p LEFT JOIN abc_resources r ON r.id=p.resource_id WHERE p.job_id=? ORDER BY p.id DESC',[$j['id']])->fetchAll(),'conflicts'=>ops_conflicts($u),'locked'=>card_locked((int)$j['id']),'permissions'=>['move'=>abc_perm($u,'edit_jobs')&&abc_perm($u,'move_vehicles'),'prepare'=>abc_perm($u,'edit_jobs')&&abc_perm($u,'prepare_jobs'),'status'=>abc_perm($u,'edit_jobs')&&abc_perm($u,'change_status'),'assign'=>abc_perm($u,'assign_jobs')||$u['role']==='owner','share'=>abc_perm($u,'share_jobs')]];
}
function ops_assert_unit(int $task,string $unit): void {$t=query('SELECT unit,ordered_quantity FROM abc_quick_tasks WHERE id=?',[$task])->fetch();if($t&&$t['unit']!==$unit&&((float)$t['ordered_quantity']>0||query('SELECT id FROM abc_part_receipts WHERE task_id=? LIMIT 1',[$task])->fetch()))fail('U objednaného nebo převzatého dílu nelze tiše změnit jednotku. Zachovej jednotku skutečné dodávky.',409);}
