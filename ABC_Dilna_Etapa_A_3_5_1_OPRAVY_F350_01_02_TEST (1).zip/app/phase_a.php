<?php
declare(strict_types=1);
const ABC_A_SCHEMA='3.5.1-f350';
require_once __DIR__.'/review_331.php';
require_once __DIR__.'/operations_v2.php';
require_once __DIR__.'/catalog_350.php';
require_once __DIR__.'/documents_350.php';
require_once __DIR__.'/review_351.php';
function a_permissions(): array {return ['manage_catalog'=>'Spravovat společný ceník','view_documents'=>'Zobrazit a stáhnout dokumenty','print_documents'=>'Tisknout firemní formuláře a ceník','manage_documents'=>'Spravovat dokumenty a tiskové šablony','move_vehicles'=>'Skutečné přesuny vozidel','prepare_jobs'=>'Příprava a převzetí dílů','assign_jobs'=>'Přidělovat práci kolegům','create_jobs'=>'Přijímat zakázky','edit_jobs'=>'Upravovat zakázku','edit_lines'=>'Přidávat a upravovat práce/díly','edit_identity'=>'Doplňovat zákazníka a vozidlo','change_status'=>'Měnit stav opravy','move_appointments'=>'Měnit termíny','price_jobs'=>'Měnit prodejní ceny','discount_jobs'=>'Poskytovat slevu','handover_billing'=>'Předat k vyúčtování','receive_billing'=>'Přebírat frontu vyúčtování','issue_invoices'=>'Vystavovat faktury','collect_payments'=>'Přijímat platby / vlastní pokladna','confirm_transfers'=>'Potvrzovat převody','print_receipts'=>'Tisknout příjmové doklady','take_jobs'=>'Přebírat volné zakázky','view_all_jobs'=>'Vidět zakázky kolegů','share_jobs'=>'Přidělit přístup kolegovi','manage_team'=>'Spravovat zaměstnance'];}
function a_legacy_permissions(): array {return ['view_documents','print_documents','move_vehicles','prepare_jobs','create_jobs','edit_jobs','edit_lines','edit_identity','change_status','move_appointments','handover_billing'];}
function a_migrate(PDO $db): void {
    $db->exec("CREATE TABLE IF NOT EXISTS abc_workshop_settings(id INT PRIMARY KEY,revision INT UNSIGNED NOT NULL DEFAULT 1,settings_json LONGTEXT NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $s=$db->prepare('INSERT IGNORE INTO abc_workshop_settings(id,settings_json) VALUES (1,?)');$s->execute([json_encode(a_defaults(),JSON_UNESCAPED_UNICODE)]);
    $add=['jobs'=>['billing_state'=>"VARCHAR(20) NOT NULL DEFAULT 'unbilled'",'billing_to'=>'INT NULL','billing_by'=>'INT NULL','billing_at'=>'DATETIME NULL'], 'crm_vehicles'=>['engine_code'=>"VARCHAR(40) NOT NULL DEFAULT ''",'fuel'=>"VARCHAR(40) NOT NULL DEFAULT ''",'engine_cc'=>'INT NULL','power_kw'=>'DECIMAL(6,1) NULL','year'=>'SMALLINT NULL','stk_due'=>'DATE NULL','color'=>"VARCHAR(60) NOT NULL DEFAULT ''",'condition_note'=>"VARCHAR(1000) NOT NULL DEFAULT ''"], 'abc_quick_tasks'=>['bundle_key'=>'VARCHAR(64) NULL'], 'office_appointments'=>['resource_id'=>'INT NULL','resource_start'=>'DATETIME NULL','resource_end'=>'DATETIME NULL']];
    foreach($add as $table=>$cols){$found=array_column($db->query('SHOW COLUMNS FROM `'.$table.'`')->fetchAll(),'Field');foreach($cols as $col=>$sql)if(!in_array($col,$found,true))$db->exec('ALTER TABLE `'.$table.'` ADD COLUMN `'.$col.'` '.$sql);}
    $c=$db->query("SHOW COLUMNS FROM office_appointments LIKE 'end_at'")->fetch();if($c['Null']==='NO')$db->exec('ALTER TABLE office_appointments MODIFY end_at DATETIME NULL');
    $db->exec("CREATE TABLE IF NOT EXISTS abc_job_access(job_id INT NOT NULL,user_id INT NOT NULL,granted_by INT NOT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(job_id,user_id),FOREIGN KEY(job_id) REFERENCES jobs(id),FOREIGN KEY(user_id) REFERENCES users(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $db->exec("CREATE TABLE IF NOT EXISTS abc_resources(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(80) NOT NULL,kind VARCHAR(12) NOT NULL,capacity INT NOT NULL DEFAULT 1,active TINYINT NOT NULL DEFAULT 1,revision INT UNSIGNED NOT NULL DEFAULT 1) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    // Privilegované staré role se nemění. Základní dosavadní pracovní práva se
    // doplní jen jednou; pozdější individuální odebrání zůstane zachováno.
    $done=$db->query("SELECT version FROM schema_meta WHERE version='3.3.0-permissions'")->fetchColumn();
    if(!$done){$db->beginTransaction();foreach($db->query('SELECT id,permissions FROM users FOR UPDATE')->fetchAll() as $u){$p=json_decode($u['permissions'],true)?:[];$s=$db->prepare('UPDATE users SET permissions=? WHERE id=?');$s->execute([json_encode(array_values(array_unique(array_merge($p,a_legacy_permissions())))),$u['id']]);}$db->exec("INSERT IGNORE INTO schema_meta(version) VALUES ('3.3.0-permissions')");$db->commit();}
    $db->exec("UPDATE jobs j SET billing_state='documented' WHERE billing_state='unbilled' AND (EXISTS(SELECT 1 FROM office_invoices i WHERE i.job_id=j.id) OR EXISTS(SELECT 1 FROM payments p WHERE p.job_id=j.id))");
    $db->exec("INSERT IGNORE INTO schema_meta(version) VALUES ('3.3.0-a')");
    a_migrate_331($db);
    ops_migrate($db);
    c_migrate($db);
    a_migrate_351($db);
}
function a_defaults(): array {return ['theme'=>'navy','services'=>['Pneuservis','Oleje a filtry','Brzdy','Autoskla','Diagnostika','Klimatizace','Ostatní opravy'],'status_labels'=>['new'=>'Objednáno','work'=>'V opravě','parts'=>'Čeká na díly','review'=>'Ke kontrole','done'=>'Hotovo','closed'=>'Předáno'],'office_available'=>false,'car_capacity'=>null,'hours'=>[],'min_duration'=>15,'max_duration'=>480,'tyres'=>[],'tyre_extras'=>[],'service_templates'=>a_manual_templates(),'tyre_van_runflat_exclusive'=>true];}
function a_settings(): array {static $s;if($s===null){$r=query('SELECT revision,settings_json FROM abc_workshop_settings WHERE id=1')->fetch();$s=['revision'=>(int)$r['revision'],...array_replace(a_defaults(),json_decode($r['settings_json'],true)?:[])];}return c_decorate_settings($s);}
function a_can_view(array $u,array $j): bool {return $u['role']==='owner'||abc_perm($u,'view_all_jobs')||(int)$j['assigned_to']===(int)$u['id']||(!$j['assigned_to']&&(int)$j['created_by']===(int)$u['id'])||((int)($j['preparation_assigned_to']??0)===(int)$u['id'])||(bool)query('SELECT user_id FROM abc_job_access WHERE job_id=? AND user_id=?',[$j['id'],$u['id']])->fetchColumn()||($j['billing_state']==='queued'&&((int)$j['billing_to']===(int)$u['id']||(!$j['billing_to']&&abc_perm($u,'receive_billing'))));}
function a_job_where(array $u,string $alias='jobs'): array {if($u['role']==='owner'||abc_perm($u,'view_all_jobs'))return ['1=1',[]];return ["($alias.assigned_to=? OR $alias.preparation_assigned_to=? OR ($alias.assigned_to IS NULL AND $alias.created_by=?) OR EXISTS(SELECT 1 FROM abc_job_access ax WHERE ax.job_id=$alias.id AND ax.user_id=?) OR ($alias.billing_state='queued' AND ($alias.billing_to=? OR ($alias.billing_to IS NULL AND ?=1))))",[$u['id'],$u['id'],$u['id'],$u['id'],$u['id'],abc_perm($u,'receive_billing')?1:0]];}
function a_edit(array $u,string $right='edit_jobs'): void {permission($u,'edit_jobs');permission($u,$right);}
function a_reset_queue(array $j): void {if($j['billing_state']==='queued'){query("UPDATE jobs SET billing_state='unbilled',billing_to=NULL,billing_by=NULL,billing_at=NULL WHERE id=?",[$j['id']]);log_event((int)($_SESSION['user_id']??0),(int)$j['id'],'billing_recalled','Po změně zakázky je potřeba nové předání');}}
function a_vehicle_fields(array $p,array $old=[]): array {
    $r=[];foreach(['engine_code'=>40,'fuel'=>40,'color'=>60,'condition_note'=>1000] as $k=>$n)$r[$k]=array_key_exists($k,$p)?post_str($p,$k,$n):($old[$k]??'');
    foreach(['engine_cc'=>20000,'power_kw'=>3000,'year'=>(int)date('Y')+2] as $k=>$max){$s=$p[$k]??$old[$k]??'';if($s===null||$s===''){$r[$k]=null;continue;}if(!is_scalar($s)||!preg_match($k==='power_kw'?'/^\d{1,4}(\.\d)?$/D':'/^\d+$/D',(string)$s)||(float)$s<1||(float)$s>$max||($k==='year'&&(int)$s<1886))fail('Neplatný technický údaj: '.$k);$r[$k]=$s;}
    $d=$p['stk_due']??$old['stk_due']??'';if($d&&!a_date((string)$d))fail('Neplatný termín STK.');$r['stk_due']=$d?:null;return $r;
}
function a_date(string $s): bool {$d=DateTimeImmutable::createFromFormat('!Y-m-d',$s);return $d&&$d->format('Y-m-d')===$s;}
