<?php
declare(strict_types=1);
function platform_key(array $p): string {$key=post_str($p,'request_key',80);if(!preg_match('/^[a-zA-Z0-9_-]{16,80}$/D',$key))fail('Obnov formulář a zkus to znovu.');return $key;}
function platform_tenant(int $id): array {$t=pq('SELECT * FROM saas_tenants WHERE id=?',[$id])->fetch();if(!$t)fail('Servis neexistuje.',404);return $t;}
function platform_attach(array $t): void {
 $c=open_tenant($t['credentials'],$t['tenant_key']);$p=tenant_pdo($c);require_once __DIR__.'/migrations.php';abc_migrate_a12($p);saas_business_schema($p,$t['tenant_key'],tenant_profile_defaults($t['name']));pq("UPDATE saas_tenants SET state='active' WHERE id=?",[$t['id']]);
}
function platform_action(array $u,array $p): ?array {
 $a=post_str($p,'action',40);
 if($a==='plan'){ $name=post_str($p,'name',100);$price=money($p['monthly_price']??null);if(!$name||$price<=0)fail('Zadej název tarifu a skutečnou kladnou měsíční cenu.');pq('INSERT INTO saas_plans(name,monthly_price) VALUES (?,?)',[$name,$price]);platform_audit((int)$u['id'],null,'plan_created',['name'=>$name,'price'=>$price]);return null; }
 if($a==='tenant'){
  $name=post_str($p,'name',160);$slug=post_str($p,'slug',60);if(!$name||!preg_match('/^[a-z0-9][a-z0-9-]{2,59}$/D',$slug))fail('Zadej název a kód servisu malými písmeny bez mezer.');
  $c=[];foreach(['db_host'=>180,'db_name'=>100,'db_user'=>100,'db_password'=>300] as $key=>$max)$c[$key]=post_str($p,$key,$max);$c['db_port']=filter_var($p['db_port']??3306,FILTER_VALIDATE_INT);if(!$c['db_host']||!$c['db_name']||!$c['db_user']||$c['db_port']<1||$c['db_port']>65535||str_contains($c['db_host'],';')||str_contains($c['db_name'],';'))fail('Neplatné údaje databáze.');
  $target=tenant_pdo($c);$tables=$target->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);$attach=!empty($p['attach_copy']);if($tables&&!$attach)fail('Databáze není prázdná. Pro známou kopii 3.0 výslovně zvol připojení kopie.',409);if($attach&&empty($p['copy_confirmed']))fail('Potvrď, že připojuješ samostatnou kopii a máš zálohu.');
  if($attach){if(!in_array('schema_meta',$tables,true)||!$target->query("SELECT version FROM schema_meta WHERE version='3.0.0'")->fetchColumn())fail('Připojení podporuje ověřenou kopii 3.0. Neznámá databáze nebyla změněná.',409);if(in_array('saas_identity',$tables,true)&&$target->query('SELECT tenant_key FROM saas_identity WHERE id=1')->fetchColumn())fail('Databáze už je přiřazená jinému servisu.',409);}
  $identity=bin2hex(random_bytes(16));$token=bin2hex(random_bytes(24));$c['setup_token']=$attach?'':$token;$fingerprint=hash('sha256',strtolower($c['db_host']).':'.$c['db_port'].'/'.strtolower($c['db_name']));
  $plan=empty($p['plan_id'])?null:positive_id($p['plan_id']);if($plan&&!pq('SELECT id FROM saas_plans WHERE id=? AND active=1',[$plan])->fetch())fail('Tarif neexistuje.');
  try{pq('INSERT INTO saas_tenants(tenant_key,slug,name,plan_id,access_until,credentials,db_fingerprint) VALUES (?,?,?,?,?,?,?)',[$identity,$slug,$name,$plan,date('Y-m-d',strtotime('+14 days')),seal_tenant($c,$identity),$fingerprint]);}catch(PDOException $e){if($e->getCode()==='23000')fail('Kód servisu nebo databáze už jsou používané.',409);throw $e;}
  $id=(int)platform_db()->lastInsertId();platform_audit((int)$u['id'],$id,'tenant_registered',['slug'=>$slug,'copy'=>$attach]);if($attach){try{platform_attach(platform_tenant($id));}catch(Throwable $e){error_log('Připojení servisu: '.$e->getMessage());return ['id'=>$id,'error'=>'Servis je evidovaný, ale připojení kopie se nedokončilo. Zkontroluj práva a použij Dokončit připojení.'];}}
  return ['id'=>$id,'setup_token'=>$attach?null:$token,'slug'=>$slug];
 }
 $id=positive_id($p['id']??null);$t=platform_tenant($id);
 if($a==='attach'){if(empty($p['copy_confirmed']))fail('Potvrď práci s kopií.');platform_attach($t);platform_audit((int)$u['id'],$id,'tenant_attached');return null;}
 if($a==='state'){
  $state=post_str($p,'state',20);$until=post_str($p,'access_until',10);$reason=post_str($p,'reason',300);$d=DateTimeImmutable::createFromFormat('!Y-m-d',$until);if(!in_array($state,['active','suspended'],true)||!$d||$d->format('Y-m-d')!==$until||!$reason)fail('Vyplň stav, datum a důvod změny.');
  if($state==='active'){$c=open_tenant($t['credentials'],$t['tenant_key']);$db=tenant_pdo($c);$bound=$db->query('SELECT tenant_key FROM saas_identity WHERE id=1')->fetchColumn();if(!is_string($bound)||!hash_equals($bound,$t['tenant_key']))fail('Nejdříve dokonči správnou instalaci servisu.',409);}
  pq('UPDATE saas_tenants SET state=?,access_until=? WHERE id=?',[$state,$until,$id]);platform_audit((int)$u['id'],$id,'access_changed',['old_state'=>$t['state'],'old_until'=>$t['access_until'],'state'=>$state,'until'=>$until,'reason'=>$reason]);return null;
 }
 if($a==='bill'){
  if(!$t['plan_id'])fail('Nejdříve přiřaď tarif.');$plan=pq('SELECT * FROM saas_plans WHERE id=? AND active=1',[$t['plan_id']])->fetch();if(!$plan)fail('Tarif není aktivní.');$start=max(date('Y-m-d'),date('Y-m-d',strtotime($t['access_until'].' +1 day')));$end=saas_month_end($start);$key=platform_key($p);$ref=post_str($p,'external_invoice',100);
  try{pq('INSERT INTO saas_bills(tenant_id,plan_id,amount,period_start,period_end,external_invoice,request_key) VALUES (?,?,?,?,?,?,?)',[$id,$plan['id'],$plan['monthly_price'],$start,$end,$ref,$key]);}catch(PDOException $e){if($e->getCode()==='23000')fail('Předpis pro stejné období už existuje.',409);throw $e;}platform_audit((int)$u['id'],$id,'subscription_bill',['period_start'=>$start,'period_end'=>$end,'amount'=>$plan['monthly_price'],'external_invoice'=>$ref]);return null;
 }
 if($a==='plan_assign'){ $plan=positive_id($p['plan_id']??null);if(!pq('SELECT id FROM saas_plans WHERE id=? AND active=1',[$plan])->fetch())fail('Tarif není dostupný.');pq('UPDATE saas_tenants SET plan_id=? WHERE id=?',[$plan,$id]);platform_audit((int)$u['id'],$id,'plan_assigned',['old'=>$t['plan_id'],'new'=>$plan]);return null; }
 if($a==='subscription_payment'){
  $key=platform_key($p);$amount=money($p['amount']??null);$billId=positive_id($p['bill_id']??null);$ref=post_str($p,'reference',160);if($amount<=0||!$ref||empty($p['confirmed']))fail('Potvrď skutečně přijatou platbu, částku a bankovní referenci.');$db=platform_db();$db->beginTransaction();
  $bill=pq('SELECT * FROM saas_bills WHERE id=? AND tenant_id=? FOR UPDATE',[$billId,$id])->fetch();if(!$bill)fail('Předpis nepatří servisu.',404);$old=pq('SELECT * FROM saas_payments WHERE request_key=?',[$key])->fetch();if($old){if((int)$old['bill_id']!==$billId||abs((float)$old['amount']-$amount)>.009||$old['reference']!==$ref)fail('Klíč platby už má jiná data.',409);$db->rollBack();return null;}
  $paid=(float)pq('SELECT COALESCE(SUM(amount),0) FROM saas_payments WHERE bill_id=?',[$billId])->fetchColumn();if($amount>(float)$bill['amount']-$paid+.009)fail('Platba nesmí přesáhnout nedoplatek.',409);
  pq('INSERT INTO saas_payments(bill_id,admin_id,amount,reference,request_key,received_at) VALUES (?,?,?,?,?,NOW())',[$billId,$u['id'],$amount,$ref,$key]);
  if(abs($paid+$amount-(float)$bill['amount'])<.009){$current=pq('SELECT * FROM saas_tenants WHERE id=? FOR UPDATE',[$id])->fetch();$until=max($current['access_until'],$bill['period_end']);pq('UPDATE saas_tenants SET access_until=? WHERE id=?',[$until,$id]);}
  platform_audit((int)$u['id'],$id,'subscription_payment',['bill_id'=>$billId,'amount'=>$amount,'reference'=>$ref]);$db->commit();return null;
 }
 fail('Neznámá operace.',404);
}
