<?php
declare(strict_types=1);

/** F350-01: neznámé účtované hodiny jsou NULL, nikdy fiktivní 0 nebo 1. */
function a_migrate_351(PDO $db): void {
    foreach(['abc_quick_tasks','items','abc_price_history'] as $table){
        $column=$db->query("SHOW COLUMNS FROM `{$table}` LIKE 'quantity'")->fetch();
        if($column['Null']==='NO'){
            $default=$table==='abc_price_history'?'':' DEFAULT 1';
            $db->exec("ALTER TABLE `{$table}` MODIFY quantity DECIMAL(10,3) NULL".$default);
        }
        if($table!=='abc_price_history'){
            // Dosavadní NOT NULL se u jiných prací a dílů nesmí oslabit ani v DB.
            $name=$table==='items'?'abc_items_hourly_quantity':'abc_tasks_hourly_quantity';
            $s=$db->prepare("SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS WHERE CONSTRAINT_SCHEMA=DATABASE() AND TABLE_NAME=? AND CONSTRAINT_NAME=?");$s->execute([$table,$name]);
            if(!(int)$s->fetchColumn())$db->exec("ALTER TABLE `{$table}` ADD CONSTRAINT `{$name}` CHECK (quantity IS NOT NULL OR (kind='labor' AND unit='hod'))");
        }
    }
    $db->exec("INSERT IGNORE INTO schema_meta(version) VALUES ('3.5.1-f350')");
}

function card_quantity($raw,string $kind,string $unit): ?float {
    if($kind==='labor'&&$unit==='hod'&&($raw===null||$raw===''))return null;
    $q=qty($raw);
    if($q>1000)fail('Množství může být nejvýše 1000.');
    return $q;
}
