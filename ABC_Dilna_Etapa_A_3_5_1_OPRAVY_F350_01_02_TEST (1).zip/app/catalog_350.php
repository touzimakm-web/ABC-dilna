<?php
declare(strict_types=1);
const ABC_CATALOG_SCHEMA='3.5.0-catalog-documents';
function c_migrate(PDO $db): void {
 $add=['abc_quick_catalog'=>['revision'=>'INT UNSIGNED NOT NULL DEFAULT 1','sort_order'=>'INT NOT NULL DEFAULT 0','public_item'=>'TINYINT NOT NULL DEFAULT 0','pricing_mode'=>"VARCHAR(16) NOT NULL DEFAULT 'unit'"],
 'abc_quick_tasks'=>['catalog_id'=>'INT NULL','catalog_revision'=>'INT NULL','catalog_snapshot'=>'LONGTEXT NULL','price_origin'=>"VARCHAR(16) NOT NULL DEFAULT 'legacy'"]];
 foreach($add as $table=>$cols){$found=array_column($db->query('SHOW COLUMNS FROM `'.$table.'`')->fetchAll(),'Field');foreach($cols as $k=>$sql)if(!in_array($k,$found,true))$db->exec('ALTER TABLE `'.$table.'` ADD COLUMN `'.$k.'` '.$sql);}
 if($db->query("SHOW COLUMNS FROM abc_quick_catalog LIKE 'unit_price'")->fetch()['Null']==='NO')$db->exec('ALTER TABLE abc_quick_catalog MODIFY unit_price DECIMAL(12,2) NULL');
 $db->exec("CREATE TABLE IF NOT EXISTS abc_catalog_state(id INT PRIMARY KEY,revision INT UNSIGNED NOT NULL DEFAULT 1,valid_from DATE NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");$db->exec('INSERT IGNORE INTO abc_catalog_state(id) VALUES(1)');
 $db->exec("CREATE TABLE IF NOT EXISTS abc_catalog_history(id BIGINT AUTO_INCREMENT PRIMARY KEY,catalog_id INT NULL,user_id INT NOT NULL,changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,before_json LONGTEXT NULL,after_json LONGTEXT NOT NULL,FOREIGN KEY(user_id) REFERENCES users(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
 d_migrate($db);
 $db->beginTransaction();try{
  if(!$db->query("SELECT version FROM schema_meta WHERE version='3.5.0-defaults'")->fetchColumn()){
   $db->exec("UPDATE abc_quick_catalog SET pricing_mode=CASE WHEN kind='labor' AND unit='hod' THEN 'hourly' WHEN kind='labor' AND unit IN ('úkon','sada') THEN 'fixed' ELSE 'unit' END");
   $row=$db->query('SELECT settings_json FROM abc_workshop_settings WHERE id=1 FOR UPDATE')->fetch();$settings=json_decode($row['settings_json'],true)?:[];$changed=false;
   foreach($settings['tyres']??[] as $i=>$r){$s=$db->prepare('SELECT unit FROM abc_quick_catalog WHERE id=?');$s->execute([$r['catalog_id']]);$unit=$s->fetchColumn();if($unit&&!in_array($unit,['ks','kolo','sada'],true)){$settings['tyres'][$i]['legacy_per_wheel']=true;$changed=true;}}
   if($changed){$s=$db->prepare('UPDATE abc_workshop_settings SET settings_json=?,revision=revision+1 WHERE id=1');$s->execute([json_encode($settings,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR)]);}
   foreach($db->query('SELECT id,permissions FROM users FOR UPDATE')->fetchAll() as $u){$p=json_decode($u['permissions'],true)?:[];$p=array_values(array_unique([...$p,'view_documents','print_documents']));$s=$db->prepare('UPDATE users SET permissions=? WHERE id=?');$s->execute([json_encode($p),$u['id']]);}
   $db->exec("INSERT IGNORE INTO schema_meta(version) VALUES('3.5.0-defaults')");
  }
  $db->exec("INSERT IGNORE INTO schema_meta(version) VALUES('3.5.0-catalog-documents')");$db->commit();
 }catch(Throwable $e){if($db->inTransaction())$db->rollBack();throw $e;}
}
function c_columns(): string {return 'id,category,description,kind,unit,unit_price,revision,sort_order,public_item,pricing_mode,active';}
function c_list(bool $all=false,bool $cost=false): array {return query('SELECT '.c_columns().($cost?',unit_cost':'').' FROM abc_quick_catalog'.($all?'':' WHERE active=1').' ORDER BY sort_order,category,description,id')->fetchAll();}
function c_row(int $id,bool $lock=false): array {$c=query('SELECT * FROM abc_quick_catalog WHERE id=?'.($lock?' FOR UPDATE':''),[$id])->fetch();if(!$c||!$c['active'])fail('Položka ceníku není dostupná.',409,['code'=>'catalog_unavailable']);return $c;}
function c_sale(array $c): array {return array_intersect_key($c,array_flip(explode(',',c_columns())));}
function c_check(array $c,$rev): void {card_version(['revision'=>$rev],(int)$c['revision'],'catalog',c_sale($c));}
function c_snapshot(array $c): string {return json_encode(c_sale($c),JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);}
function c_source(int $task,?array $c,string $origin): void {query('UPDATE abc_quick_tasks SET catalog_id=?,catalog_revision=?,catalog_snapshot=?,price_origin=? WHERE id=?',[$c['id']??null,$c['revision']??null,$c?c_snapshot($c):null,$origin,$task]);}
function c_nullable($v): ?float {return $v===null||$v===''?null:money($v,'prodejní cena');}
/** Množství nikdy neodvozujeme ze skutečného pobytu/docházky. */
function c_validate_mode(string $kind,string $unit,string $mode): void {
 if(!in_array($mode,['hourly','fixed','unit','variant'],true)||($mode==='hourly'&&($kind!=='labor'||$unit!=='hod'))||($unit==='hod'&&$mode!=='hourly')||($mode==='fixed'&&!in_array($unit,['úkon','sada'],true)))fail('Hodinová práce používá hod, pevný úkon úkon/sada; ostatní ceny mají skutečnou jednotku.');
}
/** Volá se uvnitř transakce, pro API i původní kancelářský formulář. */
function c_save(array $u,array $p): int {
 permission($u,'manage_catalog');$id=empty($p['id'])?0:positive_id($p['id']);$old=null;if($id){$old=query('SELECT * FROM abc_quick_catalog WHERE id=? FOR UPDATE',[$id])->fetch();if(!$old)fail('Položka ceníku neexistuje.',404);card_version($p,(int)$old['revision'],'catalog',c_sale($old));}
 $name=post_str($p,'description',220);$cat=post_str($p,'category',80);$kind=post_str($p,'kind',10);if(mb_strlen($name)<2||!$cat||!in_array($kind,['labor','part'],true))fail('Vyplň název, kategorii a druh položky.');
 $unit=card_unit($p['unit']??($kind==='labor'?'úkon':'ks'));$mode=post_str($p,'pricing_mode',16)?:($unit==='hod'?'hourly':($kind==='labor'&&in_array($unit,['úkon','sada'],true)?'fixed':'unit'));c_validate_mode($kind,$unit,$mode);
 $order=filter_var($p['sort_order']??($old['sort_order']??0),FILTER_VALIDATE_INT,['options'=>['min_range'=>-100000,'max_range'=>100000]]);if($order===false)fail('Neplatné pořadí.');
 $price=c_nullable($p['unit_price']??null);$cost=array_key_exists('unit_cost',$p)?money($p['unit_cost']??0,'náklad'):($old['unit_cost']??0);$active=!empty($p['active'])?1:0;$public=!empty($p['public_item'])?1:0;
 $values=[$cat,$name,$kind,$price,$cost,$active,$unit,$mode,$order,$public];
 if($id)query('UPDATE abc_quick_catalog SET category=?,description=?,kind=?,unit_price=?,unit_cost=?,active=?,unit=?,pricing_mode=?,sort_order=?,public_item=?,revision=revision+1 WHERE id=?',[...$values,$id]);
 else {query('INSERT INTO abc_quick_catalog(category,description,kind,unit_price,unit_cost,active,unit,pricing_mode,sort_order,public_item) VALUES(?,?,?,?,?,?,?,?,?,?)',$values);$id=(int)db()->lastInsertId();}
 query('UPDATE abc_catalog_state SET revision=revision+1 WHERE id=1');$after=query('SELECT * FROM abc_quick_catalog WHERE id=?',[$id])->fetch();
 query('INSERT INTO abc_catalog_history(catalog_id,user_id,before_json,after_json) VALUES(?,?,?,?)',[$id,$u['id'],$old?json_encode($old,JSON_UNESCAPED_UNICODE):null,json_encode($after,JSON_UNESCAPED_UNICODE)]);log_event((int)$u['id'],0,'catalog_changed','#'.$id,['before'=>$old,'after'=>$after]);return $id;
}
function c_decorate_settings(array $s): array {
 static $map=null;if($map===null)$map=array_column(c_list(),null,'id');foreach($s['service_templates'] as &$t)foreach($t['rows'] as &$r)if(!empty($r['catalog_id'])){$c=$map[$r['catalog_id']]??null;$r['catalog_revision']=$c['revision']??null;$r['catalog_price']=$c['unit_price']??null;$r['catalog_available']=$c!==null;}
 unset($r,$t);return $s;
}
function c_tyre_quantity(array $c,int $count,string $basis,bool $legacy=false): array {
 if($basis==='wheel'){
  if(!in_array($c['unit'],['ks','kolo'],true)&&!$legacy)fail('Cena za kolo potřebuje jednotku kolo nebo ks. Uprav ceník.',409);
  return [$count,in_array($c['unit'],['ks','kolo'],true)?$c['unit']:'kolo'];
 }
 if($basis==='set'){if($c['unit']!=='sada')fail('Cena za sadu potřebuje jednotku sada.',409);return [1,'sada'];}
 return [1,$c['unit']];
}

function c_locked_settings(): array {$r=query('SELECT revision,settings_json FROM abc_workshop_settings WHERE id=1 FOR UPDATE')->fetch();return c_decorate_settings(['revision'=>(int)$r['revision'],...array_replace(a_defaults(),json_decode($r['settings_json'],true)?:[])]);}
