<?php
declare(strict_types=1);
/** Jeden validátor používá příjem, přesun i recepce. Neurčený konec není
 * vydávaný za hodinovou rezervaci: při konfliktu se konzervativně posoudí
 * jako neuzavřený plán a kalendář jej označí jako nejistý. */
function a_calendar_end(string $start,?string $end): string {return $end?:'9999-12-31 23:59:59';}
function a_interval_max(array $rows,string $start,string $end): int {
    $events=[];foreach($rows as $r){$a=max($start,$r[0]);$b=min($end,$r[1]);if($a<$b){$events[]=[$a,1];$events[]=[$b,-1];}}
    usort($events,fn($a,$b)=>$a[0]<=>$b[0]?:$a[1]<=>$b[1]);$n=0;$max=0;foreach($events as $e){$n+=$e[1];$max=max($max,$n);}return $max;
}
function a_calendar_check(PDO $db,string $start,?string $end,int $exclude,int $mechanic,?int $resource=null,?string $rs=null,?string $re=null,string $mode='inside',int $job=0): void {
    ops_calendar_check($db,$start,$end,$exclude,$mechanic,$resource,$rs,$re,$mode,$job);
}

function a_resource_payload(array $p,string $start,?string $end): array {
    $resource=empty($p['resource_id'])?null:positive_id($p['resource_id']);if(!$resource)return [null,null,null];
    $rs=post_str($p,'resource_start',19);$re=post_str($p,'resource_end',19);
    if(!$rs&&!$re)return [$resource,$start,$end];
    foreach([$rs,$re] as $v){$d=DateTimeImmutable::createFromFormat('!Y-m-d\TH:i',$v);if(!$d||$d->format('Y-m-d\TH:i')!==$v)throw new OfficeRule('Zkontroluj interval použití heveru.');}
    return [$resource,str_replace('T',' ',$rs).':00',str_replace('T',' ',$re).':00'];
}
