<?php
declare(strict_types=1);
const D_MAX_PDF=5242880;
function d_defaults(): array {return ['title'=>'Zakázkový list','footer'=>'','show_vin'=>true,'show_mileage'=>true,'show_phone'=>true,'work_rows'=>6,'material_rows'=>5];}
function d_migrate(PDO $db): void {
 $db->exec("CREATE TABLE IF NOT EXISTS abc_documents(id INT AUTO_INCREMENT PRIMARY KEY,job_id INT NULL,vehicle_id INT NULL,revision INT UNSIGNED NOT NULL DEFAULT 1,active TINYINT NOT NULL DEFAULT 1,created_by INT NOT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(job_id) REFERENCES jobs(id),FOREIGN KEY(vehicle_id) REFERENCES crm_vehicles(id),FOREIGN KEY(created_by) REFERENCES users(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
 $db->exec("CREATE TABLE IF NOT EXISTS abc_document_versions(id INT AUTO_INCREMENT PRIMARY KEY,document_id INT NOT NULL,version INT UNSIGNED NOT NULL,title VARCHAR(180) NOT NULL,category VARCHAR(20) NOT NULL,staff_visible TINYINT NOT NULL DEFAULT 0,filename VARCHAR(200) NOT NULL,byte_size INT NOT NULL,sha256 CHAR(64) NOT NULL,pdf_bytes LONGBLOB NOT NULL,created_by INT NOT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,UNIQUE KEY document_version(document_id,version),FOREIGN KEY(document_id) REFERENCES abc_documents(id),FOREIGN KEY(created_by) REFERENCES users(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
 $db->exec("CREATE TABLE IF NOT EXISTS abc_document_config(id INT PRIMARY KEY,revision INT UNSIGNED NOT NULL DEFAULT 1,template_json LONGTEXT NOT NULL,logo_bytes MEDIUMBLOB NULL,logo_mime VARCHAR(20) NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
 $db->exec("CREATE TABLE IF NOT EXISTS abc_print_template_versions(id INT AUTO_INCREMENT PRIMARY KEY,revision INT UNSIGNED NOT NULL UNIQUE,template_json LONGTEXT NOT NULL,logo_bytes MEDIUMBLOB NULL,logo_mime VARCHAR(20) NULL,created_by INT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(created_by) REFERENCES users(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
 $s=$db->prepare('INSERT IGNORE INTO abc_document_config(id,template_json) VALUES(1,?)');$s->execute([json_encode(d_defaults(),JSON_UNESCAPED_UNICODE)]);
 $db->exec('INSERT IGNORE INTO abc_print_template_versions(revision,template_json,logo_bytes,logo_mime) SELECT revision,template_json,logo_bytes,logo_mime FROM abc_document_config WHERE id=1');
}
function d_config(?int $revision=null): array {
 $r=$revision?query('SELECT * FROM abc_print_template_versions WHERE revision=?',[$revision])->fetch():query('SELECT * FROM abc_document_config WHERE id=1')->fetch();if(!$r)fail('Verze tiskové šablony neexistuje.',404);$r['template']=array_replace(d_defaults(),json_decode($r['template_json'],true)?:[]);return $r;
}
function d_may_view(array $u): bool {return abc_perm($u,'view_documents')||abc_perm($u,'manage_documents');}
function d_require_view(array $u): void {if(!d_may_view($u))fail('Nemáš právo zobrazit dokumenty.',403);}
function d_get(int $id,array $u,?int $version=null): array {
 d_require_view($u);$d=query('SELECT d.*,v.id version_id,v.version,v.title,v.category,v.staff_visible,v.filename,v.byte_size,v.sha256,v.created_at version_at FROM abc_documents d JOIN abc_document_versions v ON v.document_id=d.id AND v.version=d.revision WHERE d.id=?',[$id])->fetch();if(!$d)fail('Dokument neexistuje.',404);
 if(!$d['active']&&!abc_perm($u,'manage_documents'))fail('Dokument není dostupný.',403);
 if($d['job_id'])get_job((int)$d['job_id'],$u);
 elseif(!$d['staff_visible']&&!abc_perm($u,'manage_documents'))fail('Dokument není určen pro tento účet.',403);
 if($version!==null){$v=query('SELECT id version_id,version,title,category,staff_visible,filename,byte_size,sha256,created_at version_at FROM abc_document_versions WHERE document_id=? AND version=?',[$id,$version])->fetch();if(!$v)fail('Verze dokumentu neexistuje.',404);if(!$d['job_id']&&!$v['staff_visible']&&!abc_perm($u,'manage_documents'))fail('Tato verze není dostupná.',403);$d=array_replace($d,$v);}
 return $d;
}
function d_list(array $u,?int $job=null,?int $vehicle=null): array {
 d_require_view($u);if($job)get_job($job,$u);[$where,$args]=a_job_where($u,'j');$manage=abc_perm($u,'manage_documents');
 $sql='SELECT d.id FROM abc_documents d JOIN abc_document_versions v ON v.document_id=d.id AND v.version=d.revision LEFT JOIN jobs j ON j.id=d.job_id WHERE '.($manage?'1=1':'d.active=1')." AND ((d.job_id IS NULL AND ".($manage?'1=1':'v.staff_visible=1').') OR (d.job_id IS NOT NULL AND '.$where.'))';
 if($job){$sql.=' AND d.job_id=?';$args[]=$job;}elseif($vehicle){$sql.=' AND d.vehicle_id=?';$args[]=$vehicle;}
 $sql.=' ORDER BY d.id DESC';$rows=[];foreach(query($sql,$args)->fetchAll() as $r)$rows[]=d_get((int)$r['id'],$u);return $rows;
}
function d_upload(array $file): array {
 if(($file['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK){if(in_array($file['error']??0,[UPLOAD_ERR_INI_SIZE,UPLOAD_ERR_FORM_SIZE],true))fail('PDF překračuje limit serveru (max. 5 MB v aplikaci).',413);fail('PDF nebylo nahrané. Vyber soubor znovu.');}
 $tmp=$file['tmp_name']??'';if(!is_string($tmp)||!is_uploaded_file($tmp))fail('Neplatný nahraný soubor.');$size=filesize($tmp);if(!$size||$size>D_MAX_PDF)fail('PDF musí mít nejvýše 5 MB.',413);
 $name=basename(str_replace('\\','/',(string)($file['name']??'')));if(strtolower(pathinfo($name,PATHINFO_EXTENSION))!=='pdf')fail('Podporované jsou pouze PDF soubory.',415);
 $bytes=file_get_contents($tmp);if($bytes===false||strlen($bytes)!==$size)fail('Soubor nelze bezpečně přečíst.',503);
 if(!class_exists('finfo'))fail('Na serveru chybí PHP Fileinfo. Soubor nebyl uložen.',503);
 $mime=(new finfo(FILEINFO_MIME_TYPE))->buffer($bytes);if($mime!=='application/pdf'||!preg_match('/^%PDF-(?:1\.[0-9]|2\.0)/',$bytes)||!str_contains(substr($bytes,-2048),'%%EOF'))fail('Soubor není platné podporované PDF.',415);
 if(preg_match('~/\s*(?:JavaScript|JS|Launch|EmbeddedFile|RichMedia|OpenAction|XFA)\b~i',$bytes))fail('PDF s aktivními akcemi nebo vloženými soubory není podporované.',415);
 return ['bytes'=>$bytes,'size'=>$size,'name'=>mb_substr($name,0,200),'sha256'=>hash('sha256',$bytes)];
}
function d_logo(array $file): array {
 if(($file['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK)fail('Logo se nepodařilo nahrát.');$tmp=$file['tmp_name']??'';if(!is_uploaded_file($tmp)||filesize($tmp)>524288)fail('Logo PNG/JPEG může mít nejvýše 512 kB.');
 $bytes=file_get_contents($tmp);$size=@getimagesizefromstring($bytes);if(!class_exists('finfo'))fail('Na serveru chybí PHP Fileinfo. Logo nebylo uloženo.',503);$mime=(new finfo(FILEINFO_MIME_TYPE))->buffer($bytes);if(!$size||!in_array($mime,['image/png','image/jpeg'],true)||$size[0]>4096||$size[1]>4096)fail('Logo musí být PNG/JPEG nejvýše 4096 × 4096 px.');return [$bytes,$mime];
}
/** Obsah i metadata jsou jeden COMMIT klientské DB; nepřesouváme soubor do webového adresáře. */
function d_save(array $u,array $p,?array $upload): array {
 permission($u,'manage_documents');$id=empty($p['id'])?0:positive_id($p['id']);$old=null;
 if($id){query('SELECT id FROM abc_documents WHERE id=? FOR UPDATE',[$id]);$old=d_get($id,$u);card_version($p,(int)$old['revision'],'document',$old);}
 $job=$old?($old['job_id']?(int)$old['job_id']:null):(empty($p['job_id'])?null:positive_id($p['job_id']));
 if($old&&array_key_exists('job_id',$p)&&(int)($p['job_id']?:0)!==(int)$old['job_id'])fail('Dokument nelze přesunout pod jinou zakázku.');
 if($job)get_job($job,$u);$category=post_str($p,'category',20);if($job)$category='attachment';elseif(!in_array($category,['form','price_list','other'],true))fail('Vyber kategorii dokumentu.');
 $title=post_str($p,'title',180);if(mb_strlen($title)<2)fail('Vyplň název dokumentu.');$staff=!empty($p['staff_visible'])?1:0;$active=!empty($p['active'])?1:0;
 if(!$upload){if(!$old)fail('Vyber PDF soubor.');$row=query('SELECT pdf_bytes FROM abc_document_versions WHERE id=?',[$old['version_id']])->fetch();$upload=['bytes'=>$row['pdf_bytes'],'size'=>$old['byte_size'],'name'=>$old['filename'],'sha256'=>$old['sha256']];}
 $vehicle=$job?query('SELECT vehicle_id FROM crm_vehicle_jobs WHERE job_id=?',[$job])->fetchColumn():null;
 if(!$id){query('INSERT INTO abc_documents(job_id,vehicle_id,active,created_by) VALUES(?,?,?,?)',[$job,$vehicle?:null,$active,$u['id']]);$id=(int)db()->lastInsertId();$version=1;}
 else{$version=(int)$old['revision']+1;query('UPDATE abc_documents SET revision=?,active=? WHERE id=?',[$version,$active,$id]);}
 query('INSERT INTO abc_document_versions(document_id,version,title,category,staff_visible,filename,byte_size,sha256,pdf_bytes,created_by) VALUES(?,?,?,?,?,?,?,?,?,?)',[$id,$version,$title,$category,$staff,$upload['name'],$upload['size'],$upload['sha256'],$upload['bytes'],$u['id']]);
 log_event((int)$u['id'],$job??0,'document_version','#'.$id.' verze '.$version,['sha256'=>$upload['sha256'],'bytes'=>$upload['size'],'title'=>$title,'category'=>$category,'active'=>$active,'staff_visible'=>$staff]);return ['id'=>$id,'version'=>$version];
}
function d_save_template(array $u,array $p,?array $logo): void {
 permission($u,'manage_documents');$old=query('SELECT * FROM abc_document_config WHERE id=1 FOR UPDATE')->fetch();card_version($p,(int)$old['revision'],'print_template',['revision'=>$old['revision']]);$t=d_defaults();$t['title']=post_str($p,'title',100);if(!$t['title'])fail('Vyplň název formuláře.');$t['footer']=post_str($p,'footer',2000);
 foreach(['show_vin','show_mileage','show_phone'] as $k)$t[$k]=!empty($p[$k]);foreach(['work_rows','material_rows'] as $k){$n=filter_var($p[$k]??null,FILTER_VALIDATE_INT,['options'=>['min_range'=>2,'max_range'=>20]]);if(!$n)fail('Počet řádků formuláře je 2–20.');$t[$k]=$n;}
 [$bytes,$mime]=$logo??[!empty($p['remove_logo'])?null:$old['logo_bytes'],!empty($p['remove_logo'])?null:$old['logo_mime']];$json=json_encode($t,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);$rev=(int)$old['revision']+1;
 query('UPDATE abc_document_config SET revision=?,template_json=?,logo_bytes=?,logo_mime=? WHERE id=1',[$rev,$json,$bytes,$mime]);query('INSERT INTO abc_print_template_versions(revision,template_json,logo_bytes,logo_mime,created_by) VALUES(?,?,?,?,?)',[$rev,$json,$bytes,$mime,$u['id']]);log_event((int)$u['id'],0,'print_template_changed','Verze '.$rev,['before'=>json_decode($old['template_json'],true),'after'=>$t]);
}
