<?php
declare(strict_types=1);
/** Veřejná cesta cookie; na WEDOSu může SCRIPT_NAME obsahovat interní /domains/. */
function abc_cookie_path(string $requestUri): string {
    if(preg_match('/[\x00-\x20\x7f]/',$requestUri))return '/';
    $path=parse_url($requestUri,PHP_URL_PATH);
    if(!is_string($path)||$path===''||$path[0]!=='/'||preg_match('/[\x00-\x20\x7f;,\\\\]/',$path))return '/';
    if(!str_ends_with($path,'/'))$path=dirname($path);
    return rtrim($path,'/').'/';
}
date_default_timezone_set('Europe/Prague');
ini_set('display_errors', '0');
ini_set('session.use_strict_mode', '1');
ini_set('session.gc_maxlifetime','28800');
$publicSessionPath=abc_cookie_path($_SERVER['REQUEST_URI']??'/');
$sessionArea=in_array(basename($_SERVER['SCRIPT_FILENAME']??''),['platform.php','platform_setup.php'],true)?'platform':'service';
session_name('abc_dilna_v310_'.substr(hash('sha256',$publicSessionPath.$sessionArea),0,10));
$secure = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
$cookiePath=abc_cookie_path($_SERVER['REQUEST_URI']??'/');
session_set_cookie_params(['httponly'=>true,'secure'=>$secure,'samesite'=>'Lax','path'=>$cookiePath]);
// Opožděný API požadavek po odhlášení nesmí novou anonymní cookie přepsat
// právě vytvořenou přihlašovací relaci. Cookie vydávají běžné HTML vstupy.
$apiSession=str_contains(basename($_SERVER['SCRIPT_FILENAME']??''),'api.php')||str_contains($_SERVER['CONTENT_TYPE']??'','application/json')||str_contains($_SERVER['HTTP_ACCEPT']??'','application/json');
if($apiSession){$sid=$_COOKIE[session_name()]??null;if(is_string($sid)&&preg_match('/^[a-zA-Z0-9,-]{16,256}$/D',$sid))session_id($sid);}
if(!session_start($apiSession?['use_cookies'=>false]:[])){http_response_code(503);exit('Úložiště přihlašovacích relací není dostupné. Ověř session.save_path a oprávnění serveru.');}
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');
header('X-Frame-Options: SAMEORIGIN');
header('Cache-Control: no-store, private');
header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'self'; base-uri 'self'; form-action 'self'");
$defaults = [
    'db_host'=>'localhost','db_port'=>3306,'db_name'=>'','db_user'=>'','db_password'=>'','setup_token'=>'',
    'company_name'=>'ABC Autoslužby','company_address'=>'Petrohradská 216, Praha 10',
    'company_ico'=>'01460544','company_phone'=>'774 204 450','company_email'=>'','company_bank_account'=>'',
    'openai_api_key'=>'','openai_estimate_model'=>'gpt-4.1-mini',
];
$defaults+=['saas_enabled'=>false,'platform_db_host'=>'localhost','platform_db_port'=>3306,'platform_db_name'=>'','platform_db_user'=>'','platform_db_password'=>'','platform_secret'=>'','platform_setup_token'=>'','company_vat'=>false,'company_dic'=>''];
$config = $defaults;
if (is_file(__DIR__.'/config.php')) $config = array_replace($config, require __DIR__.'/config.php');
// Proměnné prostředí mají přednost; využívá je také automatické ověření.
foreach (['db_host','db_port','db_name','db_user','db_password','setup_token','saas_enabled','platform_db_host','platform_db_port','platform_db_name','platform_db_user','platform_db_password','platform_secret','platform_setup_token'] as $name) {
    $env = getenv('ABC_'.strtoupper($name));
    if ($env !== false) $config[$name] = $env;
}
set_exception_handler(static function(Throwable $e): void {
    error_log('ABC Dílna: '.$e->getMessage());
    fail('Operaci se nepodařilo dokončit. Zkontroluj konfiguraci a instalaci databáze.', 500);
});
function is_api(): bool {
    return str_contains(basename($_SERVER['SCRIPT_NAME']??''),'api.php') ||
        str_contains($_SERVER['CONTENT_TYPE']??'','application/json') ||
        str_contains($_SERVER['HTTP_ACCEPT']??'','application/json');
}
function e($s): string { return htmlspecialchars((string)($s??''), ENT_QUOTES|ENT_SUBSTITUTE, 'UTF-8'); }
function fail(string $message, int $status=400,array $details=[]): never {
    foreach(['abc_db','abc_platform_db'] as $connection){$conn=$GLOBALS[$connection]??null;if($conn instanceof PDO&&$conn->inTransaction())$conn->rollBack();}
    http_response_code($status);
    if (is_api()) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['ok'=>false,'error'=>$message]+$details,JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE);
    } else {
        header('Content-Type: text/html; charset=utf-8');
        echo '<!doctype html><html lang="cs"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>ABC Dílna</title><link rel="stylesheet" href="assets/mechanic.css"><main class="main-wrap surface"><h1>ABC Dílna</h1><p>'.e($message).'</p><a class="button" href="index.php">Zpět na úvod</a></main></html>';
    }
    exit;
}
function json_ok(array $data=[]): never {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok'=>true]+$data,JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}
function db(): PDO {
    global $config;
    if (isset($GLOBALS['abc_db'])) return $GLOBALS['abc_db'];
    if (!$config['db_name'] || !$config['db_user']) fail('Nejprve nastav databázi v app/config.php a otevři setup.php.',503);
    $dsn='mysql:host='.$config['db_host'].';port='.(int)$config['db_port'].';dbname='.$config['db_name'].';charset=utf8mb4';
    $p=new PDO($dsn,(string)$config['db_user'],(string)$config['db_password'],[
        PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES=>false,
    ]);
    $p->exec("SET time_zone = ".$p->quote(date('P')));
    $GLOBALS['abc_db']=$p;
    return $p;
}
function query(string $sql, array $values=[]): PDOStatement {
    $s=db()->prepare($sql);$s->execute($values);return $s;
}
function csrf(): string {
    return $_SESSION['csrf']??=bin2hex(random_bytes(32));
}
function require_csrf(): void {
    $token=$_SERVER['HTTP_X_CSRF_TOKEN']??$_POST['csrf']??'';
    if (!is_string($token)||!hash_equals(csrf(),$token)) fail('Platnost formuláře vypršela. Obnov stránku.',403);
}
function db_scope(): string {global $config;return hash('sha256',implode('|',[$config['db_host'],$config['db_port'],$config['db_name'],$config['db_user'],$config['tenant_key']??'single']));}
function login_required(): array {
    if(!empty($_SESSION['user_id'])&&!hash_equals(db_scope(),(string)($_SESSION['db_scope']??''))){$_SESSION=[];session_regenerate_id(true);}
    if(isset($_SERVER['HTTP_X_ABC_SCOPE'])&&!hash_equals(db_scope(),(string)$_SERVER['HTTP_X_ABC_SCOPE']))fail('V tomto prohlížeči je otevřený jiný servis. Obnov stránku.',409);
    $id=(int)($_SESSION['user_id']??0);
    $u=$id?query('SELECT * FROM users WHERE id=? AND active=1',[$id])->fetch():false;
    if($u&&(int)($_SESSION['session_version']??0)!==(int)$u['session_version']) {$_SESSION=[];session_regenerate_id(true);$u=false;}
    if (!$u) {
        if (is_api()) fail('Přihlas se znovu.',401);
        header('Location: index.php');exit;
    }
    if (time()-(int)($_SESSION['last_seen']??time())>28800) {
        $_SESSION=[];session_regenerate_id(true);fail('Přihlášení vypršelo.',401);
    }
    $_SESSION['last_seen']=time();
    if(basename($_SERVER['SCRIPT_FILENAME']??'')!=='upgrade.php'&&!query("SELECT version FROM schema_meta WHERE version='3.0.0'")->fetchColumn()){if(is_api())fail('Je nutná přidávací migrace 3.0. Otevři upgrade.php jako majitel.',503);header('Location: upgrade.php');exit;}
    if(basename($_SERVER['SCRIPT_FILENAME']??'')!=='upgrade.php'&&!query('SELECT version FROM schema_meta WHERE version=?',[ABC_A12_SCHEMA])->fetchColumn()){
        if(is_api())fail('Je potřeba migrace Etapy A. Majitel otevře upgrade.php na testovací kopii.',503,['code'=>'upgrade_required']);
        redirect('upgrade.php');
    }
    if(basename($_SERVER['SCRIPT_FILENAME']??'')!=='upgrade.php'&&!query('SELECT version FROM schema_meta WHERE version=?',[ABC_A_SCHEMA])->fetchColumn()){if(is_api())fail('Je potřeba dokončit migraci Etapy A.',503,['code'=>'upgrade_required']);redirect('upgrade.php');}
    return $u;
}
function require_role(array $u,array $roles): void {
    if (!in_array($u['role'],$roles,true)) fail('K této části nemáš přístup.',403);
}
function abc_perm(array $u,string $name): bool {
    if ($u['role']==='owner') return true;
    $perms=is_array($u['permissions']??null)?$u['permissions']:json_decode($u['permissions']??'[]',true);
    return in_array($name,is_array($perms)?$perms:[],true);
}
function permission(array $u,string $name): void {
    if (!abc_perm($u,$name)) fail('K této operaci nemáš oprávnění.',403);
}
function get_job(int $id,array $u): array {
    $j=query('SELECT * FROM jobs WHERE id=?',[$id])->fetch();
    if (!$j) fail('Zakázka neexistuje.',404);
    if(!a_can_view($u,$j))fail('K zakázce nemáš přístup.',403);
    return $j;
}
function post_str(array $p,string $key,int $max): string {
    $v=$p[$key]??'';
    if (!is_scalar($v)&&$v!==null) fail('Neplatná hodnota: '.$key);
    $v=trim((string)$v);
    if (mb_strlen($v)>$max) fail('Příliš dlouhá hodnota: '.$key);
    return $v;
}
function positive_id($v): int {
    $id=filter_var($v,FILTER_VALIDATE_INT,['options'=>['min_range'=>1]]);
    if (!$id) fail('Neplatné číslo záznamu.');
    return (int)$id;
}
function money($v,string $label='částka'): float {
    if (!is_scalar($v)) fail('Neplatná '.$label.'.');
    $s=str_replace(',','.',trim((string)$v));
    if (!preg_match('/^\d{1,7}(?:\.\d{1,2})?$/D',$s)||(float)$s>2000000) fail('Neplatná '.$label.'.');
    return round((float)$s,2);
}
function qty($v): float {
    if (!is_scalar($v)) fail('Neplatné množství.');
    $s=str_replace(',','.',trim((string)$v));
    if (!preg_match('/^\d{1,6}(?:\.\d{1,3})?$/D',$s)||(float)$s<=0||(float)$s>10000) fail('Neplatné množství.');
    return (float)$s;
}
function totals(int $id): array {
    return card_totals($id);
}
function log_event(int $user,int $job,string $action,string $detail='',?array $data=null): void {
    query('INSERT INTO events(user_id,job_id,action,detail,data_json,source) VALUES (?,?,?,?,?,?)',[$user,$job?:null,$action,mb_substr($detail,0,500),$data===null?null:json_encode($data,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR),basename($_SERVER['SCRIPT_FILENAME']??'cli')]);
}
function payload(): array {
    if (($_SERVER['REQUEST_METHOD']??'GET')!=='POST') fail('Použij POST.',405);
    require_csrf();
    $p=json_decode(file_get_contents('php://input'),true);
    if (!is_array($p)) fail('Neplatná data.');
    return $p;
}
function auth_payload(array $u): array {
    return ['vat'=>!empty($GLOBALS['config']['company_vat']),'scope'=>db_scope(),'csrf'=>csrf(),'user'=>['id'=>(int)$u['id'],'name'=>$u['name'],'role'=>$u['role']],
        'settings'=>a_settings(),'can_price'=>abc_perm($u,'price_jobs'),'permissions'=>json_decode($u['permissions'],true)??[],
        'staff'=>(abc_perm($u,'share_jobs')||abc_perm($u,'assign_jobs'))?query('SELECT id,name FROM users WHERE active=1 ORDER BY name')->fetchAll():[]];
}
function flash(string $text): void { $_SESSION['flash']=$text; }
function redirect(string $path): never { header('Location: '.$path);exit; }
function czmoney($v): string { return number_format((float)$v,2,',',' ').' Kč'; }

require_once __DIR__.'/operations.php';
require_once __DIR__.'/work_card.php';
require_once __DIR__.'/phase_a.php';

require_once __DIR__.'/saas.php';
saas_bootstrap();
