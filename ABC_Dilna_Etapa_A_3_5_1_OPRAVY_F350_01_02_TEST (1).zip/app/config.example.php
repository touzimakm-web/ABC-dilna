<?php
// Zkopírujte jako config.php. Nezveřejňujte tento vyplněný soubor.
// Jeden společný PHP projekt, samostatná databáze platformy + databáze každého servisu.
return [
    'saas_enabled' => true,
    'platform_db_host' => 'DATABAZOVY_SERVER_WEDOS',
    'platform_db_port' => 3306,
    'platform_db_name' => 'NOVA_PRAZDNA_DATABAZE_PLATFORMY',
    'platform_db_user' => 'UZIVATEL_POUZE_TETO_DATABAZE',
    'platform_db_password' => 'HESLO_DATABAZE_PLATFORMY',
    // Jednou vygenerujte v generator_klicu.html a vložte hotové hodnoty.
    // Nepoužívejte zde random_bytes(): klíč musí zůstávat STEJNÝ při každém načtení.
    'platform_secret' => 'VLOZTE_64_HEXADECIMALNICH_ZNAKU',
    'platform_setup_token' => 'VLOZTE_VLASTNI_INSTALACNI_KLIC',
    // Přístupy klientských databází přidává pouze provozovatel v platform.php.
    // Údaje na dokladech si každý majitel nastaví ve vlastním účtu.
    'db_host' => 'localhost',
    'db_port' => 3306,
    'db_name' => '',
    'db_user' => '',
    'db_password' => '',
    'setup_token' => '',
    'company_name' => '',
    'company_address' => '',
    'company_ico' => '',
    'company_dic' => '',
    'company_vat' => false,
    'company_phone' => '',
    'company_email' => '',
    'company_bank_account' => '',
    'openai_api_key' => '',
    'openai_estimate_model' => 'gpt-4.1-mini',
];
