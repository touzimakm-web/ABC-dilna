<?php
declare(strict_types=1);

/** Nastavitelné obecné pracovní požadavky. Nejsou ceník ani kompatibilita dílů. */
function a_manual_templates(): array {
    $row=static fn(string $kind,string $name,$quantity=1,string $unit='úkon')=>['kind'=>$kind,'description'=>$name,'quantity'=>$quantity,'unit'=>$unit];
    $templates=[];
    $add=static function(string $code,string $category,string $label,array $rows,string $group='')use(&$templates): void {$templates[]=['code'=>$code,'category'=>$category,'label'=>$label,'exclusive_group'=>$group,'rows'=>$rows];};
    $add('oil-change','Oleje a filtry','Výměna motorového oleje',[$row('labor','Výměna motorového oleje')]);
    $add('oil-material','Oleje a filtry','Motorový olej',[$row('part','Motorový olej',1,'l')]);
    foreach(['oil'=>'Olejový','air'=>'Vzduchový','cabin'=>'Kabinový','fuel'=>'Palivový'] as $code=>$label)$add($code.'-filter','Oleje a filtry',$label.' filtr',[$row('part',$label.' filtr',1,'ks')]);
    foreach(['front'=>['Přední','předních'],'rear'=>['Zadní','zadních']] as $side=>[$label,$gen]){
        $disc=$row('part',$label.' brzdové kotouče',2,'ks');$pads=$row('part',$label.' brzdové destičky',1,'sada');
        $add('brakes-'.$side.'-both','Brzdy',$label.' kotouče a destičky',[$row('labor','Výměna '.$gen.' kotoučů a destiček'),$disc,$pads],'brakes-'.$side);
        $add('brakes-'.$side.'-pads','Brzdy',$label.' destičky',[$row('labor','Výměna '.$gen.' brzdových destiček'),$pads],'brakes-'.$side);
        $add('brakes-'.$side.'-discs','Brzdy',$label.' kotouče',[$row('labor','Výměna '.$gen.' brzdových kotoučů'),$disc],'brakes-'.$side);
    }
    $left=$row('part','Levé rameno',1,'ks');$right=$row('part','Pravé rameno',1,'ks');
    $add('arm-left','Podvozek','Rameno – levé',[$row('labor','Výměna levého ramene'),$left],'suspension-arms');
    $add('arm-right','Podvozek','Rameno – pravé',[$row('labor','Výměna pravého ramene'),$right],'suspension-arms');
    $add('arm-both','Podvozek','Ramena – obě strany',[$row('labor','Výměna obou ramen'),$left,$right],'suspension-arms');
    $add('diagnostics','Diagnostika','Diagnostika',[$row('labor','Diagnostika')]);
    return $templates;
}

function a_validate_templates($value): array {
    if(!is_array($value)||!array_is_list($value)||count($value)>100)fail('Neplatné pracovní šablony.');
    $result=[];$codes=[];
    foreach($value as $t){
        if(!is_array($t))fail('Neplatná pracovní šablona.');
        $code=post_str($t,'code',60);$category=post_str($t,'category',80);$label=post_str($t,'label',100);$group=post_str($t,'exclusive_group',80);
        if(!preg_match('/^[A-Za-z0-9_-]{3,60}$/D',$code)||isset($codes[$code])||!$category||!$label)fail('Šablona vyžaduje jednoznačný kód, kategorii a název.');
        $rows=$t['rows']??null;if(!is_array($rows)||!array_is_list($rows)||!$rows||count($rows)>12)fail('Šablona musí obsahovat 1–12 řádků.');
        $lines=[];foreach($rows as $r){
            if(!is_array($r))fail('Neplatný řádek šablony.');$kind=post_str($r,'kind',10);$desc=post_str($r,'description',220);if(!in_array($kind,['labor','part'],true)||mb_strlen($desc)<2)fail('Vyplň typ a název řádku šablony.');
            $cid=empty($r['catalog_id'])?null:positive_id($r['catalog_id']);$unit=card_unit($r['unit']??($kind==='labor'?'úkon':'ks'));
            if($cid){$c=c_row($cid);if($c['kind']!==$kind||$c['unit']!==$unit)fail('Druh a jednotka řádku musí odpovídat jeho ceníku.');}
            $raw=$r['quantity']??null;$q=$unit==='hod'&&($raw===null||$raw==='')?null:qty($raw??1);if($q!==null&&$q>1000)fail('Množství šablony je nejvýše 1000.');
            $line=['kind'=>$kind,'description'=>$desc,'quantity'=>$q,'unit'=>$unit];if($cid)$line['catalog_id']=$cid;$lines[]=$line;
        }
        $codes[$code]=true;$result[]=['code'=>$code,'category'=>$category,'label'=>$label,'exclusive_group'=>$group,'rows'=>$lines];
    }
    return $result;
}

function a_apply_manual_plan(array $u,array $j,$selection): array {
    if($selection===null)return [];
    a_edit($u,'edit_lines');
    if(!is_array($selection))fail('Neplatný výběr plánovaných úkonů.');
    $settings=c_locked_settings();card_version($selection,(int)$settings['revision'],'templates',['revision'=>$settings['revision']]);
    $codes=$selection['codes']??null;if(!is_array($codes)||!array_is_list($codes)||!$codes||count($codes)>24)fail('Vyber 1–24 úkonů.');
    $map=array_column($settings['service_templates'],null,'code');$seen=[];$groups=[];$rows=[];$quantities=$selection['quantities']??[];if(!is_array($quantities))fail('Neplatná množství.');foreach($quantities as $overrides)if(!is_array($overrides))fail('Neplatná množství šablony.');
    foreach($codes as $code){
        if(!is_string($code)||isset($seen[$code])||!isset($map[$code]))fail('Pracovní výběr se změnil. Obnov nabídku a zkontroluj rozepsaný výběr.',409);
        $t=$map[$code];$seen[$code]=true;$group=$t['exclusive_group'];
        if($group&&isset($groups[$group]))fail('Vybrané alternativy téže opravy se překrývají. Vyber jednu variantu.',409);
        if($group)$groups[$group]=true;
        if(query("SELECT id FROM abc_quick_tasks WHERE job_id=? AND status<>'cancelled' AND (plan_code=? OR (?<>'' AND plan_group=?)) LIMIT 1",[$j['id'],$code,$group,$group])->fetch())fail('Tato oprava už na kartě je. Uprav její stávající řádky; nevytvářej druhé účtování.',409);
        foreach($t['rows'] as $i=>$line){$overrides=$quantities[$code]??[];$raw=array_key_exists($i,$overrides)?$overrides[$i]:$line['quantity'];$q=card_quantity($raw,$line['kind'],$line['unit']);$rows[]=[$t,$line,$q];}
    }
    if(count($rows)>100)fail('Najednou lze potvrdit nejvýše 100 řádků.');
    $ids=[];foreach($rows as [$t,$line,$q]){
        $c=null;$item=null;$price=null;if(!empty($line['catalog_id'])){$c=c_row((int)$line['catalog_id'],true);c_check($c,$selection['catalog_revisions'][$c['id']]??null);if($c['kind']!==$line['kind']||$c['unit']!==$line['unit'])fail('Změnil se druh nebo jednotka ceníkové položky. Uprav vazbu karty.',409);$price=$c['unit_price'];query('INSERT INTO items(job_id,kind,description,quantity,unit,unit_price,unit_cost) VALUES(?,?,?,?,?,?,?)',[$j['id'],$line['kind'],$line['description'],$q,$line['unit'],$price,$c['unit_cost']]);$item=(int)db()->lastInsertId();}
        query("INSERT INTO abc_quick_tasks(job_id,category,description,kind,quantity,unit,status,item_id,created_by,entry_type,plan_code,plan_group) VALUES (?,?,?,?,?,?,'planned',NULL,?,'work',?,?)",[$j['id'],$t['category'],$line['description'],$line['kind'],$q,$line['unit'],$u['id'],$t['code'],$t['exclusive_group']]);
        $id=(int)db()->lastInsertId();$ids[]=$id;if($item)query('UPDATE abc_quick_tasks SET item_id=? WHERE id=?',[$item,$id]);c_source($id,$c,$c?'catalog':'unknown');price_history($u,(int)$j['id'],$id,null,$price,$q,'planned_template');
    }
    card_touch($u,$j,'Potvrzený ruční výběr úkonů',true);
    log_event((int)$u['id'],(int)$j['id'],'manual_plan','Potvrzeny plánované úkony',['codes'=>$codes,'line_ids'=>$ids,'templates_revision'=>$settings['revision']]);
    return $ids;
}

function a_tyre_components(string $operation,bool $balance): array {
    $components=match($operation){'complete'=>['wheel_remove_fit','tyre_remove_fit'],'swap'=>['wheel_remove_fit'],'balance'=>[],default=>[]};
    if($balance||$operation==='balance')$components[]='wheel_balance';return $components;
}
function a_wheel_set_key(string $name): string {return hash('sha256',mb_strtolower(preg_replace('/\s+/u',' ',trim($name))));}
function a_tyre_scope(array $p,int $job,string $operation,bool $balance): array {
    $set=post_str($p,'wheel_set',100)?:'Na vozidle';$reason=post_str($p,'repeat_reason',300);$repeat=!empty($p['repeat_confirmed']);
    if($repeat&&mb_strlen($reason)<5)fail('Pro další opakovanou práci napiš konkrétní důvod (alespoň 5 znaků).');
    if($reason&&!$repeat)fail('Další opakovaný úkon musíš výslovně potvrdit.');
    $components=a_tyre_components($operation,$balance);$setKey=a_wheel_set_key($set);
    $old=query("SELECT id,description,bundle_meta FROM abc_quick_tasks WHERE job_id=? AND bundle_key IS NOT NULL AND kind='labor' AND status<>'cancelled'",[$job])->fetchAll();
    $overlaps=[];foreach($old as $r){$meta=json_decode($r['bundle_meta']??'null',true);$same=!$meta||($meta['wheel_set_key']??a_wheel_set_key('Na vozidle'))===$setKey;
        if($same&&(!$meta||in_array('*',$meta['components']??['*'],true)||array_intersect($components,$meta['components']??[])))$overlaps[]=['id'=>$r['id'],'description'=>$r['description']];}
    if($overlaps&&!$repeat)fail('Tato sada kol už má část služby na kartě. Zkontroluj řádky; pro jinou sadu uveď její název, pro skutečně opakovanou práci potvrď důvod.',409,['code'=>'tyre_overlap','lines'=>$overlaps]);
    return ['wheel_set'=>$set,'wheel_set_key'=>$setKey,'components'=>$components,'repeat_reason'=>$repeat?$reason:'','repeat_confirmed'=>$repeat];
}

/** Přidávací oprava 3.3.0; všechny finanční snímky a staré rezervace zachová. */
function a_migrate_331(PDO $db): void {
    $add=['jobs'=>['work_day'=>'DATE NULL'],'abc_quick_tasks'=>['plan_code'=>'VARCHAR(60) NULL','plan_group'=>'VARCHAR(80) NULL','bundle_meta'=>'LONGTEXT NULL']];
    foreach($add as $table=>$columns){$found=array_column($db->query('SHOW COLUMNS FROM `'.$table.'`')->fetchAll(),'Field');foreach($columns as $name=>$sql)if(!in_array($name,$found,true))$db->exec('ALTER TABLE `'.$table.'` ADD COLUMN `'.$name.'` '.$sql);}
    if(!$db->query("SHOW INDEX FROM jobs WHERE Key_name='job_work_day_idx'")->fetch())$db->exec('ALTER TABLE jobs ADD INDEX job_work_day_idx(work_day)');
    $db->beginTransaction();
    try{
        $row=$db->query('SELECT * FROM abc_workshop_settings WHERE id=1 FOR UPDATE')->fetch();$settings=json_decode($row['settings_json'],true)?:[];$changed=false;
        foreach(['service_templates'=>a_manual_templates(),'tyre_van_runflat_exclusive'=>true] as $k=>$v)if(!array_key_exists($k,$settings)){$settings[$k]=$v;$changed=true;}
        if($changed){$s=$db->prepare('UPDATE abc_workshop_settings SET settings_json=?,revision=revision+1 WHERE id=1');$s->execute([json_encode($settings,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR)]);}
        $known=[];foreach($settings['tyres']??[] as $rule){$operation=$rule['operation'];$balance=$operation==='balance'||(bool)$rule['balance'];$key=hash('sha256',json_encode([$operation,$rule['vehicle'],(int)$rule['diameter'],$balance,(bool)$rule['runflat']]));$known[$key]=['operation'=>$operation,'components'=>a_tyre_components($operation,$balance)];}
        $rows=$db->query('SELECT id,bundle_key,kind FROM abc_quick_tasks WHERE bundle_key IS NOT NULL AND bundle_meta IS NULL')->fetchAll();$save=$db->prepare('UPDATE abc_quick_tasks SET bundle_meta=? WHERE id=? AND bundle_meta IS NULL');
        foreach($rows as $r){$meta=['wheel_set'=>'Na vozidle','wheel_set_key'=>a_wheel_set_key('Na vozidle'),'components'=>$r['kind']==='labor'?($known[$r['bundle_key']]['components']??['*']):[],'capture'=>'legacy_scope_from_330','scope_inferred'=>true];$save->execute([json_encode($meta,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR),$r['id']]);}
        $db->exec("INSERT IGNORE INTO schema_meta(version) VALUES ('3.3.1-a')");$db->commit();
    }catch(Throwable $e){if($db->inTransaction())$db->rollBack();throw $e;}
}
