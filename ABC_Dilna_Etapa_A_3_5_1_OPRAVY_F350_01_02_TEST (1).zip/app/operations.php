<?php
declare(strict_types=1);
function abc_canonical($value){if(!is_array($value))return $value;if(!array_is_list($value))ksort($value);foreach($value as &$v)$v=abc_canonical($v);return $value;}
/** Volá se uvnitř transakce. Unikátní klíč chrání i současné požadavky a opakované částečné platby. */
function operation_begin(array $u,string $action,array $p): array {
    $key=post_str($p,'request_key',80);if(!preg_match('/^[A-Za-z0-9_-]{16,80}$/D',$key))fail('Chybí klíč bezpečného uložení. Obnov stránku.',400);
    unset($p['request_key']);$hash=hash('sha256',json_encode(abc_canonical($p),JSON_UNESCAPED_UNICODE|JSON_PRESERVE_ZERO_FRACTION));
    try{query('INSERT INTO abc_request_keys(user_id,action,request_key,payload_hash) VALUES (?,?,?,?)',[$u['id'],$action,$key,$hash]);}
    catch(PDOException $ex){if($ex->getCode()!=='23000')throw $ex;$r=query('SELECT * FROM abc_request_keys WHERE user_id=? AND action=? AND request_key=? FOR UPDATE',[$u['id'],$action,$key])->fetch();if(!$r||!hash_equals($r['payload_hash'],$hash))fail('Stejný klíč byl použit pro jiná data. Načti aktuální stav zakázky.',409);if(!$r['response_json'])fail('Uložení ještě probíhá. Načti aktuální stav.',409);$response=json_decode($r['response_json'],true);db()->rollBack();json_ok($response);}
    return [(int)$u['id'],$action,$key];
}
function operation_store(array $op,array $response=[]): void {
    query('UPDATE abc_request_keys SET response_json=? WHERE user_id=? AND action=? AND request_key=?',[json_encode($response,JSON_UNESCAPED_UNICODE),...$op]);
}
function operation_commit(array $op,array $response=[]): never {operation_store($op,$response);db()->commit();json_ok($response);
}
function price_history(array $u,int $job,int $task,$old,$new,?float $quantity,string $action): void {query('INSERT INTO abc_price_history(job_id,task_id,user_id,old_price,new_price,quantity,action) VALUES (?,?,?,?,?,?,?)',[$job,$task,$u['id'],$old,$new,$quantity,$action]);}
