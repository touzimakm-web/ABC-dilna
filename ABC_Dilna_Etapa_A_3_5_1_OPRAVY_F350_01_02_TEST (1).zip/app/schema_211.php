<?php
// Sloupce skutečného kompletního schématu 2.1.1; před migrací se kontrolují všechny.
return [
    'users'=>['id','name','email','password_hash','role','permissions','active','session_version','created_at'],
    'crm_customers'=>['id','type','name','phone','email','address','ico','note','created_at'],
    'crm_vehicles'=>['id','customer_id','plate','vin','brand','model','mileage','created_at'],
    'jobs'=>['id','customer_name','customer_phone','plate','vehicle','vin','mileage','title','assigned_to','created_by','status','created_at','updated_at'],
    'crm_vehicle_jobs'=>['job_id','vehicle_id'],
    'items'=>['id','job_id','kind','description','quantity','unit_price','unit_cost'],
    'abc_quick_catalog'=>['id','category','description','kind','unit_price','unit_cost','active'],
    'abc_quick_tasks'=>['id','job_id','category','description','kind','quantity','status','item_id','created_by'],
    'office_appointments'=>['id','start_at','end_at','source','status','customer_name','customer_phone','customer_email','vehicle','plate','service','note','job_id','created_by','mechanic_id'],
    'office_invoices'=>['id','job_id','invoice_no','status','customer_name','customer_address','customer_ico','customer_email','issued_on','due_on','total','payment_method','lines_json','supplier_json','note','created_by','created_at'],
    'cash_handovers'=>['id','user_id','declared_amount','status','submitted_at','accepted_at','accepted_by'],
    'payments'=>['id','job_id','user_id','amount','method','handover_id','created_at'],
    'notes'=>['id','job_id','user_id','kind','body','created_at'],
    'part_requests'=>['id','job_id','user_id','description','quantity','state','created_at'],
    'abc_job_estimates'=>['id','job_id','created_by','lower_total','upper_total','lines_json','note','origin','created_at'],
    'events'=>['id','user_id','job_id','action','detail','created_at'],
    'login_attempts'=>['id','email_hash','ip_hash','attempted_at'],
    'schema_meta'=>['version','installed_at'],
];
