<?php
declare(strict_types=1);
/** Pouze přidávací migrace známého schématu 2.1.x. Nikdy neodstraňuje provozní řádky. */
function abc_migrate_v300(PDO $db): array {
    $required=require __DIR__.'/schema_211.php';
    foreach($required as $table=>$columns){
        $s=$db->query('SHOW COLUMNS FROM `'.$table.'`');$found=array_column($s->fetchAll(),'Field');
        foreach($columns as $column)if(!in_array($column,$found,true))throw new RuntimeException('Neznámé schéma: '.$table.'.'.$column.'. Migrace nebyla provedena.');
    }
    $changes=[];
    $add=['jobs'=>['discount_amount'=>'DECIMAL(12,2) NOT NULL DEFAULT 0','discount_reason'=>"VARCHAR(200) NOT NULL DEFAULT ''"],
      'abc_quick_tasks'=>['entry_type'=>"VARCHAR(12) NOT NULL DEFAULT 'work'",'request_task_id'=>'INT NULL'],
      'payments'=>['receipt_no'=>'VARCHAR(40) NULL','snapshot_json'=>'LONGTEXT NULL'],
      'office_invoices'=>['discount_amount'=>'DECIMAL(12,2) NOT NULL DEFAULT 0']];
    foreach($add as $table=>$columns){$found=array_column($db->query('SHOW COLUMNS FROM `'.$table.'`')->fetchAll(),'Field');foreach($columns as $name=>$sql)if(!in_array($name,$found,true)){$db->exec('ALTER TABLE `'.$table.'` ADD COLUMN `'.$name.'` '.$sql);$changes[]=$table.'.'.$name;}}
    foreach(abc_v300_tables() as $sql)$db->exec($sql);
    $unique=$db->query("SHOW INDEX FROM payments WHERE Non_unique=0 AND Column_name='receipt_no'")->fetch();if(!$unique)$db->exec('ALTER TABLE payments ADD UNIQUE KEY abc_receipt_no_idx(receipt_no)');
    $db->exec("INSERT IGNORE INTO schema_meta(version) VALUES ('3.0.0')");
    return $changes;
}
function abc_v300_tables(): array {return [
 "CREATE TABLE IF NOT EXISTS abc_request_keys (user_id INT NOT NULL,action VARCHAR(60) NOT NULL,request_key VARCHAR(80) NOT NULL,payload_hash CHAR(64) NOT NULL,response_json LONGTEXT NULL,created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(user_id,action,request_key),FOREIGN KEY(user_id) REFERENCES users(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
 "CREATE TABLE IF NOT EXISTS abc_price_history (id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,job_id INT NOT NULL,task_id INT NOT NULL,user_id INT NOT NULL,old_price DECIMAL(12,2) NULL,new_price DECIMAL(12,2) NULL,quantity DECIMAL(10,3) NOT NULL,action VARCHAR(30) NOT NULL,created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(job_id) REFERENCES jobs(id),FOREIGN KEY(task_id) REFERENCES abc_quick_tasks(id),FOREIGN KEY(user_id) REFERENCES users(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
 ];}

/** M02: jen databáze konkrétního servisu, nikdy platformní databáze.
 * Opakované spuštění je bezpečné; starší položky práce byly počítány na úkony.
 */
function abc_migrate_m02(PDO $db): array {
    $changes=[];
    foreach(['items','abc_quick_tasks'] as $table){
        $found=array_column($db->query('SHOW COLUMNS FROM `'.$table.'`')->fetchAll(),'Field');
        if(!in_array('unit',$found,true)){
            $db->exec("ALTER TABLE `{$table}` ADD COLUMN unit VARCHAR(12) NULL DEFAULT NULL AFTER quantity");
            $changes[]=$table.'.unit';
        }
        $column=$db->query("SHOW COLUMNS FROM `{$table}` LIKE 'unit'")->fetch();
        if($column['Null']==='YES'){
            $db->exec("UPDATE `{$table}` SET unit=CASE WHEN kind='labor' THEN 'úkon' ELSE 'ks' END WHERE unit IS NULL");
            $db->exec("ALTER TABLE `{$table}` MODIFY unit VARCHAR(12) NOT NULL DEFAULT 'ks'");
        }
    }
    $db->exec("INSERT IGNORE INTO schema_meta(version) VALUES ('3.1.1-m02')");
    return $changes;
}

/** A1/A2: rozšiřuje pouze databázi konkrétního servisu, zachovává ID a doklady. */
require_once __DIR__.'/phase_a.php';
function abc_migrate_a12(PDO $db): array {
    $name='abc_a12_'.substr(hash('sha256',(string)$db->query('SELECT DATABASE()')->fetchColumn()),0,30);
    $lock=$db->prepare('SELECT GET_LOCK(?,10)');$lock->execute([$name]);
    if((int)$lock->fetchColumn()!==1)throw new RuntimeException('Aktualizace právě probíhá.');
    try{
        $changes=array_merge(abc_migrate_v300($db),abc_migrate_m02($db));
        $add=[
            'abc_quick_tasks'=>['revision'=>'INT UNSIGNED NOT NULL DEFAULT 1','note'=>"VARCHAR(1000) NOT NULL DEFAULT ''",'part_code'=>"VARCHAR(80) NOT NULL DEFAULT ''"],
            'jobs'=>['revision'=>'INT UNSIGNED NOT NULL DEFAULT 1'],
            'crm_customers'=>['revision'=>'INT UNSIGNED NOT NULL DEFAULT 1'],
            'crm_vehicles'=>['revision'=>'INT UNSIGNED NOT NULL DEFAULT 1'],
            'office_invoices'=>['context_json'=>'LONGTEXT NULL'],
            'events'=>['data_json'=>'LONGTEXT NULL','source'=>"VARCHAR(40) NOT NULL DEFAULT 'legacy'"],
        ];
        foreach($add as $table=>$columns){
            $found=array_column($db->query('SHOW COLUMNS FROM `'.$table.'`')->fetchAll(),'Field');
            foreach($columns as $column=>$sql)if(!in_array($column,$found,true)){$db->exec('ALTER TABLE `'.$table.'` ADD COLUMN `'.$column.'` '.$sql);$changes[]=$table.'.'.$column;}
        }
        $found=array_column($db->query('SHOW COLUMNS FROM abc_quick_catalog')->fetchAll(),'Field');
        if(!in_array('unit',$found,true)){$db->exec('ALTER TABLE abc_quick_catalog ADD COLUMN unit VARCHAR(12) NULL DEFAULT NULL');$changes[]='abc_quick_catalog.unit';}
        $column=$db->query("SHOW COLUMNS FROM abc_quick_catalog LIKE 'unit'")->fetch();
        if($column['Null']==='YES'){$db->exec("UPDATE abc_quick_catalog SET unit=CASE WHEN kind='labor' THEN 'úkon' ELSE 'ks' END WHERE unit IS NULL");$db->exec("ALTER TABLE abc_quick_catalog MODIFY unit VARCHAR(12) NOT NULL DEFAULT 'ks'");}
        $column=$db->query("SHOW COLUMNS FROM items LIKE 'unit_price'")->fetch();
        if($column['Null']==='NO'){$db->exec('ALTER TABLE items MODIFY unit_price DECIMAL(12,2) NULL');$changes[]='items.unit_price.nullable';}
        // Staré doklady zmrazíme do stavu, v němž se tiskly před touto migrací.
        // Nejde o tvrzení, že jde o historické údaje z původního okamžiku vystavení.
        $db->beginTransaction();
        $rows=$db->query('SELECT i.id,j.id job_id,j.plate,j.vin,j.vehicle,j.mileage,j.customer_name,j.customer_phone FROM office_invoices i JOIN jobs j ON j.id=i.job_id WHERE i.context_json IS NULL FOR UPDATE')->fetchAll();
        $save=$db->prepare('UPDATE office_invoices SET context_json=? WHERE id=? AND context_json IS NULL');
        foreach($rows as $row){$id=$row['id'];unset($row['id']);$save->execute([json_encode(['job'=>$row,'captured_at'=>date(DATE_ATOM),'capture'=>'legacy_at_migration'],JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR),$id]);}
        $db->exec("INSERT IGNORE INTO schema_meta(version) VALUES ('3.2.0-a12')");$db->commit();
        a_migrate($db);
        return $changes;
    }catch(Throwable $e){if($db->inTransaction())$db->rollBack();throw $e;}
    finally{$release=$db->prepare('SELECT RELEASE_LOCK(?)');$release->execute([$name]);}
}
