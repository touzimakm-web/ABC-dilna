<?php
declare(strict_types=1);
const ABC_A12_SCHEMA='3.2.0-a12';

function card_version(array $p,int $current,string $entity,array $record=[]): void {
    $v=filter_var($p['revision']??null,FILTER_VALIDATE_INT,['options'=>['min_range'=>1]]);
    if(!$v)fail('Načti aktuální verzi. Rozepsané údaje si ponech.',428,['code'=>'revision_required','entity'=>$entity,'current'=>$record]);
    if($v!==$current)fail('Údaje mezitím změnil jiný pracovník. Tvoje rozepsané změny zůstávají zachované.',409,['code'=>'revision_conflict','entity'=>$entity,'current'=>$record]);
}
function card_locked(int $id): bool {
    return (bool)query('SELECT id FROM office_invoices WHERE job_id=? LIMIT 1',[$id])->fetchColumn()
        ||(bool)query('SELECT id FROM payments WHERE job_id=? LIMIT 1',[$id])->fetchColumn();
}
function card_mutable(int $id,array $j): void {
    if(card_locked($id))fail('Finanční položky tohoto dokladu už nelze měnit. Živou evidenci zákazníka a vozidla lze dál doplňovat.',409,['code'=>'document_locked']);
}
function card_lines(int $id): array {
    return query('SELECT t.id,t.job_id,t.category,t.entry_type,t.request_task_id,t.description,t.kind,t.quantity,t.unit,t.status,t.item_id,t.revision,t.note,t.part_code,t.catalog_id,t.catalog_revision,t.price_origin,t.catalog_snapshot,i.unit_price FROM abc_quick_tasks t LEFT JOIN items i ON i.id=t.item_id AND i.job_id=t.job_id WHERE t.job_id=? ORDER BY t.id',[$id])->fetchAll();
}
function card_line(int $id,int $task): array {
    $t=query('SELECT t.id,t.job_id,t.category,t.entry_type,t.request_task_id,t.description,t.kind,t.quantity,t.unit,t.status,t.item_id,t.revision,t.note,t.part_code,t.catalog_id,t.catalog_revision,t.price_origin,t.catalog_snapshot,i.unit_price FROM abc_quick_tasks t LEFT JOIN items i ON i.id=t.item_id AND i.job_id=t.job_id WHERE t.job_id=? AND t.id=?',[$id,$task])->fetch();
    if(!$t)fail('Položka zakázky neexistuje.',404);
    return $t;
}
/** Explicitní seznam prodejních polí: nákupní cena se nikdy neposílá mechanikovi. */
function card_items(int $id,bool $completed=false): array {
    $condition=$completed?"t.status='done'":"t.status<>'cancelled'";
    return query("SELECT i.id,i.job_id,i.kind,i.description,i.quantity,i.unit,i.unit_price,t.note,t.part_code FROM items i LEFT JOIN abc_quick_tasks t ON t.item_id=i.id AND t.job_id=i.job_id WHERE i.job_id=? AND (t.id IS NULL OR (t.entry_type='work' AND $condition)) ORDER BY i.id",[$id])->fetchAll();
}
function card_totals(int $id): array {
    $s=query("SELECT COALESCE(SUM(ROUND(i.quantity*i.unit_price,2)),0) estimated,COALESCE(SUM(CASE WHEN t.id IS NULL OR t.status='done' THEN ROUND(i.quantity*i.unit_price,2) ELSE 0 END),0) completed FROM items i LEFT JOIN abc_quick_tasks t ON t.item_id=i.id AND t.job_id=i.job_id WHERE i.job_id=? AND (t.id IS NULL OR (t.entry_type='work' AND t.status<>'cancelled'))",[$id])->fetch();
    $discount=(float)query('SELECT discount_amount FROM jobs WHERE id=?',[$id])->fetchColumn();
    $paid=round((float)query('SELECT COALESCE(SUM(amount),0) FROM payments WHERE job_id=?',[$id])->fetchColumn(),2);
    $estimated=round((float)$s['estimated'],2);$subtotal=round((float)$s['completed'],2);$total=max(0,round($subtotal-$discount,2));
    $invoice=query('SELECT total FROM office_invoices WHERE job_id=? LIMIT 1',[$id])->fetchColumn();
    if($invoice!==false)$total=(float)$invoice;
    elseif($paid>0){
        // Pokladní doklad již potvrdil konkrétní vyúčtování; neúčtované plánované
        // díly se po první částečné platbě nesmějí znovu připočítat.
        $snapshot=json_decode((string)query('SELECT snapshot_json FROM payments WHERE job_id=? ORDER BY id LIMIT 1',[$id])->fetchColumn(),true);
        $total=is_array($snapshot)&&isset($snapshot['job_total'])?(float)$snapshot['job_total']:max(0,round($estimated-$discount,2));
    }
    $unpriced=(int)query("SELECT COUNT(*) FROM abc_quick_tasks t LEFT JOIN items i ON i.id=t.item_id AND i.job_id=t.job_id WHERE t.job_id=? AND t.entry_type='work' AND t.status<>'cancelled' AND i.unit_price IS NULL",[$id])->fetchColumn();
    $missing=(int)query("SELECT COUNT(*) FROM abc_quick_tasks WHERE job_id=? AND entry_type='work' AND status<>'cancelled' AND quantity IS NULL",[$id])->fetchColumn();
    return ['subtotal'=>$subtotal,'estimated_subtotal'=>$estimated,'estimated_total'=>max(0,round($estimated-$discount,2)),'discount'=>$discount,'total'=>round($total,2),'paid'=>$paid,'due'=>max(0,round($total-$paid,2)),'unpriced_count'=>$unpriced,'missing_quantity_count'=>$missing,'price_complete'=>$unpriced===0&&$missing===0];
}
function card_incomplete_labor(int $id): int {return (int)query("SELECT COUNT(*) FROM abc_quick_tasks WHERE job_id=? AND entry_type='work' AND kind='labor' AND status NOT IN ('done','cancelled')",[$id])->fetchColumn();}
function card_touch(array $u,array $j,string $reason,bool $unfinished=false): array {
    $status=$j['status'];
    if($unfinished&&in_array($status,['done','closed'],true)){
        $status='work';
        log_event((int)$u['id'],(int)$j['id'],'status','work',['before'=>'done','after'=>'work','reason'=>$reason]);
    }
    a_reset_queue($j);
    query('UPDATE jobs SET revision=revision+1,status=? WHERE id=?',[$status,$j['id']]);
    return ['revision'=>(int)$j['revision']+1,'status'=>$status];
}
function card_unit($value): string {
    if(!is_string($value)||!in_array(trim($value),['ks','l','hod','úkon','sada','kolo','bal','kg','m'],true))fail('Neplatná jednotka.');
    return trim($value);
}
function card_document_context(array $j): array {
    $live=card_identity((int)$j['id']);
    return ['job'=>array_intersect_key(array_replace($j,$live['fields']),array_flip(['id','plate','vin','vehicle','mileage','customer_name','customer_phone','title'])),'capture'=>'at_issue','captured_at'=>date(DATE_ATOM)];
}
function card_identity(int $id): array {
    $v=query('SELECT v.*,c.id customer_id,c.name customer_name,c.phone customer_phone,c.email customer_email,c.revision customer_revision FROM crm_vehicle_jobs l JOIN crm_vehicles v ON v.id=l.vehicle_id JOIN crm_customers c ON c.id=v.customer_id WHERE l.job_id=?',[$id])->fetch();
    if(!$v)return ['vehicle'=>null,'fields'=>[]];
    return ['vehicle'=>$v,'fields'=>['plate'=>$v['plate']??'','vin'=>$v['vin']??'','vehicle'=>trim($v['brand'].' '.$v['model']),'mileage'=>$v['mileage'],'customer_name'=>$v['customer_name'],'customer_phone'=>$v['customer_phone']]];
}
function card_set_line_status(array $u,array $j,array $t,string $status): array {
    $id=(int)$j['id'];
    if($t['entry_type']!=='work')fail('Požadavek zákazníka se neoznačuje jako účtovaná práce.',409);
    if($t['status']==='cancelled')fail('Zrušenou položku nelze měnit.',409);
    if(!in_array($status,['planned','done','cancelled'],true))fail('Neplatný stav položky.');
    if($status==='cancelled'&&$t['unit_price']!==null)permission($u,'price_jobs');
    query('UPDATE abc_quick_tasks SET status=?,revision=revision+1 WHERE id=? AND job_id=?',[$status,$t['id'],$id]);
    if($status==='cancelled')price_history($u,$id,(int)$t['id'],$t['unit_price'],null,$t['quantity']===null?null:(float)$t['quantity'],'cancelled');
    log_event((int)$u['id'],$id,'task_status','#'.$t['id'].' '.$status,['before'=>$t,'after'=>array_replace($t,['status'=>$status,'revision'=>(int)$t['revision']+1])]);
    return card_touch($u,$j,'Změna položky #'.$t['id'],$status==='planned'&&$t['kind']==='labor');
}
