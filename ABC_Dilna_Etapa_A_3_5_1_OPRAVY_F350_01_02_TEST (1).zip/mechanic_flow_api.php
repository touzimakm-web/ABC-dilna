<?php
/** ABC Dílna 2.0.6 – jednoduchý pracovní list, navazuje na 2.0.4a. */
declare(strict_types=1);
require __DIR__.'/app/bootstrap.php';
require __DIR__.'/office_lib.php';
$u=login_required();require_role($u,['owner','mechanic']);
$method=$_SERVER['REQUEST_METHOD']??'GET';
$action=(string)($_GET['action']??'');
if($method==='POST'){
    require_csrf();
    $p=json_decode(file_get_contents('php://input'),true);
    if(!is_array($p))fail('Neplatný požadavek.',400);
}else $p=$_GET;
function flow_id($v): int {
    $n=filter_var($v,FILTER_VALIDATE_INT,['options'=>['min_range'=>1]]);
    if(!$n)fail('Neplatné číslo zakázky.');
    return (int)$n;
}
function flow_unit($v): string {return card_unit($v);}
function flow_job(int $id,array $u): array {
    $j=get_job($id,$u);
    if($j['status']==='closed')fail('Uzavřenou zakázku nelze měnit.',409);
    return $j;
}
try{
    if($action==='info' && $method==='GET'){
        $id=flow_id($p['id']??null);$j=get_job($id,$u);$identity=card_identity($id);
        $job=array_intersect_key(array_replace($j,$identity['fields']),array_flip(['id','plate','vin','vehicle','mileage','customer_name','customer_phone','status','title','created_at','discount_reason','revision','billing_state','billing_to','billing_at','work_day']));
        $invoice=query('SELECT id,invoice_no,due_on,total FROM office_invoices WHERE job_id=? ORDER BY id DESC LIMIT 1',[$id])->fetch()?:null;
        $appointment=query("SELECT id,start_at,end_at,status,resource_id,resource_start,resource_end,work_mode,mechanic_id FROM office_appointments WHERE job_id=? AND status IN ('confirmed','requested') ORDER BY start_at LIMIT 1",[$id])->fetch()?:null;
        $prices=abc_perm($u,'price_jobs');$collect=abc_perm($u,'collect_payments');$invoicePerm=abc_perm($u,'issue_invoices');
        json_ok(['job'=>$job,'vehicle'=>$identity['vehicle'],
            'customer'=>query('SELECT c.* FROM crm_customers c JOIN crm_vehicles v ON v.customer_id=c.id JOIN crm_vehicle_jobs l ON l.vehicle_id=v.id WHERE l.job_id=?',[$id])->fetch()?:null,
            'tasks'=>card_lines($id),'appointment'=>$appointment,'items'=>card_items($id),'invoice'=>$invoice,'totals'=>totals($id),
            'payments'=>($u['role']==='owner'||$collect||$invoicePerm)?query('SELECT id,user_id,amount,method,created_at FROM payments WHERE job_id=? ORDER BY id DESC',[$id])->fetchAll():[],
            'notes'=>query('SELECT n.*,u.name author FROM notes n JOIN users u ON u.id=n.user_id WHERE n.job_id=? ORDER BY n.id DESC',[$id])->fetchAll(),
            'requests'=>query('SELECT * FROM part_requests WHERE job_id=? ORDER BY id DESC',[$id])->fetchAll(),
            'locked'=>card_locked($id),
            'permissions'=>['edit'=>!card_locked($id)&&abc_perm($u,'edit_jobs')&&abc_perm($u,'edit_lines'),'status'=>abc_perm($u,'edit_jobs')&&abc_perm($u,'change_status'),'identity'=>abc_perm($u,'edit_jobs')&&abc_perm($u,'edit_identity'),'move'=>abc_perm($u,'edit_jobs')&&abc_perm($u,'move_appointments'),'discount'=>abc_perm($u,'edit_jobs')&&abc_perm($u,'discount_jobs'),'handover'=>abc_perm($u,'handover_billing'),'price'=>$prices,'collect'=>$collect,'invoice'=>$invoicePerm,'receipt'=>abc_perm($u,'print_receipts')]]);
    }
    if($action==='create' && $method==='POST'){
        permission($u,'create_jobs');
        $assigned=(int)$u['id'];
        if(isset($p['assigned_to'])){
            $target=flow_id($p['assigned_to']);
            if($target!==$assigned && $u['role']!=='owner')fail('Zakázku jinému mechanikovi přiděluje majitel.',403);
            if(!query('SELECT id FROM users WHERE id=? AND active=1',[$target])->fetch())fail('Vybraný mechanik není aktivní.');
            $assigned=$target;
        }
        $plate=mb_strtoupper(post_str($p,'plate',30));$plate=preg_replace('/\s+/u','',$plate);
        $vin=mb_strtoupper(post_str($p,'vin',32));$vin=preg_replace('/\s+/u','',$vin);
        if($vin && !preg_match('/^[A-HJ-NPR-Z0-9]{17}$/D',$vin))fail('VIN musí obsahovat 17 platných znaků.');
        $vehicle=post_str($p,'vehicle',160);$customer=post_str($p,'customer_name',160);$phone=post_str($p,'customer_phone',60);
        $vehicleId=filter_var($p['vehicle_id']??null,FILTER_VALIDATE_INT,['options'=>['min_range'=>1]])?:null;
        $customerId=filter_var($p['customer_id']??null,FILTER_VALIDATE_INT,['options'=>['min_range'=>1]])?:null;
        $saveVehicle=!empty($p['save_vehicle']);$requested=post_str($p,'requested',900);
        $services=$p['services']??[];
        $allowedServices=array_values(array_unique(array_merge(a_settings()['services'],array_column(a_settings()['service_templates'],'category'),['Podvozek','Elektro','Ostatní'])));
        if(!is_array($services)||count($services)>count($allowedServices))fail('Neplatný seznam služeb.');
        foreach($services as $service)if(!is_string($service))fail('Neplatný druh služby.');
        $services=array_values(array_unique($services));
        $selection=$p['manual_plan']??null;$selectedCodes=is_array($selection)?($selection['codes']??[]):[];$templateMap=array_column(a_settings()['service_templates'],null,'code');if(is_array($selectedCodes))foreach($selectedCodes as $code)if(is_string($code)&&isset($templateMap[$code]))$services[]=$templateMap[$code]['category'];$services=array_values(array_unique($services));
        foreach($services as $service)if(!is_string($service)||!in_array($service,$allowedServices,true))fail('Neplatný druh služby.');
        if(!$plate&&!$vin&&!$vehicle&&!$customer&&!$vehicleId)fail('Vyplň SPZ, vozidlo nebo zákazníka.');
        if(!$services&&mb_strlen($requested)<3)fail('Vyber alespoň jednu službu nebo napiš práci.');
        $notes=array_values(array_filter(array_map('trim',preg_split('/[\r\n]+/u',$requested))));
        $entries=$services?:['Ostatní opravy'];
        if(count($entries)>12)fail('Nejvýše 12 prací při založení. Další můžeš doplnit v zakázce.');
        foreach($entries as $entry)if(mb_strlen($entry)>220)fail('Jeden pracovní úkon je příliš dlouhý.');
        $mileage=null;
        if(isset($p['mileage'])&&$p['mileage']!==''){
            if(!ctype_digit((string)$p['mileage'])||(int)$p['mileage']>9999999)fail('Neplatný stav tachometru.');
            $mileage=(int)$p['mileage'];
        }
        $date=post_str($p,'date',10);$time=post_str($p,'time',5);
        if($date!==''&&!a_date($date))fail('Zadej platný den.');
        if($time!==''&&$date==='')fail('Pro časovou rezervaci vyber den.');
        if($time===''&&!empty($p['resource_id']))fail('Hever vyžaduje výslovně zvolený čas a délku.');
        $start=null;$end=null;
        if($date!==''&&$time!=='')[$start,$end]=office_slot($date,$time,$p['duration']??null,false);
        $mode=post_str($p,'work_mode',12)?:'inside';if(!in_array($mode,['inside','outside'],true))fail('Neplatný režim plánu.');
        $resources=$start?a_resource_payload($p,$start,$end):[null,null,null];if($mode==='outside'&&array_filter($resources))fail('Oprava venku nevyžaduje vnitřní pracoviště.');
        $db=db();$locked=false;
        try{
            if($start!==null){office_lock_calendar($db);$locked=true;}
            $db->beginTransaction();$op=operation_begin($u,'job_create',$p);
            if(!$vehicleId&&($plate||$vin)){
                $matches=query('SELECT id FROM crm_vehicles WHERE (plate IS NOT NULL AND plate=?) OR (vin IS NOT NULL AND vin=?)',[$plate?:null,$vin?:null])->fetchAll();
                if(count($matches)>1)fail('SPZ a VIN ukazují na různá vozidla. Zkontroluj údaje.',409);
                if($matches)$vehicleId=(int)$matches[0]['id'];
            }
            $saveVehicle=$saveVehicle||($plate!==''||$vin!==''||$vehicle!==''||$customer!==''||$customerId);
            if($vehicleId){
                $s=$db->prepare('SELECT v.*,c.name customer_name,c.phone customer_phone FROM crm_vehicles v JOIN crm_customers c ON c.id=v.customer_id WHERE v.id=? FOR UPDATE');$s->execute([$vehicleId]);$v=$s->fetch();
                if(!$v)fail('Uložené auto neexistuje.',404);
                if(($vin&&$v['vin']&&$vin!==mb_strtoupper((string)$v['vin']))||($plate&&$v['plate']&&$plate!==preg_replace('/\s+/u','',mb_strtoupper((string)$v['plate']))))fail('SPZ nebo VIN neodpovídá vybranému autu.',409);
                $vin=$vin?:($v['vin']??'');$plate=$plate?:($v['plate']??'');
                $vehicle=$vehicle?:trim(($v['brand']??'').' '.($v['model']??''));
                $customer=$v['customer_name'];$phone=$phone?:($v['customer_phone']??'');$customerId=(int)$v['customer_id'];
                if($mileage!==null && (string)$mileage!==(string)$v['mileage']){card_version(['revision'=>$p['vehicle_revision']??null],(int)$v['revision'],'vehicle',array_intersect_key($v,array_flip(['id','plate','vin','mileage','revision'])));$db->prepare('UPDATE crm_vehicles SET mileage=?,revision=revision+1 WHERE id=?')->execute([$mileage,$vehicleId]);}
            }elseif($saveVehicle){
                if(!$plate&&!$vin&&!$vehicle&&!$customer&&!$customerId)fail('Vyplň alespoň zákazníka nebo údaj vozidla.');
                if($vin){$s=$db->prepare('SELECT id FROM crm_vehicles WHERE vin=? LIMIT 1');$s->execute([$vin]);if($s->fetch())fail('VIN už existuje; najdi auto v evidenci.',409);}
                if($plate){$s=$db->prepare("SELECT id FROM crm_vehicles WHERE REPLACE(UPPER(plate),' ','')=? LIMIT 1");$s->execute([$plate]);if($s->fetch())fail('SPZ už existuje; najdi auto v evidenci.',409);}
                if($customerId){$s=$db->prepare('SELECT id,name,phone FROM crm_customers WHERE id=?');$s->execute([$customerId]);$c=$s->fetch();if(!$c)fail('Zákazník neexistuje.',404);$customer=$c['name'];$phone=$phone?:$c['phone'];}
                else{
                    if(!$customer)$customer='Zákazník neuveden';
                    $s=$db->prepare('SELECT id FROM crm_customers WHERE name=? AND phone=? LIMIT 2');$s->execute([$customer,$phone]);$matches=($customer==='Zákazník neuveden'||$phone==='')?[]:$s->fetchAll();
                    if(count($matches)>1)fail('Vyber existující kartu zákazníka.',409);
                    if($matches)$customerId=(int)$matches[0]['id'];
                    else{$db->prepare('INSERT INTO crm_customers(type,name,phone) VALUES (?,?,?)')->execute(['person',$customer,$phone]);$customerId=(int)$db->lastInsertId();}
                }
                $parts=preg_split('/\s+/u',trim($vehicle),2);$brand=count($parts)>1?$parts[0]:'';$model=count($parts)>1?$parts[1]:($parts[0]??'');
                $db->prepare('INSERT INTO crm_vehicles(customer_id,plate,vin,brand,model,mileage) VALUES (?,?,?,?,?,?)')->execute([$customerId,$plate?:null,$vin?:null,$brand,$model,$mileage]);
                $vehicleId=(int)$db->lastInsertId();
            }
            if($customerId&&$phone!==''){$contact=query('SELECT id,phone,revision FROM crm_customers WHERE id=? FOR UPDATE',[$customerId])->fetch();if($contact&&$contact['phone']!==$phone){card_version(['revision'=>$p['customer_revision']??null],(int)$contact['revision'],'customer',$contact);query('UPDATE crm_customers SET phone=?,revision=revision+1 WHERE id=?',[$phone,$customerId]);log_event((int)$u['id'],0,'customer_contact','Kontakt při příjmu',['before'=>$contact,'phone'=>$phone]);}}
            $title=mb_substr(implode(' · ',$services?:$entries),0,220);
            $db->prepare('INSERT INTO jobs(customer_name,customer_phone,plate,vehicle,vin,mileage,title,assigned_to,created_by,status) VALUES (?,?,?,?,?,?,?,?,?,?)')
               ->execute([$customer,$phone,$plate,$vehicle,$vin,$mileage,$title,$assigned,(int)$u['id'],$start?'new':'work']);
            $id=(int)$db->lastInsertId();
            if($vehicleId)$db->prepare('INSERT INTO crm_vehicle_jobs(job_id,vehicle_id) VALUES (?,?)')->execute([$id,$vehicleId]);
            query('UPDATE jobs SET work_day=?,status=? WHERE id=?',[$date?:null,($start||($date!==''&&$date>date('Y-m-d')))?'new':'work',$id]);
            $received=array_key_exists('received',$p)?!empty($p['received']):(!$date||$date<=date('Y-m-d'));
            query('UPDATE jobs SET location_state=?,received_at=? WHERE id=?',[$received?'yard':'expected',$received?ops_now():null,$id]);
            // Kategorie a práce jsou teď pouze požadavky, nejsou to automaticky účtované položky.
            $st=$db->prepare("INSERT INTO abc_quick_tasks(job_id,category,description,kind,quantity,unit,status,item_id,created_by,entry_type) VALUES (?,?,?,'labor',1,'úkon','planned',NULL,?,'request')");
            foreach($services as $entry)$st->execute([$id,$entry,$entry,(int)$u['id']]);
            if($start!==null){
                a_calendar_check($db,$start,$end,0,$assigned,$resources[0],$resources[1],$resources[2],$mode,$id);
                $service=mb_substr(implode(', ',$entries),0,250);
                $db->prepare("INSERT INTO office_appointments(start_at,end_at,source,status,customer_name,customer_phone,customer_email,vehicle,plate,service,note,job_id,created_by,mechanic_id) VALUES (?,?,'staff','confirmed',?,?,'',?,?,?,'',?,?,?)")
                   ->execute([$start,$end,$customer,$phone,$vehicle,$plate,$service,$id,(int)$u['id'],$assigned]);
                query('UPDATE office_appointments SET resource_id=?,resource_start=?,resource_end=?,work_mode=? WHERE id=?',[...$resources,$mode,(int)$db->lastInsertId()]);
            }
            if(!empty($p['manual_plan']))a_apply_manual_plan($u,get_job($id,$u),$p['manual_plan']);
            log_event((int)$u['id'],$id,'flow_create',$start?'Objednáno '.$start:'Přijato ihned');
            if($requested!=='')query('INSERT INTO notes(job_id,user_id,kind,body) VALUES (?,?,?,?)',[$id,$u['id'],'intake',$requested]);
            operation_store($op,['id'=>$id,'scheduled'=>$start!==null,'work_day'=>$date?:null]);$db->commit();
        }catch(Throwable $e){if($db->inTransaction())$db->rollBack();throw $e;}
        finally{if($locked)office_unlock_calendar($db);}
        json_ok(['id'=>$id,'scheduled'=>$start!==null,'work_day'=>$date?:null]);
    }
    if($action==='update_identity' && $method==='POST'){
        a_edit($u,'edit_identity');
        $id=flow_id($p['id']??null);get_job($id,$u);$vdata=$p['vehicle']??null;$cdata=$p['customer']??null;
        if(!is_array($vdata)||!is_array($cdata))fail('Neplatné údaje živé evidence.');
        $db=db();$db->beginTransaction();$op=operation_begin($u,'identity_update',$p);$j=lock_job($id,$u);
        $link=query('SELECT vehicle_id FROM crm_vehicle_jobs WHERE job_id=?',[$id])->fetchColumn();if(!$link)fail('Zakázka zatím nemá propojené vozidlo.',409);
        $v=query('SELECT * FROM crm_vehicles WHERE id=? FOR UPDATE',[$link])->fetch();$c=query('SELECT * FROM crm_customers WHERE id=? FOR UPDATE',[$v['customer_id']])->fetch();
        card_version($vdata,(int)$v['revision'],'vehicle',array_intersect_key($v,array_flip(['id','plate','vin','brand','model','mileage','revision'])));
        card_version($cdata,(int)$c['revision'],'customer',array_intersect_key($c,array_flip(['id','name','phone','email','revision'])));
        $plate=preg_replace('/\s+/u','',mb_strtoupper(post_str($vdata,'plate',30)));$vin=mb_strtoupper(post_str($vdata,'vin',17));
        if($vin&&!preg_match('/^[A-HJ-NPR-Z0-9]{17}$/D',$vin))fail('VIN musí mít 17 platných znaků.');
        if(($plate&&query('SELECT id FROM crm_vehicles WHERE plate=? AND id<>?',[$plate,$v['id']])->fetch())||($vin&&query('SELECT id FROM crm_vehicles WHERE vin=? AND id<>?',[$vin,$v['id']])->fetch()))fail('SPZ nebo VIN už patří jinému vozidlu.',409);
        $mileage=post_str($vdata,'mileage',10);if($mileage!==''&&(!ctype_digit($mileage)||(int)$mileage>9999999))fail('Neplatný stav tachometru.');
        $name=post_str($cdata,'name',160);$phone=post_str($cdata,'phone',60);$email=post_str($cdata,'email',190);if(!$name||($email&&!filter_var($email,FILTER_VALIDATE_EMAIL)))fail('Zkontroluj jméno a e-mail.');
        $brand=post_str($vdata,'brand',80);$model=post_str($vdata,'model',160);
        query('UPDATE crm_vehicles SET plate=?,vin=?,brand=?,model=?,mileage=?,revision=revision+1 WHERE id=?',[$plate?:null,$vin?:null,$brand,$model,$mileage===''?null:(int)$mileage,$v['id']]);
        query('UPDATE crm_customers SET name=?,phone=?,email=?,revision=revision+1 WHERE id=?',[$name,$phone,$email,$c['id']]);
        query('UPDATE jobs SET plate=?,vin=?,vehicle=?,mileage=?,customer_name=?,customer_phone=?,revision=revision+1 WHERE id=?',[$plate,$vin,trim($brand.' '.$model),$mileage===''?null:(int)$mileage,$name,$phone,$id]);
        $tech=a_vehicle_fields($vdata,$v);query('UPDATE crm_vehicles SET engine_code=?,fuel=?,color=?,condition_note=?,engine_cc=?,power_kw=?,year=?,stk_due=? WHERE id=?',[...array_values($tech),$v['id']]);
        $now=card_identity($id);log_event((int)$u['id'],$id,'identity_updated','Živá evidence; doklady zůstávají beze změny',['before'=>['vehicle'=>array_intersect_key($v,array_flip(['plate','vin','brand','model','mileage','revision'])),'customer'=>array_intersect_key($c,array_flip(['name','phone','email','revision']))],'after'=>$now['fields']]);
        operation_commit($op,['vehicle'=>$now['vehicle'],'job'=>['revision'=>(int)$j['revision']+1,'status'=>$j['status']]]);
    }
    if($action==='add' && $method==='POST'){
        a_edit($u,'edit_lines');
        $id=flow_id($p['id']??null);get_job($id,$u);
        $kind=post_str($p,'kind',10);if(!in_array($kind,['labor','part'],true))fail('Vyber práci nebo díl.');
        $description=post_str($p,'description',220);if(mb_strlen($description)<2)fail('Napiš název práce nebo dílu.');
        $category=post_str($p,'category',80)?:'Ostatní';
        $note=post_str($p,'note',1000);$partCode=$kind==='part'?post_str($p,'part_code',80):'';
        $catalogId=filter_var($p['catalog_id']??null,FILTER_VALIDATE_INT,['options'=>['min_range'=>1]])?:null;
        $db=db();$db->beginTransaction();$op=operation_begin($u,'task_add',$p);$j=lock_job($id,$u);card_mutable($id,$j);
        $cost=0;$base=null;$defaultUnit=$kind==='labor'?'úkon':'ks';
        if($catalogId){
            $c=c_row((int)$catalogId,true);c_check($c,$p['catalog_revision']??null);
            if($c['kind']!==$kind)fail('Typ položky se změnil.');
            $base=$c['unit_price']===null?null:(float)$c['unit_price'];$cost=(float)$c['unit_cost'];$defaultUnit=$c['unit'];
        }
        $unit=card_unit($p['unit']??$defaultUnit);if($catalogId&&$unit!==$c['unit'])fail('Jednotka neodpovídá vybrané položce ceníku.',409);
        $quantity=card_quantity(array_key_exists('quantity',$p)?$p['quantity']:($kind==='labor'&&$unit==='hod'?null:1),$kind,$unit);$raw=$p['unit_price']??null;
        $price=!array_key_exists('unit_price',$p)?$base:(($raw===null||$raw==='')?null:money($raw,'cena'));
        if(($catalogId?$price!==$base:$price!==null)&&!abc_perm($u,'price_jobs'))fail('Změnu ceny může provést jen oprávněný pracovník.',403);
        $itemId=null;
        if($price!==null||$cost>0){query('INSERT INTO items(job_id,kind,description,quantity,unit,unit_price,unit_cost) VALUES (?,?,?,?,?,?,?)',[$id,$kind,$description,$quantity,$unit,$price,$cost]);$itemId=(int)$db->lastInsertId();}
        query("INSERT INTO abc_quick_tasks(job_id,category,description,kind,quantity,unit,status,item_id,created_by,note,part_code) VALUES (?,?,?,?,?,?,'planned',?,?,?,?)",[$id,$category,$description,$kind,$quantity,$unit,$itemId,$u['id'],$note,$partCode]);
        $task=(int)$db->lastInsertId();c_source($task,$catalogId?$c:null,$catalogId&&$price===$base?'catalog':($price===null?'unknown':'manual'));if($kind==='part')query("UPDATE abc_quick_tasks SET procurement_stage='needed' WHERE id=?",[$task]);
        if(!empty($p['request_task_id'])){$request=positive_id($p['request_task_id']);if(!query("SELECT id FROM abc_quick_tasks WHERE id=? AND job_id=? AND entry_type='request'",[$request,$id])->fetch())fail('Požadavek nepatří zakázce.',409);query('UPDATE abc_quick_tasks SET request_task_id=? WHERE id=?',[$request,$task]);}
        price_history($u,$id,$task,null,$price,$quantity,'added');$line=card_line($id,$task);
        log_event((int)$u['id'],$id,'flow_item_add',$description,['before'=>null,'after'=>$line]);
        $job=card_touch($u,$j,'Přidána nová položka #'.$task,true);
        operation_commit($op,['task_id'=>$task,'line'=>$line,'job'=>$job,'totals'=>totals($id)]);
    }
    if(in_array($action,['update_line','cancel_line','price'],true) && $method==='POST'){
        a_edit($u,'edit_lines');
        $id=flow_id($p['id']??null);get_job($id,$u);$task=flow_id($p['task_id']??null);
        $db=db();$db->beginTransaction();$op=operation_begin($u,'task_'.$action,$p);$j=lock_job($id,$u);card_mutable($id,$j);
        $old=card_line($id,$task);card_version($p,(int)$old['revision'],'line',$old);
        if($old['entry_type']!=='work'||$old['status']==='cancelled')fail('Tuto položku nelze měnit.',409);
        if($action==='cancel_line'){
            $job=card_set_line_status($u,$j,$old,'cancelled');
        }else{
            if($action==='price')permission($u,'price_jobs');
            $description=$action==='price'?$old['description']:post_str($p,'description',220);if(mb_strlen($description)<2)fail('Vyplň název položky.');
            $kind=$p['kind']??$old['kind'];if($kind!==$old['kind'])fail('Typ položky nelze změnit. Zruš ji a přidej novou.');
            $unit=card_unit($p['unit']??$old['unit']);if($old['kind']==='part')ops_assert_unit($task,$unit);$note=array_key_exists('note',$p)?post_str($p,'note',1000):$old['note'];$code=array_key_exists('part_code',$p)?post_str($p,'part_code',80):$old['part_code'];
            $quantity=card_quantity($action==='price'?$old['quantity']:(array_key_exists('quantity',$p)?$p['quantity']:$old['quantity']),$kind,$unit);
            $raw=array_key_exists('unit_price',$p)?$p['unit_price']:$old['unit_price'];$price=($raw===null||$raw==='')?null:money($raw,'cena');
            $previous=$old['unit_price']===null?null:(float)$old['unit_price'];
            if(!abc_perm($u,'price_jobs')&&$price!==$previous)fail('Nemáš oprávnění měnit jednotkovou prodejní cenu.',403);
            // Existující finanční řádek ani unit_cost nemažeme při neznámé ceně.
            $itemId=$old['item_id'];
            if($itemId){query('UPDATE items SET description=?,quantity=?,unit=?,unit_price=? WHERE id=? AND job_id=?',[$description,$quantity,$unit,$price,$itemId,$id]);}
            elseif($price!==null){query('INSERT INTO items(job_id,kind,description,quantity,unit,unit_price,unit_cost) VALUES (?,?,?,?,?,?,0)',[$id,$kind,$description,$quantity,$unit,$price]);$itemId=(int)$db->lastInsertId();}
            query('UPDATE abc_quick_tasks SET description=?,quantity=?,unit=?,item_id=?,note=?,part_code=?,revision=revision+1 WHERE id=? AND job_id=?',[$description,$quantity,$unit,$itemId,$note,$kind==='part'?$code:'',$task,$id]);
            if($price!==$previous||$unit!==$old['unit'])query("UPDATE abc_quick_tasks SET price_origin=? WHERE id=?",[$price===null?'unknown':'manual',$task]);
            $line=card_line($id,$task);price_history($u,$id,$task,$previous,$price,$quantity,'updated');
            log_event((int)$u['id'],$id,'flow_line_update','#'.$task.' '.$description,['before'=>$old,'after'=>$line]);
            $job=card_touch($u,$j,'Úprava položky #'.$task);
        }
        operation_commit($op,['task_id'=>$task,'line'=>card_line($id,$task),'job'=>$job,'totals'=>totals($id)]);
    }
    if($action==='confirm_materials' && $method==='POST'){
        a_edit($u,'edit_lines');
        $id=flow_id($p['id']??null);get_job($id,$u);$rows=$p['rows']??null;
        if(!is_array($rows)||!count($rows)||count($rows)>100)fail('Vyber skutečně použité položky.');
        $db=db();$db->beginTransaction();$op=operation_begin($u,'materials_confirm',$p);$j=lock_job($id,$u);card_mutable($id,$j);$tasks=[];
        foreach($rows as $row){if(!is_array($row))fail('Neplatný seznam dílů.');$tid=flow_id($row['id']??null);if(isset($tasks[$tid]))fail('Díl je vybraný dvakrát.');$t=card_line($id,$tid);card_version($row,(int)$t['revision'],'line',$t);if($t['kind']!=='part'||$t['entry_type']!=='work'||$t['status']!=='planned')fail('Vybrat lze jen plánovaný díl z této zakázky.',409);$tasks[$tid]=$t;}
        foreach($tasks as $t){$job=card_set_line_status($u,$j,$t,'done');$j['revision']=$job['revision'];$j['status']=$job['status'];}
        $saved=[];foreach(array_keys($tasks) as $tid)$saved[]=card_line($id,$tid);
        operation_commit($op,['lines'=>$saved,'job'=>$job,'totals'=>totals($id)]);
    }
    fail('Neznámá operace.',404);
}catch(OfficeRule $e){if(db()->inTransaction())db()->rollBack();fail($e->getMessage(),409);}
catch(Throwable $e){if(db()->inTransaction())db()->rollBack();error_log('ABC mechanic_flow_api: '.$e->getMessage());fail('Operaci se nepodařilo uložit. Rozepsané změny si ponech a zkus to znovu.',500);}
