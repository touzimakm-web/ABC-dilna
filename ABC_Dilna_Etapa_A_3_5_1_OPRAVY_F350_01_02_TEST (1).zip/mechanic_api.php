<?php
declare(strict_types=1);
require __DIR__.'/app/bootstrap.php';require __DIR__.'/office_lib.php';
$u=login_required();$action=(string)($_GET['action']??'');
if(($_SERVER['REQUEST_METHOD']??'GET')==='GET') {
    if($action==='catalog')json_ok(['items'=>c_list()]);
    if($action==='quick_lookup') {
        $q=post_str($_GET,'q',80);if(mb_strlen($q)<2)json_ok(['vehicles'=>[],'customers'=>[]]);
        $like='%'.str_replace(['!','%','_'],['!!','!%','!_'],$q).'%';
        $cars=query("SELECT v.*,c.name customer_name,c.phone customer_phone,c.revision customer_revision FROM crm_vehicles v JOIN crm_customers c ON c.id=v.customer_id WHERE REPLACE(v.plate,' ','') LIKE ? ESCAPE '!' OR v.vin LIKE ? ESCAPE '!' OR c.name LIKE ? ESCAPE '!' OR c.ico LIKE ? ESCAPE '!' ORDER BY v.id DESC LIMIT 12",['%'.str_replace(['!','%','_'],['!!','!%','!_'],preg_replace('/\s+/u','',$q)).'%',$like,$like,$like])->fetchAll();
        $customers=query("SELECT id,name,phone,ico,revision FROM crm_customers WHERE name LIKE ? ESCAPE '!' OR phone LIKE ? ESCAPE '!' OR ico LIKE ? ESCAPE '!' ORDER BY name LIMIT 8",[$like,$like,$like])->fetchAll();
        json_ok(['vehicles'=>$cars,'customers'=>$customers]);
    }
    if($action==='calendar') {
        $sql="SELECT * FROM office_appointments WHERE status IN ('confirmed','requested') AND start_at>=CURDATE() AND start_at<DATE_ADD(CURDATE(),INTERVAL 35 DAY)";$args=[];
        if($u['role']!=='owner'){$sql.=' AND mechanic_id=?';$args[]=$u['id'];}
        json_ok(['appointments'=>query($sql.' ORDER BY start_at',$args)->fetchAll()]);
    }
    if($action==='free_jobs') {
        json_ok(['jobs'=>abc_perm($u,'take_jobs')?query("SELECT id,vehicle,plate,title,status FROM jobs WHERE assigned_to IS NULL AND status IN ('new','work','review') ORDER BY created_at")->fetchAll():[]]);
    }
    if($action==='quick_tasks') {
        $id=positive_id($_GET['id']??null);get_job($id,$u);
        json_ok(['tasks'=>query('SELECT t.*,i.unit_price FROM abc_quick_tasks t LEFT JOIN items i ON i.id=t.item_id WHERE t.job_id=? ORDER BY t.id',[$id])->fetchAll()]);
    }
    fail('Neznámá operace.',404);
}
$p=payload();
if($action==='classify_request'){
 permission($u,'price_jobs');$id=positive_id($p['id']??null);get_job($id,$u);$task=positive_id($p['task_id']??null);
 db()->beginTransaction();$op=operation_begin($u,'classify_request',$p);$j=lock_job($id,$u);card_mutable($id,$j);$t=card_line($id,$task);card_version($p,(int)$t['revision'],'line',$t);
 if($t['unit_price']!==null||$t['status']==='cancelled')fail('Převést lze jen nenaceněný nezrušený úkon.',409);
 query("UPDATE abc_quick_tasks SET entry_type='request',revision=revision+1 WHERE id=?",[$task]);$job=card_touch($u,$j,'Změna na požadavek');log_event((int)$u['id'],$id,'request_classified','#'.$task,['before'=>$t,'after'=>card_line($id,$task)]);operation_commit($op,['line'=>card_line($id,$task),'job'=>$job]);
}
if($action==='quick_task_status'){
 a_edit($u,'edit_lines');
 $id=positive_id($p['id']??null);get_job($id,$u);$task=positive_id($p['task_id']??null);$status=post_str($p,'status',20);
 db()->beginTransaction();$op=operation_begin($u,'line_status',$p);$j=lock_job($id,$u);card_mutable($id,$j);$t=card_line($id,$task);card_version($p,(int)$t['revision'],'line',$t);
 $job=card_set_line_status($u,$j,$t,$status);operation_commit($op,['line'=>card_line($id,$task),'job'=>$job,'totals'=>totals($id)]);
}
fail('Neznámá operace.',404);
