<?php
/** ABC Dílna 2.0.6 – nezávazný cenový návrh; neúčtuje, nevystavuje fakturu. */
declare(strict_types=1);
require __DIR__.'/app/bootstrap.php';
require __DIR__.'/office_lib.php';
$u=login_required();require_role($u,['owner','mechanic']);
$method=$_SERVER['REQUEST_METHOD']??'GET';
if($method==='POST'){
    require_csrf();
    $p=json_decode(file_get_contents('php://input'),true);
    if(!is_array($p))fail('Neplatná data.',400);
}else $p=$_GET;
$action=(string)($_GET['action']??'');
function est_job($value,array $u): array {
    $id=filter_var($value,FILTER_VALIDATE_INT,['options'=>['min_range'=>1]]);
    if(!$id)fail('Neplatné číslo zakázky.',400);
    return get_job((int)$id,$u);
}
function est_authorize(array $u): void {
    if($u['role']!=='owner'&&!abc_perm($u,'price_jobs'))fail('K vytvoření předběžného cenového návrhu nemáš oprávnění. Požádej recepci.',403);
}
function est_tasks(int $id): array {
    $hasWork=(int)query("SELECT COUNT(*) FROM abc_quick_tasks WHERE job_id=? AND entry_type='work' AND status<>'cancelled'",[$id])->fetchColumn();
    $type=$hasWork?'work':'request';
    $s=db()->prepare("SELECT t.id,t.category,t.description,t.quantity,t.kind,t.unit,t.revision,t.catalog_id,t.catalog_revision,t.price_origin,t.catalog_snapshot,t.status,t.item_id,i.unit_price FROM abc_quick_tasks t LEFT JOIN items i ON i.id=t.item_id WHERE t.job_id=? AND t.entry_type='$type' AND t.status!='cancelled' ORDER BY t.id");
    $s->execute([$id]);return $s->fetchAll();
}
try{
    if($action==='info' && $method==='GET'){
        $j=est_job($p['id']??null,$u);$id=(int)$j['id'];
        $catalog=c_list();
        $s=db()->prepare('SELECT id,lower_total,upper_total,created_at,origin FROM abc_job_estimates WHERE job_id=? ORDER BY id DESC LIMIT 12');$s->execute([$id]);
        json_ok(['job'=>['revision'=>$j['revision'],'id'=>$id,'customer_name'=>$j['customer_name'],'customer_phone'=>$j['customer_phone'],'vehicle'=>$j['vehicle'],'plate'=>$j['plate'],'vin'=>$j['vin']],
            'tasks'=>est_tasks($id),'catalog'=>$catalog,'quotes'=>$s->fetchAll(),
            'can_estimate'=>$u['role']==='owner'||abc_perm($u,'price_jobs'),
            'ai_available'=>(trim((string)($config['openai_api_key']??''))!=='' && !str_contains((string)($config['openai_api_key']??''),'SEM_VLOZ'))]);
    }
    if($action==='save' && $method==='POST'){
        est_authorize($u);$j=est_job($p['id']??null,$u);$id=(int)$j['id'];
        $db=db();$db->beginTransaction();
        $op=operation_begin($u,'estimate_save',$p);
        $guard=$db->prepare('SELECT id FROM jobs WHERE id=? FOR UPDATE');$guard->execute([$id]);
        $current=est_job($id,$u);card_version(['revision'=>$p['job_revision']??null],(int)$current['revision'],'job',['id'=>$id,'revision'=>$current['revision']]);
        $tasks=est_tasks($id);$map=[];foreach($tasks as $task)$map[(int)$task['id']]=$task;
        $in=$p['lines']??null;
        if(!is_array($in)||count($in)<1||count($in)>50)fail('Neplatné položky odhadu.');
        $known=[];$lines=[];$lo=0.0;$hi=0.0;$priced=0;
        foreach($in as $line){
            if(!is_array($line))fail('Neplatná položka.');
            $taskId=filter_var($line['task_id']??null,FILTER_VALIDATE_INT,['options'=>['min_range'=>1]]);
            if(!$taskId||!isset($map[(int)$taskId])||isset($known[(int)$taskId]))fail('Položka se změnila, načti zakázku znovu.',409);
            $known[(int)$taskId]=true;$t=$map[(int)$taskId];card_version(['revision'=>$line['revision']??null],(int)$t['revision'],'line',$t);$source=null;if(!empty($line['catalog_id'])){$c=c_row(positive_id($line['catalog_id']),true);c_check($c,$line['catalog_revision']??null);if($c['kind']!==$t['kind']||$c['unit']!==$t['unit'])fail('Sazba neodpovídá druhu a jednotce odhadované položky.',409);$source=c_sale($c);}
            $a=trim((string)($line['min_price']??''));$b=trim((string)($line['max_price']??''));
            if(($a==='')!==($b===''))fail('U ceny vyplň spodní i horní hranici, nebo obě nech prázdné.');
            if($a===''){$min=null;$max=null;}
            else{
                if($t['quantity']===null)fail('Hodiny doplnit na pracovní kartě; bez množství nelze potvrdit částku tohoto řádku.',409,['code'=>'quantity_required']);
                $min=money($a,'dolní cena');$max=money($b,'horní cena');
                if($min>$max||$max>2000000)fail('Neplatné cenové rozpětí.');
                $lo+=round($min*(float)$t['quantity'],2);$hi+=round($max*(float)$t['quantity'],2);$priced++;
            }
            if(!$source&&$min!==null&&$t['price_origin']==='catalog'&&$t['unit_price']!==null&&abs((float)$t['unit_price']-$min)<.009&&abs((float)$t['unit_price']-$max)<.009)$source=json_decode($t['catalog_snapshot']??'null',true);
            if($source&&($min===null||$source['unit_price']===null||abs((float)$source['unit_price']-$min)>.009||abs((float)$source['unit_price']-$max)>.009))fail('Cena zdroje se liší. Pro vlastní rozpětí použij ruční návrh.',409);
            $lines[]=['revision'=>$t['revision'],'unit'=>$t['unit'],'catalog_source'=>$source,'task_id'=>(int)$taskId,'description'=>(string)$t['description'],'category'=>(string)$t['category'],
                      'quantity'=>$t['quantity']===null?null:(float)$t['quantity'],'min_price'=>$min,'max_price'=>$max];
        }
        if(count($known)!==count($map))fail('Seznam prací se změnil. Načti zakázku znovu a zahrň všechny položky.',409);
        if(!$priced)fail('Zadej před tiskem cenu alespoň jedné položky.');
        $note=post_str($p,'note',500);$origin=post_str($p,'origin',24);
        if(!in_array($origin,['manual','catalog','ai','mixed'],true))$origin='manual';
        $s=$db->prepare('INSERT INTO abc_job_estimates(job_id,created_by,lower_total,upper_total,lines_json,note,origin) VALUES (?,?,?,?,?,?,?)');
        $s->execute([$id,(int)$u['id'],round($lo,2),round($hi,2),json_encode($lines,JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE),$note,$origin]);
        $quoteId=(int)$db->lastInsertId();
        log_event((int)$u['id'],$id,'estimate_created','Odhad #'.$quoteId.' '.round($lo).'–'.round($hi).' Kč');
        operation_commit($op,['quote_id'=>$quoteId]);
    }
    fail('Neznámá operace.',404);
}catch(Throwable $e){
    error_log('ABC estimate api: '.$e->getMessage());
    fail('Odhad nebylo možné načíst nebo uložit. Ověř databázi a oprávnění.',500);
}
