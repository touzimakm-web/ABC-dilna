'use strict';
document.getElementById('generate').addEventListener('click',()=>{
 const hex=n=>Array.from(crypto.getRandomValues(new Uint8Array(n)),b=>b.toString(16).padStart(2,'0')).join('');
 document.getElementById('secret').value=hex(32);document.getElementById('token').value=hex(24);document.getElementById('keys').hidden=false;
});
