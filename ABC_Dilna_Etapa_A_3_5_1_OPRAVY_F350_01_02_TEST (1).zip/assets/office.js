'use strict';
document.addEventListener('submit',async event=>{
 const form=event.target.closest('form[data-api]');if(!form)return;event.preventDefault();
 if(form.dataset.confirm&&!confirm(form.dataset.confirm))return;
 const button=form.querySelector('button[type="submit"],button:not([type])');if(button?.disabled)return;
 const notice=document.getElementById('office-notice');if(notice)notice.hidden=true;
 const payload=Object.fromEntries(new FormData(form).entries());delete payload.csrf;payload.request_key=payload.request_key||crypto.randomUUID();
 if(button)button.disabled=true;
 try{
  const response=await fetch(form.dataset.api,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json','X-CSRF-Token':form.querySelector('[name="csrf"]').value,'X-ABC-Scope':document.querySelector('meta[name="abc-scope"]').content},body:JSON.stringify(payload)});
  const data=await response.json();if(!response.ok||!data.ok)throw Error(data.error||'Uložení se nezdařilo.');location.reload();
 }catch(error){if(notice){notice.hidden=false;notice.textContent=error.message;notice.className='notice error';notice.scrollIntoView({behavior:'smooth',block:'center'});}if(button)button.disabled=false;}
});
