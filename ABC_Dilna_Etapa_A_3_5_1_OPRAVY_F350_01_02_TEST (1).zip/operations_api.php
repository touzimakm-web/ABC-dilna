<?php
declare(strict_types=1);
require __DIR__.'/app/bootstrap.php';require __DIR__.'/office_lib.php';
$u=login_required();$action=post_str($_GET,'action',40);$method=$_SERVER['REQUEST_METHOD']??'GET';
try {
 if($method==='GET'){
  if($action==='info')json_ok(['operations'=>ops_info(get_job(positive_id($_GET['id']??null),$u),$u)]);
  if($action==='queue'){
   [$where,$args]=a_job_where($u,'j');$page=max(1,min(100000,(int)($_GET['page']??1)));$offset=($page-1)*50;
   $filter="j.location_state IN ('yard','unknown') AND j.status<>'closed' AND ".$where;
   $total=(int)query('SELECT COUNT(*) FROM jobs j WHERE '.$filter,$args)->fetchColumn();
   $jobs=query('SELECT j.*,(SELECT MIN(start_at) FROM office_appointments a WHERE a.job_id=j.id AND a.status IN (\'confirmed\',\'requested\')) appointment_start,u.name mechanic_name FROM jobs j LEFT JOIN users u ON u.id=j.assigned_to WHERE '.$filter.' ORDER BY COALESCE(j.received_at,j.created_at),j.id LIMIT 50 OFFSET '.$offset,$args)->fetchAll();
   foreach($jobs as &$j)$j['operations']=ops_summary($j);unset($j);json_ok(['jobs'=>$jobs,'page'=>$page,'pages'=>(int)ceil($total/50),'total'=>$total]);
  }
  fail('Neznámá operace.',404);
 }
 $p=payload();$id=positive_id($p['id']??null);get_job($id,$u);
 $moves=['wait_parts','move_yard','depart','take_inside','move_inside','start_outside','receive_yard','update_expected'];
 if(!in_array($action,[...$moves,'prepare_part','receive_part','assign_preparation'],true))fail('Neznámá operace.',404);
 $db=db();$calendar=in_array($action,$moves,true);if($calendar)office_lock_calendar($db);
 try {
  $db->beginTransaction();$op=operation_begin($u,'ops_'.$action,$p);$j=lock_job($id,$u);card_version($p,(int)$j['revision'],'job',['id'=>$id,'revision'=>$j['revision'],'status'=>$j['status']]);
  if($calendar)ops_transition($u,$j,$p,$action);
  elseif($action==='assign_preparation'){
   a_edit($u,'prepare_jobs');$target=empty($p['target'])?null:positive_id($p['target']);
   if($target&&(int)$target!==(int)$u['id']&&(int)$target!==(int)$j['preparation_assigned_to'])permission($u,'assign_jobs');
   if($target&&!query('SELECT id FROM users WHERE id=? AND active=1',[$target])->fetch())fail('Pracovník není aktivní.');
   query('UPDATE jobs SET preparation_assigned_to=?,revision=revision+1 WHERE id=?',[$target,$id]);
   log_event((int)$u['id'],$id,'preparation_assigned','Odpovědnost za přípravu',['before'=>$j['preparation_assigned_to'],'after'=>$target]);
  }else{
   a_edit($u,'prepare_jobs');$task=positive_id($p['task_id']??null);$t=query("SELECT * FROM abc_quick_tasks WHERE id=? AND job_id=? AND kind='part' AND entry_type='work' AND status<>'cancelled' FOR UPDATE",[$task,$id])->fetch();if(!$t)fail('Díl nepatří zakázce.',404);
   card_version(['revision'=>$p['line_revision']??null],(int)$t['revision'],'line',card_line($id,$task));
   if($action==='prepare_part'){
    $stage=post_str($p,'stage',20);if(!in_array($stage,['unknown','identify','needed','ordered'],true))fail('Neplatný stav ruční přípravy.');
    $ordered=($p['ordered_quantity']??'')===''?null:qty($p['ordered_quantity']);if($ordered!==null&&$ordered>100000)fail('Zkontroluj objednané množství.');if($stage==='ordered'&&$ordered===null)fail('U skutečně zadané objednávky vyplň objednané množství.');
    $expected=post_str($p,'expected_on',10);if($expected&&!a_date($expected))fail('Neplatný očekávaný den dodání.');
    $url=post_str($p,'supplier_url',500);if($url&&(!filter_var($url,FILTER_VALIDATE_URL)||!in_array(strtolower(parse_url($url,PHP_URL_SCHEME)?:''),['https','http'],true)))fail('Odkaz dodavatele musí být platná http(s) adresa.');
    $values=[$stage,$ordered,$expected?:null,post_str($p,'supplier_name',160),post_str($p,'order_reference',120),$url,post_str($p,'procurement_note',1000),!empty($p['required_for_start'])?1:0];
    query('UPDATE abc_quick_tasks SET procurement_stage=?,ordered_quantity=?,expected_on=?,supplier_name=?,order_reference=?,supplier_url=?,procurement_note=?,required_for_start=?,revision=revision+1 WHERE id=?',[...$values,$task]);
    log_event((int)$u['id'],$id,'part_prepared','Ruční evidence přípravy #'.$task,['before'=>array_intersect_key($t,array_flip(['procurement_stage','ordered_quantity','expected_on','supplier_name','order_reference','supplier_url','procurement_note','required_for_start'])),'after'=>$values]);
   }else{
    $quantity=qty($p['quantity']??null);if($quantity>100000)fail('Zkontroluj skutečně převzaté množství.');$source=post_str($p,'source',20);if(!in_array($source,['delivery','own_stock','customer'],true))fail('Vyber původ skutečně převzatého dílu.');
    query('INSERT INTO abc_part_receipts(task_id,quantity,unit,source,received_at,received_by,note) VALUES (?,?,?,?,NOW(),?,?)',[$task,$quantity,$t['unit'],$source,$u['id'],post_str($p,'note',500)]);$receipt=(int)$db->lastInsertId();query('UPDATE abc_quick_tasks SET revision=revision+1 WHERE id=?',[$task]);
    log_event((int)$u['id'],$id,'part_received','Skutečné převzetí #'.$receipt,['task_id'=>$task,'quantity'=>$quantity,'unit'=>$t['unit'],'source'=>$source]);
   }
   query('UPDATE jobs SET revision=revision+1 WHERE id=?',[$id]);
  }
  operation_store($op,['job_id'=>$id]);$db->commit();
 }finally{if($calendar)office_unlock_calendar($db);}
 json_ok(['job_id'=>$id]);
}catch(OfficeRule $e){fail($e->getMessage(),409);}
