<?php
declare(strict_types=1);
require __DIR__.'/app/bootstrap.php';
if (($_SERVER['REQUEST_METHOD']??'GET')!=='POST') fail('Použij tlačítko Odhlásit.',405);
require_csrf();$_SESSION=[];session_destroy();
setcookie(session_name(),'', ['expires'=>time()-3600,'path'=>$cookiePath,'secure'=>$secure,'httponly'=>true,'samesite'=>'Lax']);
redirect('index.php');
