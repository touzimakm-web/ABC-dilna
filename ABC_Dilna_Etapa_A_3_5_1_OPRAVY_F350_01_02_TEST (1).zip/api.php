<?php
declare(strict_types=1);
require __DIR__.'/app/bootstrap.php';require __DIR__.'/office_lib.php';
$u=login_required();$action=(string)($_GET['action']??'');$method=$_SERVER['REQUEST_METHOD']??'GET';
if ($method==='GET') {
    if ($action==='list_jobs') {
        $sql="SELECT jobs.*,COALESCE((SELECT DATE(MIN(start_at)) FROM office_appointments a WHERE a.job_id=jobs.id AND a.status IN ('confirmed','requested')),jobs.work_day,DATE(jobs.created_at)) work_date,(SELECT MIN(start_at) FROM office_appointments a WHERE a.job_id=jobs.id AND a.status IN ('confirmed','requested')) appointment_start FROM jobs";$args=[];
        [$where,$args]=a_job_where($u);$sql.=' WHERE '.$where;
        $rows=query($sql.' ORDER BY created_at DESC,id DESC LIMIT 1000',$args)->fetchAll();foreach($rows as &$row)$row['operations']=ops_summary($row);unset($row);json_ok(['jobs'=>$rows]);
    }
    if ($action==='get_job') {
        $id=positive_id($_GET['id']??null);$j=get_job($id,$u);
        json_ok(['job'=>$j,'totals'=>abc_perm($u,'price_jobs')||abc_perm($u,'collect_payments')?totals($id):null,
            'notes'=>query('SELECT n.*,u.name author FROM notes n JOIN users u ON u.id=n.user_id WHERE n.job_id=? ORDER BY n.id DESC',[$id])->fetchAll(),
            'requests'=>query('SELECT * FROM part_requests WHERE job_id=? ORDER BY id DESC',[$id])->fetchAll(),
            'photos'=>[],'items'=>abc_perm($u,'price_jobs')?card_items($id):[],
            'payments'=>abc_perm($u,'collect_payments')?query('SELECT * FROM payments WHERE job_id=?',[$id])->fetchAll():[],
            'permissions'=>array_fill_keys(array_filter(['price_jobs','collect_payments','print_receipts','issue_invoices'],fn($x)=>abc_perm($u,$x)),true)]);
    }
    if ($action==='handover_summary') {
        permission($u,'collect_payments');
        json_ok(['pending'=>query("SELECT p.*,j.vehicle,j.plate FROM payments p JOIN jobs j ON j.id=p.job_id WHERE p.user_id=? AND p.method='cash' AND p.handover_id IS NULL ORDER BY p.id",[$u['id']])->fetchAll(),
            'handovers'=>query('SELECT * FROM cash_handovers WHERE user_id=? ORDER BY id DESC LIMIT 30',[$u['id']])->fetchAll()]);
    }
    fail('Neznámá operace.',404);
}
$p=payload();
if ($action==='submit_handover') {
    permission($u,'collect_payments');$amount=money($p['declared_amount']??null);
    db()->beginTransaction();query('SELECT id FROM users WHERE id=? FOR UPDATE',[$u['id']]);$op=operation_begin($u,'cash_handover',$p);
    $pending=query("SELECT id,amount FROM payments WHERE user_id=? AND method='cash' AND handover_id IS NULL FOR UPDATE",[$u['id']])->fetchAll();
    $expected=round(array_sum(array_column($pending,'amount')),2);
    if (!$pending||$expected<=0) fail('Žádná hotovost k předání.',409);
    if (abs($amount-$expected)>.009) fail('Předávaná částka musí odpovídat evidované hotovosti.',409);
    query('INSERT INTO cash_handovers(user_id,declared_amount) VALUES (?,?)',[$u['id'],$amount]);$id=(int)db()->lastInsertId();
    query("UPDATE payments SET handover_id=? WHERE user_id=? AND method='cash' AND handover_id IS NULL",[$id,$u['id']]);
    log_event((int)$u['id'],0,'cash_submitted','#'.$id.' '.$amount.' Kč');operation_commit($op,['id'=>$id]);
}
$id=positive_id($p['id']??null);
if ($action==='claim_job') {
    permission($u,'take_jobs');db()->beginTransaction();
    $j=query('SELECT * FROM jobs WHERE id=? FOR UPDATE',[$id])->fetch();
    if (!$j) fail('Zakázka neexistuje.',404);
    if ($j['assigned_to']||in_array($j['status'],['done','closed'],true)) fail('Zakázka už není volná.',409);
    query('UPDATE jobs SET assigned_to=? WHERE id=?',[$u['id'],$id]);log_event((int)$u['id'],$id,'claimed');db()->commit();json_ok();
}
get_job($id,$u);
// Jednotné pořadí zámků při platbách a předávání hotovosti.
if ($action==='add_payment') { permission($u,'collect_payments');db()->beginTransaction();query('SELECT id FROM users WHERE id=? FOR UPDATE',[$u['id']]); }
else {if($action==='set_status'&&($p['status']??'')==='parts')office_lock_calendar(db());db()->beginTransaction();}
$op=operation_begin($u,$action==='add_payment'?'payment':$action,$p);
$j=lock_job($id,$u);
if ($action==='set_status') {
    a_edit($u,'change_status');
    card_version($p,(int)$j['revision'],'job',array_intersect_key($j,array_flip(['id','status','revision'])));
    $status=post_str($p,'status',20);
    $allowed=['new'=>['work','review','done'],'work'=>['review','done','parts'],'parts'=>['work','review','done'],'review'=>['work','done'],'done'=>['work','parts','closed'],'closed'=>['work','parts']];
    if (!in_array($status,$allowed[$j['status']]??[],true)) fail('Tato změna stavu není možná.',409);
    if ($status==='closed') permission($u,'collect_payments');
    if (in_array($status,['work','parts'],true)&&in_array($j['status'],['done','closed'],true)) {
        if (totals($id)['paid']>0||query("SELECT id FROM office_invoices WHERE job_id=?",[$id])->fetch()) fail('Vyúčtovanou zakázku nelze znovu otevřít.',409);
    }
    if($status==='done'&&card_incomplete_labor($id))fail('Nejdříve označ provedené práce jako hotové.',409);
    if ($status==='closed') { require_priced($id);if(totals($id)['due']>.009)fail('Nejprve uhraď zbývající částku.',409); }
    if($status==='parts'&&ops_active($id)){ops_transition($u,$j,$p,'wait_parts');operation_commit($op,['job'=>['id'=>$id,'status'=>'parts','revision'=>(int)$j['revision']+1],'totals'=>totals($id)]);}
    if($status!=='done'&&$status!=='closed')a_reset_queue($j);
    query('UPDATE jobs SET status=?,revision=revision+1 WHERE id=?',[$status,$id]);log_event((int)$u['id'],$id,'status',$status,['before'=>$j['status'],'after'=>$status]);
} elseif ($action==='add_note') {
    a_edit($u);
    $body=post_str($p,'body',3000);if(mb_strlen($body)<3)fail('Napiš delší poznámku.');
    query('INSERT INTO notes(job_id,user_id,kind,body) VALUES (?,?,?,?)',[$id,$u['id'],'work',$body]);log_event((int)$u['id'],$id,'note_added');
} elseif ($action==='add_request') {
    a_edit($u,'edit_lines');
    if($j['status']==='closed')fail('Zakázka je uzavřená.',409);
    $desc=post_str($p,'description',220);if(mb_strlen($desc)<3)fail('Popiš požadovaný díl.');
    query('INSERT INTO part_requests(job_id,user_id,description,quantity) VALUES (?,?,?,?)',[$id,$u['id'],$desc,qty($p['quantity']??1)]);log_event((int)$u['id'],$id,'part_requested',$desc);
} elseif ($action==='set_discount') {
    permission($u,'discount_jobs');a_edit($u);card_version($p,(int)$j['revision'],'job',array_intersect_key($j,array_flip(['id','status','revision'])));if($j['status']==='closed'||totals($id)['paid']>0||query('SELECT id FROM office_invoices WHERE job_id=?',[$id])->fetch())fail('Vyúčtovanou cenu nelze měnit.',409);
    $amount=money($p['amount']??null);$reason=post_str($p,'reason',200);$t=totals($id);if($amount>$t['estimated_subtotal']+.009||($amount>0&&!$reason))fail('Sleva musí být nejvýše cenou zakázky a mít důvod.');
    query('UPDATE jobs SET discount_amount=?,discount_reason=?,revision=revision+1 WHERE id=?',[$amount,$reason,$id]);log_event((int)$u['id'],$id,'discount_changed',json_encode(['old'=>$j['discount_amount'],'new'=>$amount,'reason'=>$reason],JSON_UNESCAPED_UNICODE));
} elseif ($action==='add_payment') {
    issuer_ready();
    if(!empty($config['company_vat'])&&!query('SELECT id FROM office_invoices WHERE job_id=?',[$id])->fetch())fail('U plátce DPH nejprve vystav fakturu. Potom k ní přijmi hotovost nebo kartu; potvrzení platby nenahrazuje daňový doklad.',409);
    if(!in_array($j['status'],['done','closed'],true))fail('Platbu lze přijmout po dokončení opravy.',409);
    if(card_incomplete_labor($id))fail('Nejdřív dokonči nově přidané práce.',409);
    require_priced($id);$amount=money($p['amount']??null);$method=post_str($p,'method',20);
    if(!in_array($method,['cash','card','transfer'],true))fail('Neplatný způsob platby.');
    if($method==='transfer'&&!abc_perm($u,'confirm_transfers'))fail('Převod potvrzuje majitel.',403);
    $t=totals($id);if($t['discount']>$t['subtotal']+.009)fail('Uprav slevu podle skutečně použitých položek.',409);if($amount<=0||$amount>$t['due']+.009)fail('Platba musí být kladná a nejvýše ve výši nedoplatku.',409);
    query('INSERT INTO payments(job_id,user_id,amount,method) VALUES (?,?,?,?)',[$id,$u['id'],$amount,$method]);$payment=(int)db()->lastInsertId();
    log_event((int)$u['id'],$id,'payment_added','#'.$payment.' '.$amount.' Kč '.$method);
    $supplier=[];foreach(['company_name','company_address','company_ico','company_phone','company_email','company_bank_account','company_vat','company_dic'] as $key)$supplier[$key]=$config[$key];
    $invoice=query('SELECT invoice_no,customer_name,customer_address,customer_ico,supplier_json FROM office_invoices WHERE job_id=?',[$id])->fetch();if($invoice){$original=json_decode($invoice['supplier_json'],true);$supplier=array_replace($supplier,array_intersect_key($original,$supplier));}$number='P-'.date('Y').'-'.str_pad((string)$payment,6,'0',STR_PAD_LEFT);
    $j=array_replace($j,card_identity($id)['fields']);
    $snapshot=['supplier'=>$supplier,'customer_name'=>$invoice['customer_name']??$j['customer_name'],'customer_address'=>$invoice['customer_address']??'','customer_ico'=>$invoice['customer_ico']??'','collector_name'=>$u['name'],'plate'=>$j['plate'],'vehicle'=>$j['vehicle'],'invoice_no'=>$invoice['invoice_no']??null,'job_total'=>$t['total'],'amount'=>$amount,'method'=>$method,'recorded_at'=>date('Y-m-d H:i:s')];
    query('UPDATE payments SET receipt_no=?,snapshot_json=? WHERE id=?',[$number,json_encode($snapshot,JSON_UNESCAPED_UNICODE),$payment]);
    query('INSERT IGNORE INTO abc_job_access(job_id,user_id,granted_by) VALUES (?,?,?)',[$id,$u['id'],$u['id']]);
    query("UPDATE jobs SET billing_state='documented',revision=revision+1 WHERE id=?",[$id]);
    operation_commit($op,['payment_id'=>$payment,'totals'=>totals($id)]);
} else fail('Neznámá operace.',404);
operation_commit($op,['job'=>['id'=>$id,'status'=>$status??$j['status'],'revision'=>(int)$j['revision']+($action==='set_status'||$action==='set_discount'?1:0)],'totals'=>totals($id)]);
