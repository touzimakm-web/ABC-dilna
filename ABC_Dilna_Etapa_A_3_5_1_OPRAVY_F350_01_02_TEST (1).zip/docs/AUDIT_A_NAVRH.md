# Audit před úpravami – ABC Dílna 3.0

Podklad: dodaný ZIP 2.0.6 (13 souborů dílčí aktualizace), samostatný SQL soubor odhadů a kompletní PHP projekt 2.1.1 z této konverzace. Originály zůstávají v samostatných adresářích; inventář a SHA-256 úplného základu jsou v `source-inventory.json`. Produkční FTP ani databáze nejsou k dispozici a nebudou měněny.

## Funkční základ k zachování

PHP + PDO MySQL/MariaDB; společné tabulky zákazníků, vozidel, vazeb historie, zakázek, úkonů, položek, kalendáře, odhadů, faktur, úhrad a předání hotovosti. Vlastní účty, hashovaná hesla, role a živé ověřování oprávnění, CSRF, transakční zámky zakázek a peněz, oddělené účetní úhrady. Ruční údaje, vlastní ceník a samostatné tiskové dokumenty fungují bez API klíčů. Oprava cesty session cookie podle veřejné URL z 2.1.1 zůstane zachovaná.

## Zjištěné vady a rozdíly proti novému zadání

- Karty požadavků sice při příjmu nevytvoří cenu, ale ukládají se do stejné evidence jako provedené úkony a obecná kontrola nacenění je před fakturací vyžaduje zpoplatnit nebo zrušit. Chybí jednoznačný typ požadavek / skutečná práce.
- Úvod má velká tlačítka až pod dlouhými seznamy, další volby a vysvětlující text. JS obsahuje i starý nedosažitelný čtyřkrokový průvodce. Aktivní příjem již používá mechanic_work.php, ten se zachová jako společný vstup pro všechny služby.
- Nové auto se do zákaznické evidence uloží pouze po zvláštním zaškrtnutí; samotná SPZ tedy nemusí být dohledatelná při další návštěvě.
- Množství v aktivním pracovním formuláři dovoluje jen celé kusy, přestože databáze podporuje desetinná množství (např. olej).
- Aktivní pracovní karta po vystavení faktury skryje příjem plateb. Backend částečné úhrady podporuje, ale mechanikův formulář nabízí pouze celý nedoplatek.
- Ochrana opakovaného kliknutí je převážně v JS. Zamknutí a kontrola nedoplatku brání přeplatku celé faktury, ale opakované částečné platbě nebo stejné zakázce nezaručuje identickou odpověď.
- Historie cen nezachycuje původní i novou cenu strukturovaně; u příjmového dokladu není uložený snímek odběratele a dodavatele.
- Zakázkový list je svázaný s uloženým oceněným odhadem; má jít vytisknout i před naceněním.
- Kalendář musí trvale rozlišovat rezervaci od evidenčního času neobjednaného příjmu. Interní session cesta WEDOS se nesmí znovu použít jako veřejná cesta cookie.

## Jednoduché obrazovky

1. Mechanik: pozdrav, čtyři velká tlačítka Rychlá zakázka / Moje auta / Kalendář / Pokladna, pak dnešní auta. Modrá, zlatá, bílá; žádné žebříčky, stopky ani dashboard se statistikami.
2. Rychlá zakázka: jedno hledání SPZ/zákazníka, automatické výsledky, více karet služeb, nepovinná poznámka. Další údaje a termín jsou sbalené. Jediné uložení bez cen a bez průvodce vrátí mechanika na úvod.
3. Pracovní karta: stejná pro všechny služby; nahoře auto a požadavky, dále práce a materiál s cenami a dokončením. Jednoduché přidání z ceníku nebo vlastní položky, skutečná desetinná množství. Poznámky a díly k zajištění jsou dostupné bez přerušení zakázky. Průběžná cena, zakázkový list a dokončení na této kartě.
4. Dokončení: hotovost / karta / faktura; skutečné platby mají vlastní potvrzení a částku včetně částečné úhrady. Faktura se nevydává za platbu. Existující fakturu lze otevřít a následně uhradit ze stejné pracovní karty.
5. Majitel: zachovaný desktopový přehled, zákazníci a jejich vozidla, historie, ceník, přidělení mechanika a kolize kalendáře, pohledávky, platby a potvrzení převzaté hotovosti.

## Databáze a nasazení

Nová verze se připravuje odděleně. Čistá instalace vytváří prázdnou databázi bez ukázkových zákazníků a cen. Pro známé schéma 2.1.1 bude samostatná přidávací migrace ověřující skutečnou strukturu. Staré úkony se nebudou automaticky přeznačovat podle odhadovaného významu. Původní tabulky a ID zůstanou zachované. Neznámá produkční schémata vyžadují původní kompletní soubory a strukturu SQL; migrace se nebude domýšlet.

## Ověření

Vedle HTTP a databázových kontrol budou provedené skutečné scénáře v dostupném samostatném Chromium, na mobilním rozměru i na desktopu a v oddělených relacích mechanika a majitele. Provoz na vzdáleném WEDOSu a fyzická tiskárna zůstávají přejímací zkouškou uživatele. Žádná externí integrace se nebude označovat jako připojená bez skutečného přístupu.
