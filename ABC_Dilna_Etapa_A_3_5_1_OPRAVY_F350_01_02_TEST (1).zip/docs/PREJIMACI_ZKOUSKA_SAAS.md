# Přejímací zkouška SaaS na cílovém WEDOSu

Použijte nové testovací databáze a nejméně dva nezávislé profily prohlížeče. Všechny testovací položky vědomě označte jako testovací, nepoužívejte je jako skutečné účetní doklady.

1. Provozovatel instaluje prázdnou platformu, přihlásí se po obnově stránky. Bez něj není správa klientů dostupná. Zaměstnanec klienta se na platformu svým účtem nedostane.
2. Založí vlastní tarif a dva klienty s různými DB a SQL uživateli. Každý majitel si nastaví vlastní heslo a údaje firmy. Lze použít stejný e-mail v obou servisech.
3. Oba vytvoří zákazníka, auto se stejnou SPZ, položku ceníku s jinou cenou a první zakázku. Vyhledávání, tisk i přehled se musí týkat pouze aktuálního servisu i při shodě číselných ID. SQL uživatel A nesmí číst DB B.
4. Majitel založí mechanika a přiřadí oprávnění. Mechanik na Samsungu vidí čtyři velké akce a dnešní auta. Nesmí mít přístup do firemního nastavení, správy předplatného ani celkového exportu.
5. Mechanik založí rychlou zakázku jen SPZ + tři karty služeb. Uložení nevyžaduje termín, cenu, díl ani hodiny. Do účtovaných položek se nesmí přidat nic. Obnova stránky uchová přihlášení.
6. Existující SPZ/jméno se nabízí z vlastní DB. Termín je nepovinný; pokud ho zadá, kalendář ukáže stejnou zakázku. Bez termínu zůstane jen evidenční čas přijetí.
7. Pracovní karta: později přidá práci z ceníku, ruční práci, vlastní díl bez skladové karty, olej s desetinným množstvím a další úkon po opětovném otevření. Cenu lze doplnit později, práce odškrtnout. Poptané karty se neúčtují podruhé.
8. Vytiskne neoceněný zakázkový list. Faktura vytvořená po dokončení zůstane bez platby. Ověřte vlastní číselnou řadu a neplátcovský text u neplátce. U plátce ověřte DIČ, datum plnění, konečnou cenu, základ a DPH 21 %; nejprve faktura, pak platba.
9. Zapíše část hotově, část kartou. Majitel potvrdí skutečný převod zbývající částky. Dvojí klik / opakování stejného požadavku nesmí vytvářet další úhradu. Mechanik předá jen hotovost; převzetí majitelem nesmí zdvojnásobit příjem.
10. Provozovatel vytvoří předpis předplatného a zadá číslo skutečné externí faktury. Bez platby se přístup nezmění. Část platby neprodlouží celý měsíc; doplatek ano. Přijaté předplatné se neobjeví v zákaznických penězích autoservisu.
11. Pozastavte A s důvodem. A nesmí uložit obchodní změnu, musí ale číst zakázky, tisknout faktury a stáhnout vlastní JSON export. B pracuje dál. Stejně vyzkoušejte propadnutí data a znovupřihlášení.
12. V jedné záložce rozepsat příjem A, odhlásit, přihlásit B. Koncept A se v B neobjeví. Stará obrazovka při API požadavku s jiným kontextem nesmí vykonat operaci.
13. Na telefonu ověřte šířky, tlačítka a skutečný tisk/PDF. Žádný vodorovný posun pracovní karty. Na počítači zkontrolujte přehled všech mechaniků jen vlastního servisu.
14. Vytvořte SQL zálohy platformy a klientů, zálohu konfigurace včetně platform_secret a na odděleném testu ověřte obnovu. JSON export musí mít vlastní data a nesmí obsahovat hesla, šifrované DB přístupy ani druhý servis.
15. Ověřte HTTPS, nepřístupnost app/config.php, SQL, storage a tests přes web a funkční relace po obnovení. Neřešte chybu relace odstraněním CSRF nebo nastavením 777.

Starou aplikaci přepínejte až po úspěšné zkoušce a záloze. Dodaný ZIP nic nepřepíná ani nenahrává na vzdálený web. Fyzickou tiskárnu a konkrétní Samsung místní headless test nenahrazuje.
