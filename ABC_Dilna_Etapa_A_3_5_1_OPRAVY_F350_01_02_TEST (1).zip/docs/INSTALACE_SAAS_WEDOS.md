# Instalace SaaS 3.1 na WEDOS

Nejprve celý postup proveďte v nové složce a nových databázích. Původní aplikaci ani její databázi neměňte. Konkrétní limity svého tarifu (počet DB, spojení, PHP paměť) ověřte v administraci WEDOS před zřízením klientů.

## 1. Soubory a konfigurace platformy

1. Vytvořte `/www/domains/dilna.abcautosluzby.cz/abc-saas-test/`. Nahrajte obsah ZIPu tak, aby v této složce ležely přímo `index.php`, `platform.php`, `app`, `assets` a kořenový `.htaccess`. Nenahrávejte do živé složky `/nova/`.
2. Vyberte PHP 8.1+ s PDO MySQL, mbstring, OpenSSL a funkčními sessions. Oprávnění adresářů musí umožňovat průchod; nepoužívejte plošné 777. Systémové úložiště sessions se nenastavuje přes FTP práva aplikace. Používejte HTTPS.
3. Přes WEDOS vytvořte novou prázdnou databázi platformy a jejího vlastního uživatele. Tento uživatel nepotřebuje přístup do zákaznických databází. Pro instalaci musí mít DDL práva v této databázi.
4. Zkopírujte `app/config.example.php` na `app/config.php`. Vyplňte `platform_db_host`, port, název, uživatele a heslo. Použijte skutečný databázový server z WEDOS, nikoli automaticky localhost. Hesla neposílejte do chatu.
5. Otevřete `https://dilna.abcautosluzby.cz/abc-saas-test/generator_klicu.html`. Stiskněte generování a obě hodnoty vložte jako pevné řetězce do konfigurace. `platform_secret` má 64 hexadecimálních znaků; `platform_setup_token` má nejméně 24 znaků. Nechte je v uvozovkách. Klíč se nesmí nově generovat při každém PHP požadavku.
6. Otevřete `platform_setup.php`, vložte instalační klíč platformy a zvolte jméno, e-mail a vlastní heslo nejméně 12 znaků. Instalátor odmítne jakoukoliv neprázdnou databázi a nikdy nevytváří výchozí heslo.
7. Přihlaste se na `platform.php`. Přes Měsíční tarify vytvořte vlastní skutečnou cenu. Není vložený žádný falešný ceník ani bankovní údaje.

## 2. První klientský servis

1. Na WEDOSu vytvořte další novou prázdnou databázi. Její uživatel musí mít přístup pouze do ní. Účet platformy nepoužívejte znovu jako uživatele klientské DB.
2. Na `platform.php` rozbalte Založit nový klientský servis. Vyplňte skutečný název, jedinečný kód (například `abc-autosluzby`), DB přístupy a tarif. Kód má 3–60 malých písmen/číslic/pomlček a začíná číslicí nebo písmenem.
3. Po uložení se jednou zobrazí instalační klíč tohoto servisu a odkaz `setup.php?servis=abc-autosluzby`. Přístupy DB se zpětně nevypisují. Klíč předejte majiteli důvěrně. Toto předání není automatický e-mail.
4. Majitel na nabídnutém odkazu vloží instalační klíč servisu a zvolí vlastní přihlášení. Tím se vytvoří tabulky pouze v nové databázi tohoto servisu. Provozovatel nepotřebuje znát jeho přihlašovací heslo.
5. Majitel vstoupí přes `index.php?servis=abc-autosluzby`. V Nastavení otevře Údaje firmy a vyplní skutečné jméno/název, adresu, IČO, bankovní účet, případné DIČ a plátcovství. Bez základních údajů nelze vystavit fakturu ani potvrdit zákaznickou platbu.
6. Založí tým, oprávnění a skutečný ceník. Zaměstnanci stejného servisu mají společnou DB a oddělené účty. Ceny se zadávají jako konečné částky.
7. Založte druhý testovací servis se svou databází. V různých prohlížečích/nezávislých profilech ověřte, že zákazníci a doklady zůstávají oddělené. Jedna běžná relace prohlížeče je přihlášená právě do jednoho servisu; před změnou kódu se musí odhlásit.

Po ověření smažte `platform_setup.php`, `generator_klicu.html` a vyprázdněte `platform_setup_token`. `platform_secret` zachovejte a bezpečně zálohujte. `setup.php` ponechte pro nové klienty; každá instalace vyžaduje unikátní klíč a prázdnou DB. Na již nainstalovanou DB odmítne znovu instalovat. `upgrade.php` je pouze pomocník pro kopie známých starších schémat a po dokončení převodů ho lze z veřejného webu odstranit.

## 3. Připojení existující kopie 3.0

Připojení mění schéma této kopie. Živou databázi nepřipojujte.

1. Ze staré aplikace exportujte SQL a zazálohujte soubory i config. SQL importujte do nové samostatné databáze, přidejte jejího samostatného uživatele.
2. V založení servisu vyplňte přístup jen do této kopie. Zaškrtněte Připojit existující kopii 3.0 a potvrzení samostatné kopie se zálohou. Neznámé schéma je odmítnuté. Původní ZIP 2.0.6 je částečná aktualizace, nelze jej vydávat za úplný DB export.
3. Připojení ověří původní tabulky a pouze přidá identitu servisu, nastavení firmy a DIČ. Původní uživatelé, hesla, ID, zákazníci, platby a faktury zůstávají. Nový instalační klíč se u připojené kopie nevytváří.
4. Přihlaste se původním majitelským účtem přes nový kód a nastavte údaje firmy. Dříve vystavené faktury zůstávají se svým uloženým dodavatelem.
5. Pokud se připojení přeruší, servis zůstane ve stavu Čeká na instalaci. Po kontrole práv a zálohy lze na jeho kartě použít Dokončit připojení. Opakovaná přidávací migrace nemaže data. Při chybě čisté instalace nejprve prohlédněte chybu a stav tabulek; instalátor neprázdnou DB úmyslně nepřepisuje.

Známé 2.1.1 lze nejprve na samostatné kopii převést přes postup 3.0, potom připojit tuto kopii. Nemigrujte přímo neznámou databázi z produkce.

## 4. Měsíční platby

Nový klient má 14 dní pro ověření. Ruční změna přístupu vyžaduje důvod a zapisuje historii. Tarif je konečná měsíční částka. Předpis pokrývá měsíc ode dne po konci aktuálního přístupu, nejdříve ode dneška; konec se přizpůsobí délce měsíce. Předpis pro stejné období nelze založit podruhé.

Přes Vytvořit předpis se uloží **interní evidence předplatného**. Skutečnou fakturu za pronájem vystavte ve svém fakturačním systému (např. iDoklad) a zadejte její číslo u předpisu. Aplikace do iDokladu nic neposílá. Po kontrole banky potvrďte skutečnou částku a referenci. Lze potvrdit část; celý měsíc se prodlouží až po doplacení. Opakované potvrzení stejným klíčem nevytvoří další platbu. Přepsání již přijaté platby a vratky nejsou v této verzi dostupné.

Propadlé nebo pozastavené předplatné zablokuje obchodní POST operace na serveru. Prohlížení, tisk a vlastnický export zůstávají dostupné. Úplné doplacení prodlužuje datum, samo neruší výslovné pozastavení provozovatelem. Zákaznické peníze autoservisu se s předplatným aplikace nesměšují.

## 5. Zálohy a provoz

Zálohujte SQL platformy, SQL každého servisu, soubory a původní `platform_secret` z konfigurace. Ztráta klíče znamená ztrátu možnosti dešifrovat připojení v registru. Nově vygenerovaný klíč staré přístupy neopraví. JSON export klienta obsahuje obchodní data, nikoli hesla či přístupy; není plnou SQL zálohou. Zálohy uchovávejte mimo veřejnou složku webu. Obnovu nejprve vyzkoušejte do oddělených DB a neveřejného testovacího prostředí.

Ověřte, že přímé URL `app/config.php`, `sql/schema.sql`, `storage/` a `tests/` nepovolují čtení. Konkrétní Apache/.htaccess, sessions, tiskárna a limity tarifu se ověřují až na vašem hostingu. Provozujte pilot na testovacích datech, dokud nedokončíte přejímací zkoušku. Před veřejným prodejem zbývá vlastní obchodní nastavení služby, provozní zálohování/obnova a cílová platební integrace podle zvoleného způsobu účtování; tyto věci kód na WEDOS automaticky nezřizuje.
