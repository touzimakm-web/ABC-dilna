> Archivní dokumentace verze 3.0. Pro tuto SaaS verzi začněte [instalací 3.1](INSTALACE_SAAS_WEDOS.md).

# Bezpečná instalace na WEDOS

## Co připravit

PHP 8.1 nebo novější, rozšíření PDO MySQL, mbstring, ctype a JSON; MySQL 8 nebo MariaDB 10.6+, InnoDB a utf8mb4. Vlastní HTTPS doména. Apache musí respektovat `.htaccess`. cURL potřebuje pouze volitelná AI, běžný provoz bez API funguje.

## Nová testovací instalace

1. Zálohujte soubory dosavadního webu a exportujte jeho databázi v phpMyAdmin. Export ukládejte mimo veřejnou webovou složku.
2. Vytvořte **novou** složku `/www/domains/dilna.abcautosluzby.cz/abc-test`. Nepoužívejte složku stávající aplikace, například `/nova`, pokud v ní dosud pracujete.
3. Nahrajte a rozbalte instalační ZIP do nové složky. Rozbalte i skryté `.htaccess`. Vedle `index.php` musí být `setup.php`, `app`, `assets`, `sql`. Samotné nahrání archivu aplikaci nenainstaluje. ZIP následně z webové složky odstraňte.
4. V administraci založte samostatnou prázdnou databázi. Pro instalaci použijte databázového uživatele s právem vytvářet tabulky. Názvy a server zkopírujte z administrace; `localhost` v příkladu není automaticky správný server WEDOSu.
5. Zkopírujte `app/config.example.php` na `app/config.php`. Doplňte hostitele, port, název **testovací** databáze, jejího uživatele a heslo. Zadejte vlastní náhodný `setup_token` alespoň 24 znaků. Nepoužívejte zástupné hodnoty z příkladu.
6. Zkontrolujte název firmy, celou adresu, IČO, kontakty a bankovní účet. Doklady jsou pro neplátce DPH. API klíče nechte prázdné, pokud integraci nechcete používat.
7. Otevřete `https://dilna.abcautosluzby.cz/abc-test/setup.php`. Zadejte instalační klíč, jméno a e-mail majitele a jeho vlastní heslo (alespoň 12 znaků, nejvýše 72 bajtů). Instalátor odmítne databázi, která už obsahuje tabulky.
8. Přihlaste se, vytvořte účty mechaniků a nastavte jejich oprávnění. Přidejte skutečné položky ceníku; žádné zkušební částky se do nové databáze nedosazují. Pro běžnou práci s cenami a platbami dejte zvolenému mechanikovi příslušná oprávnění. Oprávnění lze později odvolat.
9. Na telefonu přihlaste mechanika a na počítači majitele. Projděte přejímací scénář. Oba musí pracovat proti stejné testovací databázi. Změny se ukládají na server, nikoli do localStorage telefonu.
10. Po úspěšné instalaci odstraňte ze serveru `setup.php` a `upgrade.php` a vyprázdněte `setup_token` v konfiguraci. Testovací zdrojové soubory nemusíte na hosting nahrávat. Pro důkaz ochrany ověřte, že `/abc-test/app/config.php`, `/abc-test/sql/schema.sql`, `/abc-test/tests/evidence/results.json` a výpis adresáře vracejí zákaz přístupu.

## Kopie existujících dat

Postupujte podle [MIGRACE_300.md](MIGRACE_300.md). Importujte zálohu do samostatné databáze, nastavte na ni novou testovací aplikaci a spusťte přidávací migraci. Původní databázi k nové verzi během prvního testování nepřipojujte.

## Přihlášení a chyba formuláře

Oprava 2.1.1 používá veřejnou cestu z REQUEST_URI. Interní cesta typu `/domains/dilna.abcautosluzby.cz/...` se do cookie nepropíše. Verze 3.0 má odlišný název cookie pro každou veřejnou instalační cestu a vazbu relace na databázi. Po přechodu na 3.0 je nové přihlášení očekávané; obnova stránky přihlášení zachovává.

CSRF zůstává zapnuté. Při problému ověřte skutečně vydanou cookie a její cestu, HTTPS, čas a dostupnost PHP `session.save_path` v chybovém logu. Neodstraňujte CSRF ani neměňte náhodně práva jiných hostingových adresářů. Aplikace při nefunkčním úložišti relací oznámí konkrétní problém; neinicializuje nezabezpečenou náhradní relaci.

## Přepnutí provozu

Tato dodávka nezasahovala do vzdáleného WEDOSu. Před přepnutím ověřte funkci `.htaccess`, relace, tisk, zálohy, firemní údaje a databázové vazby na vašem skutečném hostingu. Pak naplánujte finální export/import, aby se mezi kopií a spuštěním neztratily nově zadané zakázky. Přepnutí adresy a databáze má následovat až po vašem otestování nové verze. Původní web a zálohu zachovejte.
