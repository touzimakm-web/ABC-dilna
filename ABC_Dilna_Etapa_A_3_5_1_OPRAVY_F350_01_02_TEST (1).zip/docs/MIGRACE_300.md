> Archivní dokumentace verze 3.0. Pro tuto SaaS verzi začněte [instalací 3.1](INSTALACE_SAAS_WEDOS.md).

# Přidávací migrace 2.1.1 → 3.0.0

Migrace je v `app/migrations.php`, spouštěcí stránka `upgrade.php`. Před změnou ověří všechny tabulky a sloupce známého úplného schématu 2.1.x. Dílčí ZIP 2.0.6 tuto databázi neobsahuje. Pro jiné schéma je nutný jeho skutečný export struktury a odpovídající zdroje; migrace se nesmí domýšlet.

1. Zálohujte dosavadní soubory i databázi.
2. V phpMyAdmin vytvořte novou testovací databázi a importujte do ní kopii zálohy. Ponechte původní ID, kódování a tabulky.
3. Nahrajte 3.0 do nové složky `/abc-test/`. V konfiguraci zadejte pouze novou databázovou kopii a uživatele s oprávněním ALTER/CREATE/INDEX.
4. Přihlaste se původním účtem majitele z této kopie. Aplikace nabídne `upgrade.php`.
5. Potvrďte, že jde o testovací kopii se zálohou, a spusťte migraci.
6. Ověřte počty a obsah zákazníků, aut, vazeb historie, zakázek, faktur a plateb před a po změně. Úspěšná migrace je opakovatelná; nepřidá znovu stejné sloupce ani nezaloží nové zákaznické řádky.
7. U dosud neoceněných starších obecných úkonů rozhodněte, zda jde o požadavek zákazníka. Na pracovní kartě je případně převeďte přes Upravit → Pouze požadavek zákazníka. Migrace se nerozhoduje podle podobnosti názvu a neupravuje zaplacené nebo vyfakturované položky.
8. Dokončete přejímací zkoušku. Po ověření odstraňte `upgrade.php` a `setup.php` ze serveru.

## Co se přidává

- `jobs.discount_amount`, `jobs.discount_reason` – sleva majitele.
- `abc_quick_tasks.entry_type`, `request_task_id` – rozlišení požadavku a skutečné práce a případná vazba.
- `payments.receipt_no`, `snapshot_json` a unikátní index čísla dokladu – nové uložené doklady o úhradě.
- `office_invoices.discount_amount` – sleva ve vystaveném dokladu.
- `abc_request_keys` – trvalé klíče opakovaných operací, cizí klíč na uživatele.
- `abc_price_history` – původní a nová cena, množství, pracovník a čas změny.
- Řádek `3.0.0` do `schema_meta`.

Starší řádky úkonů dostanou výchozí typ `work`; jejich původní obsah a vazby se nemění. Starší příjmové doklady nemohou zpětně získat neexistující identifikační snímek. Jejich původní čísla zůstávají při tisku zachovaná. Nové platby již ukládají vlastní číslo a snímek.

Neprovádí se DROP, TRUNCATE ani mazání zákaznických tabulek. DDL v MySQL/MariaDB může implicitně potvrzovat dílčí změny. Při nedostatku práv proto nepřepínejte provoz a zkontrolujte serverový log; po opravě práv je možné přidávací migraci zopakovat na kopii. Automatický návrat mazáním sloupců není součástí aplikace. Pro návrat použijte nedotčenou původní instalaci a její databázi.
