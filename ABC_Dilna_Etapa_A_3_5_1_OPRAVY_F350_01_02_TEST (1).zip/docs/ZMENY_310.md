# Změny 3.1.0 proti 3.0.0

- Společná aplikace pro více servisů, každý se samostatnou DB a SQL účtem. Zachovaný tok mechanika a recepce i původní vazby.
- Samostatné přihlášení provozovatele, registry klientů, vlastní tarify, zřizování servisů, měsíční předpisy, externí fakturační reference a skutečně potvrzené částečné platby předplatného.
- Propojení zaplaceného období s přístupem; pozastavený/propadlý účet může dál číst, tisknout a exportovat.
- Oddělení servisů v relaci, SQL připojení, DB identitě, prohlížečových konceptech a kontextu API. Registr šifruje přístupy AES-GCM serverovým klíčem.
- Majitel má vlastní firmu a firemní údaje, přehled předplatného a export dat bez hesel.
- Neplátce DPH i standardní tuzemský plátce 21 % se snímkem vyčíslení při vystavení. U plátce se platby přijímají k vystavené faktuře.
- Připojení samostatné známé kopie 3.0 přidávací migrací; původní údaje a účty zůstávají. Živý původní systém nebyl upravený.
- Nové skutečné HTTP/DB/prohlížečové testy izolace klientů, oprávnění provozovatele, předplatného, expirace, exportu a DPH. Opakované ověření celého pracovního postupu 3.0.
- WEDOS postup platformy, databází klientů, prvních dvou servisů, přenosu kopie a záloh včetně šifrovacího klíče.

Automatické platby kartou za předplatné, automatické zřizování DB/e-maily, storna/vratky, úplné účetnictví, EET, registr vozidel a přímé objednávání u dodavatelů nejsou nově připojené. Žádná integrační data nejsou simulovaná.
