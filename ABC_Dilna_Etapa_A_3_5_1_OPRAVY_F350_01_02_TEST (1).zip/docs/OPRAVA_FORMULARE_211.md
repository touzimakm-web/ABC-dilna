# Oprava 2.1.1: formuláře na WEDOSu

Příčina: WEDOS přepisuje interní `SCRIPT_NAME` například na `/domains/dilna.abcautosluzby.cz/nova/setup.php`. Verze 2.1.0 z této hodnoty odvozovala cestu session cookie. Prohlížeč na veřejné adrese `/nova/setup.php` tak cookie neposlal zpět a další požadavek dostal novou relaci i CSRF token.

Oprava odvozuje rozsah cookie z veřejné cesty v `REQUEST_URI`. Instalační adresa se tedy vztahuje k `/nova/`. Platí také pro přihlášení, API a odhlášení. Kontrola CSRF zůstává zachovaná.

## Použití malé aktualizace

1. V WebFTP otevřete `/www/domains/dilna.abcautosluzby.cz/nova`.
2. Zálohujte dosavadní `app/bootstrap.php` stažením do zařízení.
3. Nahrajte a rozbalte `ABC_Dilna_OPRAVA_FORMULARE_211.zip` přímo do této složky. Povolte nahrazení `app/bootstrap.php`. Archiv obsahuje jen opravený bootstrap a tento instalační návod.
4. Znovu otevřete `https://dilna.abcautosluzby.cz/nova/setup.php` jako nově načtenou stránku. Původní otevřený formulář nepoužívejte.

Balíček neobsahuje `config.php` ani SQL. Hesla, instalační klíč a databáze se nemění. Další změny oprávnění adresářů nejsou pro tuto chybu potřeba.

## Ověření

- Přes veřejné GET požadavky bylo na hostingu potvrzeno, že původní cookie měla chybnou interní cestu. Po opravě cesty pouze v kontrolním klientovi se CSRF token zachoval mezi načteními. Serverové soubory ani obchodní data nebyly tímto ověřením změněny.
- 13 kontrol rozsahu cookie včetně spuštění bootstrapu s interním `SCRIPT_NAME` WEDOSu.
- 103 integračních kontrol na skutečném PHP/MariaDB v běžném režimu.
- Stejných 103 kontrol v režimu s veřejným prefixem `/nova/` a interním přepisem `/domains/.../nova/`, včetně instalace a přihlášení.
- Kontrola syntaxe všech 25 PHP souborů bez chyb.

Nahrání opravy na provozní hosting musí provést uživatel přes svůj přístup do WebFTP. Poté je vhodné zopakovat kontrolu uchování cookie přímo na hostingu.
