# ABC DÍLNA – KOMPLETNÍ ZADÁNÍ PRO CODEX
## Modul MECHANIK a jeho návaznost na budoucí Kancelář a komerční SaaS
**Datum zadání:** 16. 11. 2026  
**Status:** souhrn odsouhlasených požadavků z konzultací; nikoli tvrzení, že funkce už jsou naprogramované.

## 0. HLAVNÍ CÍL A VÝCHOZÍ KÓD

Vybudovat profesionální, rychlou, **intuitivní mobilní webovou aplikaci MECHANIK** pro jakýkoli autoservis. ABC Autoslužby jsou pouze první testovací autoservis. Aplikace má být budoucí **komerční SaaS**, ne jediný na míru napevno zakódovaný provoz. **Všechna provozní nastavení musí jít kdykoli změnit i v ABC Autoslužbách.**

**NENAVRHOVAT NOVOU NESOUVISEJÍCÍ APLIKACI OD NULY.** Použít už vytvořené projekty, které budou Codexu předány jako soubory:

- `ABC_Dilna_SaaS_3_1_0.zip`: základ pro více autoservisů, jejich data, přístupy, zákazníky, zakázky, vyúčtování a předplatné.
- `ABC_Dilna_SaaS_3_1_M02_VYVOJ.zip`: **preferovaný současný vývojový základ**, do SaaS byl začleněn přístup z níže zmíněné M01. Nutno nejdřív provést audit a ověřit běh nad testovací DB.
- `ABC_Dilna_MECHANIK_M01_VYVOJ.zip` a/nebo `ABC_Dilna_SaaS_M02_klikaci_pracovni_karta.html`: podklad **schváleného UX** – přímé řádky práce/díly, úpravy bez dalších formulářů. Pro Codex primárně používat skutečný zdrojový kód M02, vizuální HTML je jen demonstrace.
- Starší `ABC_Dilna_2_1_0...zip` a záplata 2.1.1 slouží pouze jako historický zdroj. **Nesmí přepsat novější opravy přihlášení**.

Aktuální soubory obsahují **vývojový kód, ne ověřenou produkční aplikaci**. Nic nenasazovat na živý WEDOS bez výslovného souhlasu. Pro testování používat oddělenou instalaci, databázi a testovací účty. Zachovat SaaS oddělení dat a stávající fakturační pravidla.

### Hlavní principy
1. **Mechanik má co nejméně psát a klikat.** Za každým krokem musí být jasný následující krok, bez zbytečných mezistránek a dlouhých vysvětlení.
2. **Jeden zakázkový list, jedna sdílená zakázka.** Mechanik, oprávněný kolega a pozdější Kancelář uvidí stejná aktuální data. Žádné dvojí zadávání.
3. **Ruční zadávání funguje plnohodnotně i bez AI a bez kanceláře.** AI je urychlení, ne blokující podmínka.
4. **Povinné minimum při příjmu, volitelné detaily později.** Ceny a díly nejsou povinné pro první uložení.
5. **Až do vystavení dokladu je zakázka opravovatelná**, včetně změny stavu z Hotovo zpět na V opravě nebo Čeká na díly.
6. **Nákupní ceny a marže patří oprávněnému vedení/Kanceláři.** Mechanik vidí prodejní údaje, které potřebuje k práci, podle svých práv.
7. **Oprávnění a nastavení vždy po jednotlivých zaměstnancích i dílnách.** Nepředpokládat, že hlavní mechanik nebo každý mechanik musí vybírat platby.
8. **Zachovat uživatelsky schválený způsob pracovní karty M01/M02.** Nerozbíjet ho přidáváním samostatných formulářů či zbytečným průvodcem.

## 1. HLAVNÍ NAVIGACE A VZHLED MECHANIKA

- Mobil první: Samsung/Android, velké dobře čitelné písmo, vysoký kontrast, velké oblasti pro klepnutí; zároveň **kompaktní uspořádání**, malé mezery, minimum „omáčky“. Volba Aa pro zvětšení včetně extra velkého režimu.
- Firemní barvy jako výchozí lze nastavit tmavě modré/zlaté/bílé; vzhled/logo/barvy jsou **nastavení autoservisu**, nikoli trvalé konstanty programu.
- Stále dostupné spodní menu **Domů | Zakázky | Kalendář | Auta**. Nepřidávat redundantní plovoucí bublinu „Nová zakázka“ dole. Nová zakázka je na úvodní stránce a v Zakázkách. Zprávy dostupné jasně označenou ikonou a upozorněním, bez zahlcení menu.
- Android systémová šipka Zpět vrací o jeden smysluplný krok; pro přechod do Kalendáře/Zakázek/Auta funguje **přímé spodní menu na jedno klepnutí**, ne deset kroků zpět. Při přepnutí neztratit neuložený příjem.
- Rozepsaná *skutečně neuložená* zakázka: jasně označený návrat „Pokračovat v neuložené zakázce“, případně zahodit s potvrzením. Po uložení už tuto výzvu nezobrazovat.
- Po „Uložit zakázku“ / „Uložit změny“ **trvalé jednoznačné potvrzení**, s číslem zakázky, autem, datem a akcemi otevřít nebo zobrazit zakázky. Úspěch zobrazit teprve po potvrzení uložení serverem.
- Úvod mechanika: časový pozdrav jeho jménem, rychlé hlavní volby a dnešní auta, nikoli dlouhé vysvětlivky. Jméno zaměstnance není v kódu napevno.
- Karty objednaných aut: auto + SPZ, zákazník, **výrazný čas příjezdu**, krátký seznam prací a stav; dominantní otevření, výrazně menší koš se potvrzením. Řadit podle termínu; celé běžné tělo karty může otevírat zakázku.

## 2. RYCHLÝ PŘÍJEM ZÁKAZNÍKA A VOZIDLA

- Zákazník popíše, co chce udělat; mechanik nejprve rychle zjistí vozidlo a případný termín.
- Minimum: **jméno, kontakt dle potřeby, SPZ, značka a model**; nepřehánět počet povinných polí. VIN není povinné, pokud ho mechanik nemá.
- Další údaje lze vyplnit hned nebo kdykoli později: VIN, rok výroby, objem motoru (cm³), výkon (kW – samostatné pole), kód motoru, palivo, barva, tachometr, STK, stav vozidla, telefon/e-mail a poznámky.
- Nově zadaný vůz a zákazník se **automaticky zařadí do evidence**, bez zvláštního zaškrtávání. Při opakovaném příjmu vyhledat existující záznam podle VIN (prioritně) nebo SPZ a předejít duplicitám; mechanik jen ověří shodu.
- Je možné přidat novou zakázku pro stejné auto bez opětovného zadání údajů; nové práce se nepřenášejí automaticky jako už provedené.
- První uložení možné bez dílů, cen i pevně určeného termínu. Vše doplnitelné.

## 3. FOTO / AI PŘÍJEM VOZIDLA

- Na mobilu možnost **Zadat ručně** nebo **Vyfotit / AI příjem**, obě volby vedou do stejné zakázky.
- Foto SPZ, VIN, tachometru; volitelně celé auto a poškození. OCR/AI navrhne rozpoznané údaje a při přiměřeně ověřitelných zdrojích doplní dostupné technické informace.
- Zobrazení rozpoznaných údajů ke kontrole; zřetelně označit nejisté položky, snadno opravit a vyfotit znovu.
- **Nikdy nevymýšlet VIN, přesnou motorizaci, číslo dílu, stav tachometru ani platnost STK.** Aktuální km nelze zjistit pouze z VIN. Externí registr vozidel není automaticky dostupný – navrhnout konektor, až bude skutečně oprávněný a funkční.
- Fotky bezpečně svázat s konkrétním vozidlem/zakázkou a oprávněními.

## 4. JEDNODUCHÝ VÝBĚR OPRAV – RUČNĚ I HLASEM

- Kategorie (nastavitelné dílnou): Pneuservis, Oleje a filtry, Brzdy, Podvozek, Diagnostika, Klimatizace, Autoskla, Ostatní; možnost dalších vlastních kategorií.
- Jedna zvolená kategorie na obrazovce. Další kategorie přidat malým jednoduchým ovládáním; při více kategoriích kompaktní přepínače, ne obrovský nekonečný seznam prací z jiných kategorií.
- **Červené karty = PRÁCE**, **modré karty = DÍLY/MATERIÁL**; lze vybrat více položek a více kategorií v **jedné zakázce**.
- Např. Oleje a filtry: „Výměna oleje“ = práce; motorový olej, olejový/vzduchový/kabinový/palivový filtr a těsnění = díly. Nepřidávat všechny filtry automaticky, jen vybrané nebo potvrzené návrhy.
- Např. Brzdy: zvolit přední/zadní/obě nápravy a kotouče/destičky; sestavit správné řádky prací i dílů, např. přední kotouče 2 ks, přední destičky 1 sada, zadní destičky 1 sada. **Neúčtovat výměnu kombinace dvakrát**, nepřidávat nechtěné díly.
- Např. Podvozek: levá/pravá/obě strany, nabídnout přesně odpovídající levý/pravý díl. Pokud už řádek obsahuje jiné uživatelsky zadané údaje, při přepnutí strany je tiše nesmazat.
- Diagnostika: zprvu jen práce „Diagnostika“ a případně poznámka. Konkrétní závady a díly se přidají až po zjištění příčiny.
- Kdekoli vlastní úkon/vlastní díl. Mechanik může ponechat cenu prázdnou.

### Pneuservis – výjimka s okamžitým ceníkem
- Výběr typu operace (kompletní přezutí, výměna/přehození kompletních kol apod.), **s/bez vyvážení**, průměr kola, počet kol, ventilky a další příplatky dle ceníku konkrétní dílny.
- Příplatky podle nastaveného ceníku, např. run-flat, dodávka, nízký profil, TPMS; vzájemně neslučitelné volby (např. run-flat/dodávka v dohodnutém modelu) kontrolovat.
- Přehledný rozpis ceny; nemíchat překrývající se služby tak, aby se účtovaly dvakrát. U ventilků lze později připojit sklad/spotřebu.
- **Pneuservis se může nacenit hned automaticky; ostatní práce a díly zpravidla zůstávají bez ceny až do doplnění.** Vše lze později upravit.

## 5. SCHVÁLENÝ ZAKÁZKOVÝ LIST / PRACOVNÍ KARTA M01/M02

Nejdůležitější část celé aplikace. Musí být snadno ovladatelná na jednom místě, bez otevírání další karty pro každou editaci.

- Záhlaví: zákazník, auto/SPZ, termín, technické údaje podle potřeby, stav opravy a rychlé odkazy na historii vozidla.
- **PRÁCE** (červeně): jednotlivé řádky – popis, množství/počet hodin, jednotka, prodejní cena za jednotku a řádková cena; sazba práce z nastavitelného ceníku, upravitelná jen při oprávnění. Ne nutně povinný čas.
- **DÍLY A MATERIÁL** (modře): řádky – název/dostupné katalogové číslo, množství, jednotka (`ks`, `l`, `sada` atd.), prodejní cena za jednotku, řádkový součet, stav plánováno/použito.
- Uživatel může **přímo v každém řádku** změnit název, počet, jednotku, cenu, doplnit poznámku, smazat řádek a přidat další; změny se bezpečně ukládají do téže zakázky.
- Ceny smějí být prázdné; zobrazit „Bez ceny / Nenaceněno“, nikoli mylně nula jako hotová cena. Průběžná částka je označena „Zatím naceněno“.
- **Nákupní ceny, rozdíl nákup/prodej a marže se v běžném režimu mechanika nezobrazují.** Office je může později doplnit.
- Smazání práce nemá bez varování smazat jiné práce a související materiál; jasně vysvětlit dopad. Změna dílu přímo v seznamu, ne přes formulář nahoře.
- Rozpis konečné částky ukazuje jednotlivé práce, díly, množství a případné příplatky. Sleva jen podle oprávnění.
- Zakázka má **jediné konzistentní uložení** a stejné položky se pak použijí pro tisk zakázkového listu, doklad a budoucí Kancelář.
- Rozlišovat **požadovanou/plánovanou práci**, **skutečně provedenou práci**, **požadovaný/objednaný díl** a **skutečně použitý a účtovaný díl**; neproměňovat návrhy automaticky na účtované položky.

## 6. AI DIKTOVÁNÍ A STRUKTUROVANÉ VYPLNĚNÍ ZAKÁZKY

- Velké tlačítko mikrofonu. Mechanik běžnou češtinou nadiktuje: „Vyměnit olej, přední kotouče a destičky, vzadu jen destičky.“
- AI vytvoří **návrh skutečných řádků téže pracovní karty**: práce odděleně od dílů, správná náprava/strana, přiměřená množství; chybějící údaje zůstávají k doplnění.
- Např. „Výměna oleje“ → práce; olej, olejový filtr jako **návrhy dílů**; žádná nevyžádaná výměna dalších filtrů. Případné speciální oleje, přesné množství a kompatibilita pouze z ověřených údajů.
- Mechanik návrh vidí v téže pracovní kartě, může jednotlivé řádky změnit/smazat/doplnit a **potvrdí**; bez potvrzení AI neúčtuje, neobjednává ani nevydává doklady.
- AI nebude znamenat separátní druhý průvodce nebo duplicitní seznam. Ruční karty fungují i bez AI a AI může pomoci doplnit už rozpracovanou zakázku.
- Stejné hlasové zadání používat pro poznámky/závady, díly a interní zprávy. Rozpoznaný text vždy rychle zkontrolovat, upravit a potvrdit.
- Zprvu připravit čisté rozhraní a připojení služby; **nepředstírat skutečné OCR/STT/LLM**, pokud nejsou napojené a otestované.

## 7. HISTORIE VOZIDLA A DOPORUČENÍ PŘÍŠTÍHO SERVISU

- Po načtení známého auta ihned přístupná **servisní historie** po datech: zakázky, provedené práce, skutečně namontované díly včetně výrobce a katalogového čísla, olej/specifikace/množství, datum, tachometr, poznámky, případně doklady.
- Ukázat poslední výměnu oleje (datum + km) a zaznamenaný termín STK; jen známé podložené údaje. Intervaly další údržby nastavitelné pro vozidlo/dílnu.
- Mechanik může během opravy nadiktovat **poznámku pro příště**: „Přední destičky ještě vyhovují, při další návštěvě zkontrolovat.“ Poznámka zůstává u vozidla, **není automaticky účtovaná práce ani požadavek na díl**.
- Při další návštěvě nabídnout dřívější doporučení; lze je označit jako prověřené, odložené nebo převést na požadovanou opravu.
- Budoucí Kancelář bude mít seznam blížících se STK, výměn oleje a doporučené údržby a může zákazníky se souhlasem a podle nastavení kontaktovat.
- U opakované návštěvy lze rychle založit nové práce s odkazy na dosavadní historii, nikoli překopírovat minule účtovanou zakázku jako již provedenou.

## 8. CHYTRÝ KATALOG DÍLŮ A DŘÍVE POUŽITÉ NÁHRADY

Týká se **všech dílů** (filtry, brzdy, čepy, ramena, stabilizátory atd.), ne jen olejových filtrů.

- Při opakované opravě **předvyplnit poslední skutečně použitý konkrétní díl** stejného vozidla (výrobce + katalogové číslo), pokud je vhodný pro daný úkon.
- **Pouhé klepnutí na existující řádek dílu** rozbalí kompaktní nabídku **přímo pod tímto řádkem**, např. 2–3 další dříve použité alternativy. Žádná povinná nová obrazovka, dialog ani potvrzování, pokud chce mechanik ponechat výchozí poslední díl.
- Alternativu vybrat jedním klepnutím; vždy také možnost zadat nový jiný díl ručně.
- Aplikace si pamatuje, **který díl byl původně navržen, objednán, dodán a hlavně skutečně namontován**; při příští zakázce nabízí také dříve skutečně použité náhrady.
- Rozvíjet interní **katalog položek a vazeb na konkrétní kompatibilní vozidla**. Díl může být vhodný i pro jiné vozy nebo modely stejného koncernu, ale porovnat přesnou motorizaci, kód motoru, provedení brzd/nápravy, období výroby, OE čísla a ověřené katalogové křížové odkazy.
- Zřetelně **rozlišit „dříve namontováno“ od „ověřená katalogová kompatibilita“**. Nedomýšlet bezpečnost dílů jen ze značky auta nebo ze skutečnosti, že díl někdy někdo použil. Nabídky mezi auty mohou být návrhy k ověření.
- Připravit možnost integrace dodavatelského katalogu (např. AP Autopartner), dostupnosti, skladových zásob a ověřených alternativ, **bez tvrzení o funkční integraci, pokud neexistuje**.
- Data jednotlivých autoservisů nesdílet tak, aby jeden servis viděl zákazníky, zakázky či nákupy jiného. Případná společná katalogová data musí být bezpečná a ověřená.

## 9. SPOLEČNÝ SEZNAM POTŘEBNÝCH DÍLŮ A OBJEDNÁVÁNÍ

- Mechanik může zapsat jen obecný požadavek „olejový filtr – 1 ks“, bez katalogového čísla a ceny.
- Tento požadavek zůstává **ve stejné zakázce** a zároveň se promítá do společného přehledu **Díly k zajištění / objednání** pro budoucí Kancelář, včetně SPZ, zakázky, množství a stavu.
- Kancelář může konkrétní díl určit, vybrat ověřenou alternativu, spojit požadavky z více zakázek do objednávky dodavateli, doplnit nákupní a prodejní cenu. Mechanik tyto změny vidí v zakázce v rozsahu svých oprávnění.
- Přehledné stavy: **požadováno → objednáno → dodáno / rezervováno → skutečně použito**. Nezaměňovat vytvořený požadavek s potvrzenou objednávkou.
- Pokud je díl skladem nebo už objednaný, nevytvářet duplicitní nákup. Sklad se odepisuje podle **skutečného použití**, ne jen naplánování.
- Automatická objednávka dodavateli ani přepsání dílu na faktuře **nesmí proběhnout bez výslovně nastavené/ověřené akce a oprávnění**.

## 10. KALENDÁŘ, PLÁNOVÁNÍ A OBSAZENOST

- Kompaktní **měsíční kalendář** podobný uživatelem schválené inspiraci Metro směny. Barevné označení volný / částečně obsazený / plně obsazený; výklad barev přístupný, nezáviset pouze na barvě.
- **Kliknutí na den ihned ukáže seznam objednaných aut** (ne až pod dlouhým hodinovým rozpisem). U každého: čas, vozidlo, SPZ, zákazník, práce, fáze, možnost otevřít/upravit, přepnout stav a změnit termín.
- **Volný den → „Přidat auto na tento den“**, datum již vyplněno. V obsazeném dni lze též přidat při volné kapacitě.
- Hodinový rozpis a detail obsazenosti dostupné na rozbalení pod seznamem aut.
- Zaznamenat **čas příjezdu**, odhad délky opravy (např. 0,5–8 h, rozsah konfigurovatelný), zda a kdy je potřeba hever/pracovní místo, případně přiřazeného mechanika. Při příjmu může být termín neurčený.
- U zakázek bez známé délky **neprohlašovat automaticky čas za volný**, ale ukázat chybějící plánovací údaj.
- Počet současných aut, stání, heverů, pracovní doba, pracovníci a pravidla obsazenosti jsou **měnitelná nastavení každého autoservisu**. Pro naši testovací dílnu lze nastavit například 2 auta a 1 hever, NIKDY to ale nepsat jako pevný limit do kódu.
- Kontrolovat překrytí intervalů; 3. současné auto nebo 2. současné využití jediného heveru v testovacím nastavení musí vyvolat jasnou kontrolu kolize. Přesouvání termínů zachovat.
- Mechanik má navíc **svůj osobní pracovní kalendář**; Kancelář později přehled všech pracovníků a zdrojů.

## 11. STAVY ZAKÁZKY A OPRAVY

- **Stav opravy:** např. Objednáno / Přijato / V opravě / Čeká na díly / Hotovo / Předáno (stavy a názvy dle nastavení dílny).
- **Stav vyúčtování:** Nevyúčtováno / Předáno k vyúčtování / Doklad vystaven / Oprava dokladu atd.
- **Stav platby:** Nezaplaceno / Částečně zaplaceno / Zaplaceno.
- **„HOTOVO“ NIKDY NEZNAMENÁ UZAMČENÍ ZAKÁZKY.** Dokud nebyl vystaven doklad, oprávněný pracovník může zakázku kdykoli znovu otevřít, přidat/smazat/upravit práci a díl, vrátit stav na V opravě nebo Čeká na díly, změnit termín. Platí i tehdy, když zákazník dodatečně zavolá s další požadovanou opravou.
- Historie změn: kdo/kdy/odkud upravil stav, díl, prodejní cenu, termín apod. Pracovní karta je stále **jedna stejná zakázka**, ne další duplicitní zakázka.
- **Po vystavení dokladu** uzamknout běžné přepisování finančních položek již zahrnutých do dokladu; opravy řešit průhledným opravným postupem podle použitého typu dokladu. Nezaměňovat vystavení faktury se skutečným zaplacením.
- Zakázku lze označit za rozpracovanou i když již byla jednou „Hotovo“.

## 12. PRÁVA, VYÚČTOVÁNÍ A POKLADNA

- Oprávnění **individuálně pro každého zaměstnance** a v každém autoservisu zvlášť: vidět/upravovat zakázky, přidat díl/práci, měnit ceny, poskytovat slevu, vystavit doklad, přijmout platbu, mít pokladnu, předat k vyúčtování, spravovat kolegy apod. „Hlavní mechanik“ je případně šablona role, **nikoli povinná rigidní hierarchie**.
- Mechanik bez platebního oprávnění po dokončení práce pouze **„Předat k vyúčtování“** vybranému oprávněnému pracovníkovi nebo Kanceláři. V jeho rozhraní se pokladna vůbec nezobrazuje.
- Mechanik s oprávněním může **sám vyúčtovat, přijmout platbu a vydat doklad**, anebo **předat zakázku Kanceláři**, když je k dispozici. Zpráva „Kancelář přijímá platby“ vychází z jejího nastaveného dostupného stavu, nikoli z neověřeného odhadu.
- Provoz může mít **všechny mechaniky s oprávněním a vlastními pokladnami** nebo jen jednoho oprávněného pracovníka. Obojí konfigurovatelné bez změny kódu.
- Pokud má pracovník vlastní pokladnu, evidence hotovosti a předání do hlavní pokladny se provede jako **interní převod**, nikoli druhá tržba. Podpora hotovost/karta/převod/faktura, podle oprávnění a aktuálních integrací; karty nepovažovat automaticky za fyzickou hotovost.
- **Nevynucovat komplikovaný strom předávání pokladen** ani pokladnu pro každého. Mechanik má vidět pouze příslušné akce: „Předat k vyúčtování“ nebo „Vyúčtovat“ a volitelně „Předat kanceláři“.
- Faktury, hotovostní doklady, platby (včetně částečných) a storna vázat jednoznačně k zakázce, osobě a pokladně; žádné dvojité vyúčtování a duplicitní účtování příjmu.

## 13. ZPRÁVY A HLASOVÁ KOMUNIKACE

- **Obousměrné interní zprávy** mechanik ↔ kancelář, mezi mechaniky, jednotlivcům či týmu.
- Fungují **jak u konkrétní zakázky, tak úplně mimo zakázku** – třeba „Připomeň zkontrolovat kompresor“ nebo „Zítra dorazí dodavatel“.
- Možnost fotky, přečteno/nepřečteno, upozornění. Připomínky/úkoly s volitelným datem.
- **Diktování zpráv česky** přes mikrofon; převod na editovatelný text, následné potvrzení/odeslání. Ruční text vždy dostupný.
- Zprávy soukromé uvnitř konkrétního autoservisu, oprávnění podle adresáta a role. Nesmí zasahovat do rychlého toku oprav.

## 14. OSOBNÍ KALENDÁŘ, HODINY A PRACOVNÍ VÝKON

- Mechanik vidí **své plánované zakázky** a přehled odpracované práce, bez nutnosti hledat v celém kalendáři dílny.
- Rozlišit **plánovanou dobu**, **skutečně odpracovaný čas**, **účtované hodiny**, a volitelně **docházku/směny**. Nezaměňovat tyto veličiny.
- Může být volitelná jednoduchá funkce **Začít / Pozastavit / Dokončit práci** na zakázce, ale NESMÍ zkomplikovat základní příjem; tuto volitelnou funkci je potřeba zvlášť schválit při implementaci.
- Pokud na jedné zakázce pracují dva mechanici, evidovat časy a přínos po pracovnících; nedávat automaticky celou tržbu oběma.
- Vedení/Kancelář později uvidí přehled výkonů, tržby, náklady, rozdíl nákup/prodej a hrubý přínos práce/dílů po zakázkách i mechanikovi. **Marže není totéž co čistý zisk** (mzdy, režie, DPH dle režimu atd.). Finanční přehledy se řídí právy.

## 15. PROPOJENÍ SE SPOLEČNOU KANCELÁŘÍ (KANCELÁŘ SE BUDE TVOŘIT POZDĚJI)

Kancelář zatím **nestavět celou**, ale už teď připravit společnou datovou strukturu a bezpečné API:

- Kancelář sleduje živé zakázky a auta všech mechaniků. Klikne na Petra a uvidí: co má přiděleno, co dělá, co je hotové, na co čeká, co je třeba doplnit, co je vyúčtované a zaplacené.
- Kancelář otevírá **stejnou pracovní kartu**, doplní vozidlo, zákazníka, přesný díl/katalogové číslo, množství, **prodejní cenu**, případně objedná díly; mechanik to bez opětovného zadávání uvidí.
- Mechanik se bez kanceláře také obejde: může s patřičnými právy doplnit prodejní ceny a vyúčtovat sám.
- **Skutečné nákupní ceny** a dodavatelská data může Kancelář doplnit i dodatečně pro přehled marží a hospodaření (po vydání dokladu už ale nemá tiše měnit fakturované prodejní údaje).
- Stav `Hotovo`, `Doklad vystaven`, `Zaplaceno` jsou oddělené. Kancelář má frontu **K vyúčtování**, případně neúplné položky a nezaplacené zakázky.
- Budoucí kompletní Kancelář obsahuje příjem, zákazníky/auta, sklady, dodavatele, objednávky, faktury, pokladny, účetní výstupy, zaměstnance, ekonomiku, STK/servisní připomínky a zprávy.

## 16. KOMERČNÍ, VARIABILNÍ A BEZPEČNÝ PROVOZ

- Každý autoservis může kdykoli měnit: název/logo/barvy, uživatele a práva, kapacity pracovišť/heverů, pracovní doby, měny a daňové nastavení dle země, ceníky, sazby, služby, stavové procesy, způsoby platby, dostupnost Kanceláře, notifikace a integrace. **Ani naše testovací ABC Autoslužby nemají pevně dané konfigurace.**
- Oddělení dat autoservisů: serverově vynucované oprávnění, tenant-specific databáze/identifikátory dle zvoleného SaaS základu, žádné křížení zákazníků, dokumentů, interních zpráv, katalogových pozorování či cen.
- Oddělené prostředí majitele autoservisu (jeho nastavení) a **administrace provozovatele SaaS** (tvoje správa platících autoservisů, tarifů, splatnosti, podpory, oznámení) – to není součást běžné aplikace mechanika.
- Používat auditní záznamy, validaci na serveru, CSRF ochranu, bezpečné sessions, kontrolu oprávnění API, ochranu osobních údajů, správu dokumentů a bezpečné migrace. Neuvádět skutečné přihlašovací údaje ani hesla v odevzdaném balíčku.
- Pokud dva pracovníci současně mění stejnou položku, neztratit změnu bez varování (verzování/optimistic locking nebo obdobný bezpečný postup).
- Zachovat opravy přihlášení, platby a fakturaci z již existujícího SaaS základu; nepřepisovat novější funkční kód staršími soubory.

## 17. CO MÁ CODEX DODAT A V JAKÉM POŘADÍ

**Nepsat najednou celý systém naslepo. Postupně dodávat funkční, testované balíky.**

### Etapa A – stabilní MECHANIK (první priorita)
1. Audit SaaS M02 zdrojů, struktury databáze, API a použitých oprávnění, popis stavu a rizik.
2. Jednoduchá navigace, skutečný rychlý příjem auta a opakované vyhledání/automatický zápis do evidence.
3. **Schválená pracovní karta M02** fungující nad reálnou testovací DB, inline řádky práce/díly, množství/jednotky/ceny, uložení, úprava, mazání, bezpečná fakturační návaznost.
4. Jedna zakázka s více opravami, změny stavu i po Hotovo, historie změn; „Hotovo“ nesmí blokovat editaci před vystavením dokladu.
5. Zjednodušený kalendář a osobní přehled mechanika; konfigurace kapacity a heverů, kolize termínů.
6. Individuální oprávnění pro editaci cen, předání k vyúčtování nebo vlastní vyúčtování; jasné potvrzení a ochrana dokladů.

### Etapa B – historie, díly a chytré návrhy
7. Servisní historie vozidla a poznámky „příště zkontrolovat“.
8. Přímé nabídnutí naposledy skutečně použitého dílu, rozbalitelné alternativy na řádku.
9. Interní katalog dílů, vazby na ověřené varianty vozidel a přehled požadavků na objednání; respektovat různé stavy dílů a sklad.

### Etapa C – hlas, fotky a komunikace
10. Fotky SPZ/VIN/tachometru s potvrzením rozpoznaných údajů.
11. Diktování českých oprav → návrhy prací a dílů **přímo v pracovní kartě**.
12. Obousměrné interní zprávy, nadiktování, notifikace, propojení se zakázkou nebo samostatně.

### Etapa D – Kancelář a komerční řízení
13. Úplné rozhraní Kancelář, sklad/objednávání, ekonomika a personální přehledy se stejnými daty.
14. Uživatelsky nastavitelné pokladny a předání, integrace dodavatelů a plateb, připomínky servisů.
15. Dokončení SaaS správy tarifů, provozu, přístupu, bezpečnosti a fakturace služby.

Po každé etapě dodat **úplný změnový seznam, migrace, testovací postup, zkušební data, přehled funkčních vs. simulovaných funkcí a jeden ZIP**. Neposílat jen obrázky nebo ukázkové HTML jako náhradu funkčního backendu.

## 18. POVINNÉ AKCEPTAČNÍ SCÉNÁŘE

1. Mechanik přijme zcela nové auto, zadá minimum údajů, uloží; auto i zákazník se objeví v evidenci. Při dalším příjmu stejné VIN/SPZ se nevytvoří duplicita.
2. Na jednu zakázku přidá **výměnu oleje + přední kotouče a destičky + zadní destičky + pneuservis**. Práce a díly oddělené; nic navíc a žádné dvojité účtování.
3. Mechanik zadá „olej 10W40 5 l“, filtr 1 ks, sprej 2 ks, práci 1 h; přímo změní počet/cenu a smaže jen jednu položku, součet sedí.
4. Bez zadání cen zakázku normálně uloží; zobrazuje se „Nenaceněno“, nikoli falešná konečná nulová faktura.
5. Kancelář nebo testovací oprávněný účet doplní prodejní cenu filtru; mechanik po obnovení uvidí změnu v **téže zakázce**. Nákupní cena není mechanikovi přístupná ani přes API.
6. Mechanik označí Hotovo, zákazník telefonicky objedná další práci; mechanik otevře stejnou nevyúčtovanou zakázku, přidá práci/díly a vrátí stav do V opravě.
7. Po vystavení dokladu nejde zpětně potichu přepsat fakturované množství/cenu; požaduje se korektní opravný postup.
8. Mechanik bez oprávnění nemůže účtovat ani serverovým API; zakázku odešle k vyúčtování. Oprávněný mechanik se může rozhodnout mezi vlastní pokladnou a předáním Kanceláři.
9. Kalendář při testovacím nastavení 2 auta/1 hever zachytí kolizi dvou současných zakázek s heverem; změna nastavení na více heverů kapacitu upraví **bez zásahu do zdrojového kódu**.
10. Klepnutí na obsazený den zobrazí auta, časy a stavy s přímým otevřením; volný den nabídne Přidat auto. Přepnutí spodním menu neztratí rozpracovanou zakázku.
11. U dříve servisovaného vozidla se nabídne poslední skutečně použitý filtr; klik rozbalí alternativy pod řádkem; beze změny lze pokračovat. Žádná domnělá kompatibilita bez ověření.
12. Poznámka „příště zkontrolovat destičky“ je vidět při další návštěvě a **sama se nevyúčtuje ani neobjedná**.
13. Hlasové zadání (až po reálné integraci) připraví řádky práce + dílů, které mechanik vidí, upraví a potvrdí; bez potvrzení nic neodejde dodavateli ani na fakturu.
14. Uživatel z autoservisu A nikdy nemůže číst/upravovat zakázky, faktury, zprávy a data autoservisu B – ani přímým voláním API.
15. Po dokončení prací mechanik vidí osobní pracovní přehled; vedení může správně rozlišit čas pracovníka, účtované hodiny a ekonomický výsledek.

## 19. ZÁSADNÍ INSTRUKCE PRO CODEX

> Před implementací nejprve prozkoumej předané ZIPy a napiš, co v nich již existuje a co není hotové. Výchozí kód je SaaS 3.1 + M02; schválené uživatelské ovládání pracovní karty M01/M02 je závazné. Nevytvářej novou izolovanou aplikaci, nepiš demo, které předstírá uložení. Navrhni minimální databázové migrace a API bez porušení datové izolace SaaS ani existující fakturace. Nejprve implementuj a otestuj Etapu A. Při nejistotě o požadavku se raději zeptej; nevybírej zásadní produktová rozhodnutí sám. Vše, co není napojeno na skutečnou službu (AI/OCR/dodavatelé/platby), pravdivě označ jako neimplementované nebo simulované. Nezasahuj do existující instalace WEDOS bez výslovného pokynu. Odevzdej funkční zdrojový kód, migrace a návod k izolovanému testování.

---
**Poznámka:** Tohle je komplexní produktové zadání. Pro první implementační úkol Codexu vyber pouze **Etapu A** a vyžaduj nejprve audit existujícího zdrojového kódu, aby nevznikla další nesourodá verze.
