# Architektura a migrace 3.1

Základní pracovní postup 3.0 zůstává: PHP/PDO, stávající tabulky CRM, zakázky, požadavky, účtované položky, kalendář, faktury, platby a pokladna. Rozšíření je v `app/saas.php`, `app/platform_actions.php` a samostatných vstupních stránkách platformy. Nezavádí druhý paralelní sklad nebo novou evidenci aut.

## Kontext servisu

Veřejný kód `index.php?servis=...` smí zvolit servis jen na přihlašovací/instalační stránce. Je uložen do serverové relace. Změna při přihlášení do jiného servisu je odmítnutá. Ostatní endpointy nepřijímají změnu kódu; podstrčené `tenant_id` v těle obchodního požadavku nevolí databázi.

Bootstrap získá přístup z registru, ověří AES-GCM a databázovou identitu `saas_identity`, načte vlastní `company_settings` a teprve potom vyhodnocuje obchodní přihlášení/role. Kontext je součástí hashe relace i klíče browserového konceptu. API v otevřených obrazovkách posílají scope, který server kontroluje proti relaci. Cookie provozovatele má jiný název než cookie zaměstnanců servisů; obě respektují veřejnou cestu instalace a HTTPS.

Izolaci doplňují DB oprávnění: každý klientský SQL účet musí mít grant pouze do své DB. Provozovatel serveru může spravovat konfiguraci a hostování, nejde o šifrování obchodních dat před správcem hostingu. Aplikace nezobrazuje databázová hesla ani neumožňuje operátorovi vstup za klienta.

## Schéma platformy

`saas_schema()` vytváří při čisté instalaci:

| Tabulka | Význam |
| --- | --- |
| saas_admins | Provozovatelé platformy, hash hesla, aktivita a verze relace |
| saas_tenants | Jedinečný kód/identita servisu, šifrované připojení, tarif, přístup |
| saas_plans | Vlastní zadané měsíční ceny |
| saas_bills | Interní měsíční předpisy se snímkem ceny a externí referencí faktury |
| saas_payments | Potvrzené bankovní platby k předpisům, reference a klíč opakování |
| saas_audit | Změny přístupu, tarifů a předplatného s aktérem |
| saas_login_attempts | Omezení pokusů o přihlášení provozovatele |
| saas_requests | Skutečné žádosti o zřízení přístupu |

Klientská DB používá původní schéma 3.0. `saas_business_schema()` přidává `saas_identity`, `company_settings`, `crm_customers.dic` a `office_invoices.customer_dic`. Migrace je podmíněná existencí sloupce/tabulky a opakovatelná. Nevyprázdní žádnou provozní tabulku. Základní marker `schema_meta=3.0.0` zůstává pro kompatibilitu společných obchodních endpointů; SaaS navíc povinně kontroluje identitu a profil, samotný marker nestačí.

Před připojením známé kopie musí existovat verze 3.0, musí být potvrzená samostatná kopie a musí projít kontrola všech požadovaných starších tabulek/sloupců. `abc_migrate_v300()` doplní případné chybějící pomocné indexy a tabulky; původní hodnoty neodhaduje ani nepřepočítává. Jinému tenantovi již přiřazená DB je odmítnutá. Selhání mezi centrální registrací a dokončením klientského schématu ponechá provisioning pro vědomé opakování, nesimuluje úspěch.

Instalátory a migrace provádějí DDL, což v MySQL/MariaDB nemusí jít vrátit jednou transakcí. Proto pracují jen s prázdnou DB nebo explicitní kopií. Nepřipojují živou původní DB automaticky.

## Doklady a předplatné

Čísla zakázek/faktur/účtenek jsou jedinečná v rámci konkrétního servisu. Dva různé servisy mohou mít fakturu 2026-000001, protože se liší dodavatelem i databází. Vystavené faktury drží neměnný JSON snímek dodavatele, položek, slevy a u nových dokladů daňového rozkladu. Dřívější doklady bez daňového příznaku zůstávají neplátci DPH.

Plátce má v této verzi jen standardní tuzemské plnění se sazbou 21 %, ceny včetně DPH; základ je konečná cena po slevě / 1,21 a daň rozdíl po zaokrouhlení na haléře. Datum uskutečnění plnění je datum vystavení v tomto toku dokončené opravy. Pokud případ vyžaduje jiný režim nebo jiné datum plnění, použijte odpovídající externí fakturaci; tato verze takový případ nepředstírá.

Předplatné je zcela oddělené od zákaznických peněz servisu. Předpis uchovává měsíční cenu/období, skutečnou fakturu za službu vystavuje provozovatel externě. Platba se zapisuje až po potvrzení banky, může být částečná; transakce zamkne předpis a kontroluje součet, opakovaný klíč vrací bez dalšího příjmu. Po plném doplacení se datum přístupu nejvýše prodlouží. Výslovné pozastavení se samo neruší. Přístup po expiraci umožňuje čtení/tisk/export a zakazuje obchodní POST operace, klientská data nemaže.

## Nasazení

PHP 8.1+, PDO MySQL, mbstring, OpenSSL, sessions a InnoDB. Na sdíleném hostingu se DB zakládají ručně. Platforma nevyžaduje právo CREATE DATABASE pro svůj SQL účet, serverový Node, externí API ani platební gateway. Pro větší počet klientů se musí posoudit kapacita hostingu; není provedena zátěžová zkouška stovek servisů.
