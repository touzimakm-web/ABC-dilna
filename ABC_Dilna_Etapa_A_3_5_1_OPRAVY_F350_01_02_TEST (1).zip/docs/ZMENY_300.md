# Změny proti kompletní PHP verzi 2.1.1

- Zachovaný přihlašovací, databázový a desktopový základ; samostatná pracovní kopie projektu.
- Nový jednoduchý mobilní úvod se čtyřmi tlačítky před dnešními auty; odstraněný mrtvý čtyřkrokový průvodce a přebytečné volby.
- Jediný rychlý příjem a pracovní karta pro všechny služby. Karty se kombinují a představují samostatné požadavky, nikoli účtované úkony.
- SPZ-only příjem ukládá vazbu na zákaznickou evidenci. Neznámí zákazníci různých aut se neslučují do jedné osoby; při existujícím vozidle se zachovává jeho skutečný zákazník.
- Autocomplete podle SPZ i zákazníka, včetně sjednocení mezer v SPZ. VIN a technické údaje lze doplnit ručně.
- Nepovinný termín je oddělený od evidenčního času založení a propojený s kalendářem a kontrolou kolizí.
- Práce a díly z ceníku nebo úplně vlastní, cena může zůstat neznámá; desetinné množství materiálu. Uložení a návrat do stejné zakázky, pozdější další práce, označení dokončení.
- Průběžná cena je dostupná mechanikovi; právo měnit ceny a přijímat platby zůstává řízené majitelem. Nákupní náklady se mechanikovi nevracejí.
- Dokončení neprojde s neodškrtnutou skutečnou prací. Obecné požadavky neblokují nacenění konkrétních položek a nezapočtou se podruhé.
- Částečná hotovost, karta a majitelem potvrzený převod; stejné vyúčtování i po vystavení faktury. Sleva majitele s důvodem. Faktura sama nevytváří příjem.
- Serverová idempotence zakázky, přidané položky, faktury, úhrady a předání hotovosti včetně opakované částečné platby. Transakční zámky brání přeplacení.
- Historie změn cen před/po, uložené číslování a identifikace nových plateb. Při úhradě faktury se na doklad přenese její skutečný odběratel.
- Samostatný zakázkový list i bez cen, zachované předběžné odhady, faktury neplátce DPH, příjmové doklady a výstup PDF přes prohlížeč.
- Přehled hotovosti u jednotlivých mechaniků a přijetí přepočítané částky majitelem; předání nezvyšuje výnos znovu.
- Relace oddělená podle veřejné instalační cesty a databáze; zachovaná oprava WEDOS cookie cesty a CSRF.
- Prázdná nová instalace a oddělená přidávací migrace známého schématu. Ověření na skutečné MariaDB a ve skutečném Chromium, v mobilní i desktopové relaci.
