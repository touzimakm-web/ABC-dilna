> Archivní dokumentace verze 3.0. Pro tuto SaaS verzi začněte [instalací 3.1](INSTALACE_SAAS_WEDOS.md).

# Přejímací zkouška na vašem testovacím WEDOSu

Použijte novou složku a testovací databázi, žádné skutečné účetní doklady. Majitele přihlaste na počítači, mechanika na Samsungu. Oba účty mají používat stejnou databázi.

1. Přihlaste mechanika, obnovte stránku. Přihlášení zůstává zachované. Nahoře jsou čtyři tlačítka, bez statistik a stopek.
2. Přijměte nové auto jen SPZ a třemi službami Pneuservis + Oleje a filtry + Brzdy. Nezadávejte termín ani ceny. Jedno uložení vrátí mechanika na úvod. Nevznikne platba, faktura ani rezervace. Auto najde i majitel.
3. Přijměte další zakázku přes začátek uložené SPZ, pak přes jméno uloženého zákazníka. Nabídka vzniká při psaní. Zvolené auto doplní známé údaje.
4. U nové SPZ rozbalte údaje auta a doplňte kontakt, případně VIN ručně. Bez připojené integrace se žádná technická data nevymýšlejí.
5. Uložte další zakázku s konkrétním datem/časem. Je v kalendáři a kliknutí otevře stejnou kartu. Kolize pro stejného mechanika se odmítne, bez neúplné zakázky v databázi.
6. Otevřete první zakázku. Karty požadavků jsou oddělené od prací a materiálu. Napište „přezutí 15“; při odpovídající položce skutečného firemního ceníku se nabídne název a cena. Vyberte ji a ověřte předvyplněnou cenu.
7. Přidejte vlastní díl bez skladu a ceníku. Přidejte olej s množstvím 4 l nebo 4,5 l. Cena může zůstat prázdná a doplnit se později oprávněným účtem.
8. Vraťte se na úvod a znovu otevřete stejnou zakázku. Přidejte další práci po telefonátu zákazníka. Staré položky zůstávají; zakázka se nezakládá znovu.
9. Označte skutečné práce jako hotové a dokončete opravu. Obecné karty služeb se nemají účtovat navíc. Nedokončené skutečné úkony dokončení blokují.
10. Vytiskněte zakázkový list před oceněním a ověřte „cena bude upřesněna“. Uložte ruční předběžný odhad; odhad není faktura ani úhrada. Prohlédněte PDF i tisk na vaší tiskárně.
11. Vystavte fakturu se splatností. Majitel ji vidí jako neuhrazenou a žádná hotovost nepřibude.
12. Zapište část skutečně přijaté platby hotově, další část kartou. Nedoplatek se správně sníží. Převod smí potvrdit majitel až po skutečném přijetí.
13. Dvojklik na uložení nesmí vytvořit dvě zakázky nebo dvě stejné platby. Opakovaný tisk nevytváří novou úhradu. Nepokoušejte se takto testovat skutečné provozní účetnictví.
14. Mechanik v Pokladně předá jen vybranou hotovost. Karta a převod se nepředávají hotově. Majitel na svém počítači zkontroluje a potvrdí částku; při nesouladu se převzetí neuloží. Příjmy se nezvýší znovu.
15. Projděte mobilní kartu a kalendář bez vodorovného posouvání. Vyzkoušejte také klávesnici telefonu a otevření PDF. Mechanik nesmí otevřít cizí zakázku ani recepci; změna oprávnění a deaktivace účtu mají být účinné ihned.
16. U migrace porovnejte původní počty a ID zákazníků, aut, historie, zakázek, faktur a plateb. Přeznačení starých požadavků je výslovné rozhodnutí pracovníka, nikoli odhad migračního skriptu.

Teprve po této zkoušce se plánuje přepnutí skutečného provozu. Výsledek lokálních automatických zkoušek nenahrazuje ověření hostingové konfigurace a fyzické tiskárny.
