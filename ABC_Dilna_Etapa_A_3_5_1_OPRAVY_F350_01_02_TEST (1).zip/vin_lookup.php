<?php
declare(strict_types=1);
require __DIR__.'/app/bootstrap.php';login_required();
$vin=mb_strtoupper(post_str($_GET,'vin',17));
if(!preg_match('/^[A-HJ-NPR-Z0-9]{17}$/D',$vin))fail('Neplatný VIN.');
$v=query('SELECT brand,model FROM crm_vehicles WHERE vin=?',[$vin])->fetch();
json_ok(['found'=>(bool)$v,'vehicle'=>$v?trim($v['brand'].' '.$v['model']):'',
    'notice'=>$v?'Vozidlo dohledáno ve vlastní evidenci.':'VIN není v naší evidenci. Značku a model vyplň ručně.']);
