<?php
declare(strict_types=1);
require __DIR__.'/app/bootstrap.php';require __DIR__.'/office_lib.php';
$u=login_required();
if(($_SERVER['REQUEST_METHOD']??'GET')!=='POST')fail('Použij formulář.',405);
require_csrf();$p=$_POST;$action=post_str($p,'action',40);$back='office.php';
if(in_array($action,['save_user','update_user'],true))permission($u,'manage_team');elseif($action==='save_catalog')permission($u,'manage_catalog');else require_role($u,['owner']);
if($action==='save_customer') {
    $name=post_str($p,'name',160);if(!$name)fail('Vyplň jméno zákazníka.');
    $email=post_str($p,'email',190);if($email&&!filter_var($email,FILTER_VALIDATE_EMAIL))fail('Neplatný e-mail.');
    $ico=post_str($p,'ico',20);if($ico&&!preg_match('/^\d{8}$/D',$ico))fail('IČO musí mít osm číslic.');
    $dic=post_str($p,'dic',20);if($dic&&!preg_match('/^[A-Z]{2}[A-Z0-9]{2,18}$/D',$dic))fail('Neplatné DIČ.');
    $values=[$ico?'company':'person',$name,post_str($p,'phone',60),$email,post_str($p,'address',500),$ico,post_str($p,'note',1000)];
    db()->beginTransaction();
    if(!empty($p['id'])) {
        $id=positive_id($p['id']);$old=query('SELECT * FROM crm_customers WHERE id=? FOR UPDATE',[$id])->fetch();if(!$old)fail('Zákazník neexistuje.',404);card_version($p,(int)$old['revision'],'customer',$old);
        query('UPDATE crm_customers SET type=?,name=?,phone=?,email=?,address=?,ico=?,note=?,revision=revision+1 WHERE id=?',[...$values,$id]);
    } else {query('INSERT INTO crm_customers(type,name,phone,email,address,ico,note) VALUES (?,?,?,?,?,?,?)',$values);$id=(int)db()->lastInsertId();}
    if(saas_enabled())query('UPDATE crm_customers SET dic=? WHERE id=?',[$dic,$id]);
    log_event((int)$u['id'],0,'customer_updated','#'.$id,['before'=>$old??null,'after'=>query('SELECT * FROM crm_customers WHERE id=?',[$id])->fetch()]);db()->commit();
    $back='office.php?view=customers&customer='.$id;
} elseif($action==='save_vehicle') {
    $customer=positive_id($p['customer_id']??null);
    if(!query('SELECT id FROM crm_customers WHERE id=?',[$customer])->fetch())fail('Zákazník neexistuje.',404);
    $plate=preg_replace('/\s+/u','',mb_strtoupper(post_str($p,'plate',30)));
    $vin=mb_strtoupper(post_str($p,'vin',17));if($vin&&!preg_match('/^[A-HJ-NPR-Z0-9]{17}$/D',$vin))fail('VIN musí mít 17 platných znaků.');
    $brand=post_str($p,'brand',80);$model=post_str($p,'model',160);if(!$plate&&!$vin&&!$brand&&!$model)fail('Vyplň alespoň jeden údaj o vozidle.');
    $mileage=post_str($p,'mileage',10);if($mileage!==''&&(!ctype_digit($mileage)||(int)$mileage>9999999))fail('Neplatný stav tachometru.');
    $id=!empty($p['id'])?positive_id($p['id']):0;
    db()->beginTransaction();
    if($id){$old=query('SELECT * FROM crm_vehicles WHERE id=? AND customer_id=? FOR UPDATE',[$id,$customer])->fetch();if(!$old)fail('Auto nepatří zákazníkovi.',404);card_version($p,(int)$old['revision'],'vehicle',$old);}
    if(($plate&&query('SELECT id FROM crm_vehicles WHERE plate=? AND id<>?',[$plate,$id])->fetch())||($vin&&query('SELECT id FROM crm_vehicles WHERE vin=? AND id<>?',[$vin,$id])->fetch()))fail('Tato SPZ nebo VIN už je v evidenci.',409);
    $values=[$customer,$plate?:null,$vin?:null,$brand,$model,$mileage===''?null:(int)$mileage];
    if($id)query('UPDATE crm_vehicles SET customer_id=?,plate=?,vin=?,brand=?,model=?,mileage=?,revision=revision+1 WHERE id=?',[...$values,$id]);
    else query('INSERT INTO crm_vehicles(customer_id,plate,vin,brand,model,mileage) VALUES (?,?,?,?,?,?)',$values);
    log_event((int)$u['id'],0,'vehicle_updated','Živá evidence vozidla',['before'=>$old??null,'vehicle_id'=>$id?:db()->lastInsertId()]);db()->commit();
    $back='office.php?view=customers&customer='.$customer;
} elseif($action==='save_catalog') {
    db()->beginTransaction();$op=operation_begin($u,'catalog_save',$p);$catalog=c_save($u,$p);operation_store($op,['id'=>$catalog]);db()->commit();
    $back='office.php?view=catalog';
} elseif($action==='save_user') {
    $name=post_str($p,'name',120);$email=mb_strtolower(post_str($p,'email',190));$password=post_str($p,'password',200);
    if(!$name||!filter_var($email,FILTER_VALIDATE_EMAIL)||mb_strlen($password)<12||strlen($password)>72)fail('Vyplň jméno, e-mail a heslo alespoň 12 znaků, nejvýše 72 bajtů.');
    if(query('SELECT id FROM users WHERE email=?',[$email])->fetch())fail('Tento e-mail už je registrovaný.',409);
    $perms=array_values(array_intersect((array)($p['permissions']??[]),array_keys(a_permissions())));
    if(empty($p['rights_version']))$perms=array_values(array_unique(array_merge($perms,a_legacy_permissions())));
    query('INSERT INTO users(name,email,password_hash,role,permissions) VALUES (?,?,?,?,?)',[$name,$email,password_hash($password,PASSWORD_DEFAULT),'mechanic',json_encode($perms)]);
    $back='office.php?view=team';
} elseif($action==='update_user') {
    $id=positive_id($p['id']??null);$target=query("SELECT * FROM users WHERE id=? AND role='mechanic'",[$id])->fetch();
    if(!$target)fail('Mechanik neexistuje.',404);
    $perms=array_values(array_intersect((array)($p['permissions']??[]),array_keys(a_permissions())));
    if(empty($p['rights_version']))$perms=array_values(array_unique(array_merge($perms,a_legacy_permissions())));
    db()->beginTransaction();query('UPDATE users SET permissions=?,active=? WHERE id=?',[json_encode($perms),isset($p['active'])?1:0,$id]);
    $password=post_str($p,'password',200);if($password!==''){
        if(mb_strlen($password)<12||strlen($password)>72)fail('Heslo musí mít alespoň 12 znaků, nejvýše 72 bajtů.');
        query('UPDATE users SET password_hash=?,session_version=session_version+1 WHERE id=?',[password_hash($password,PASSWORD_DEFAULT),$id]);
    }
    db()->commit();$back='office.php?view=team';
} elseif($action==='change_password') {
    $old=post_str($p,'current_password',200);$password=post_str($p,'password',200);
    $hash=query('SELECT password_hash FROM users WHERE id=?',[$u['id']])->fetchColumn();
    if(!password_verify($old,(string)$hash))fail('Současné heslo není správné.',403);
    if(mb_strlen($password)<12||strlen($password)>72)fail('Nové heslo musí mít alespoň 12 znaků, nejvýše 72 bajtů.');
    query('UPDATE users SET password_hash=?,session_version=session_version+1 WHERE id=?',[password_hash($password,PASSWORD_DEFAULT),$u['id']]);
    $_SESSION['session_version']=(int)$u['session_version']+1;
    session_regenerate_id(true);$back='office.php?view=settings';
} elseif($action==='assign_job') {
    $id=positive_id($p['id']??null);$mechanic=empty($p['mechanic_id'])?null:positive_id($p['mechanic_id']);
    if($mechanic&&!query('SELECT id FROM users WHERE id=? AND active=1',[$mechanic])->fetch())fail('Mechanik není aktivní.');
    $db=db();office_lock_calendar($db);
    try {
        $db->beginTransaction();$j=lock_job($id,$u);card_version($p,(int)$j['revision'],'job',array_intersect_key($j,array_flip(['id','status','revision'])));if($j['status']==='closed')fail('Zakázka je uzavřená.',409);
        $appointments=query("SELECT * FROM office_appointments WHERE job_id=? AND status IN ('confirmed','requested')",[$id])->fetchAll();
        foreach($appointments as $a){
            if(!$mechanic)fail('Objednané zakázce vyber mechanika.');
            office_ensure_slot($db,$a['start_at'],$a['end_at'],(int)$a['id'],$mechanic);
            query('UPDATE office_appointments SET mechanic_id=? WHERE id=?',[$mechanic,$a['id']]);
        }
        query('UPDATE jobs SET assigned_to=?,revision=revision+1 WHERE id=?',[$mechanic,$id]);log_event((int)$u['id'],$id,'assigned',(string)$mechanic,['before'=>$j['assigned_to'],'after'=>$mechanic]);$db->commit();
    } finally { office_unlock_calendar($db); }
    $back='office.php?view=jobs&job='.$id;
} elseif($action==='appointment') {
    $id=positive_id($p['id']??null);$db=db();office_lock_calendar($db);
    try {
        $db->beginTransaction();$a=query('SELECT * FROM office_appointments WHERE id=? FOR UPDATE',[$id])->fetch();if(!$a)fail('Termín neexistuje.',404);
        if($a['job_id']){$j=lock_job((int)$a['job_id'],$u);card_mutable((int)$a['job_id'],$j);card_version($p,(int)$j['revision'],'job',array_intersect_key($j,array_flip(['id','status','revision'])));}
        if(!empty($p['cancel']))query("UPDATE office_appointments SET status='cancelled' WHERE id=?",[$id]);
        else {
            $day=post_str($p,'date',10);$time=post_str($p,'time',5);if(!a_date($day))fail('Neplatný den.');
            if($time===''){
                if(!$a['job_id'])fail('Pracovní den bez času je možné uložit u propojené zakázky.');
                query("UPDATE office_appointments SET status='cancelled' WHERE id=?",[$id]);query('UPDATE jobs SET work_day=? WHERE id=?',[$day,$a['job_id']]);
            }else{
                [$start,$end]=office_slot($day,$time,$p['duration']??null,false);
                $delta=strtotime($start)-strtotime($a['start_at']);$rs=$a['resource_start']?date('Y-m-d H:i:s',strtotime($a['resource_start'])+$delta):null;$re=$a['resource_end']?date('Y-m-d H:i:s',strtotime($a['resource_end'])+$delta):null;
                a_calendar_check($db,$start,$end,$id,(int)$a['mechanic_id'],$a['resource_id'],$rs,$re,$a['work_mode'],(int)$a['job_id']);
                query("UPDATE office_appointments SET start_at=?,end_at=?,resource_start=?,resource_end=?,status='confirmed' WHERE id=?",[$start,$end,$rs,$re,$id]);
                if($a['job_id'])query('UPDATE jobs SET work_day=? WHERE id=?',[$day,$a['job_id']]);
            }
        }
        if($a['job_id'])query('UPDATE jobs SET revision=revision+1 WHERE id=?',[$a['job_id']]);
        log_event((int)$u['id'],(int)$a['job_id'],'appointment_changed','#'.$id,['before'=>$a,'after'=>query('SELECT * FROM office_appointments WHERE id=?',[$id])->fetch()]);$db->commit();
    } finally { office_unlock_calendar($db); }
    $back='office.php?view=calendar';
} elseif($action==='accept_handover') {
    $id=positive_id($p['id']??null);db()->beginTransaction();$h=query('SELECT * FROM cash_handovers WHERE id=? FOR UPDATE',[$id])->fetch();
    if(!$h||$h['status']!=='pending')fail('Předání už bylo potvrzeno nebo neexistuje.',409);
    $counted=money($p['counted_amount']??null);if(abs($counted-(float)$h['declared_amount'])>.009)fail('Převzatá částka neodpovídá předání. Ověř ji s mechanikem.',409);
    query("UPDATE cash_handovers SET status='accepted',accepted_at=NOW(),accepted_by=? WHERE id=?",[$u['id'],$id]);
    log_event((int)$u['id'],0,'cash_accepted','#'.$id);db()->commit();$back='office.php?view=payments';
} elseif($action==='request_state') {
    $id=positive_id($p['id']??null);$state=post_str($p,'state',20);
    if(!in_array($state,['requested','ordered','received'],true))fail('Neplatný stav.');
    query('UPDATE part_requests SET state=? WHERE id=?',[$state,$id]);$back='office.php?view=jobs';
} else fail('Neznámá operace.',404);
flash('Změny byly uloženy.');if($u['role']!=='owner'&&in_array($action,['save_user','update_user'],true))$back='team.php';redirect($back);
