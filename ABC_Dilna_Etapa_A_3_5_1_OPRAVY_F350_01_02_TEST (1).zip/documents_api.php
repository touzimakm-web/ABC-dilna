<?php
declare(strict_types=1);require __DIR__.'/app/bootstrap.php';$u=login_required();$action=post_str($_GET,'action',40);
if(($_SERVER['REQUEST_METHOD']??'GET')==='GET'){
 if($action==='operation'){permission($u,'manage_documents');$key=post_str($_GET,'key',80);$kind=post_str($_GET,'operation',20);if(!in_array($kind,['save','template'],true))fail('Neplatná operace.');$r=query('SELECT response_json FROM abc_request_keys WHERE user_id=? AND action=? AND request_key=?',[$u['id'],'documents_'.$kind,$key])->fetch();$result=$r&&$r['response_json']?json_decode($r['response_json'],true):null;if(!empty($result['id']))d_get((int)$result['id'],$u);json_ok(['completed'=>$result!==null,'result'=>$result]);}
 if($action==='list')json_ok(['documents'=>d_list($u,empty($_GET['job_id'])?null:positive_id($_GET['job_id']),empty($_GET['vehicle_id'])?null:positive_id($_GET['vehicle_id']))]);
 if($action==='versions'){$d=d_get(positive_id($_GET['id']??null),$u);$rows=query('SELECT version FROM abc_document_versions WHERE document_id=? ORDER BY version DESC',[$d['id']])->fetchAll();$result=[];foreach($rows as $v){$version=(int)$v['version'];if($d['job_id']||abc_perm($u,'manage_documents')||query('SELECT staff_visible FROM abc_document_versions WHERE document_id=? AND version=?',[$d['id'],$version])->fetchColumn())$result[]=d_get((int)$d['id'],$u,$version);}json_ok(['versions'=>$result]);}
 fail('Neznámá operace.',404);
}
if(($_SERVER['REQUEST_METHOD']??'GET')!=='POST')fail('Použij POST.',405);
if(!$_POST&&!$_FILES&&(int)($_SERVER['CONTENT_LENGTH']??0)>0)fail('Nahrávání překročilo limit serveru. Zkontroluj velikost a nastavení PHP.',413);
require_csrf();permission($u,'manage_documents');$p=$_POST;
if(!in_array($action,['save','template'],true))fail('Neznámá operace.',404);
$upload=null;$logo=null;
if($action==='save'&&isset($_FILES['pdf'])&&($_FILES['pdf']['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_NO_FILE)$upload=d_upload($_FILES['pdf']);
if($action==='template'&&isset($_FILES['logo'])&&($_FILES['logo']['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_NO_FILE)$logo=d_logo($_FILES['logo']);
// Hash souboru je součástí klíče operace; opakování s jinými bytes se nepřijme.
$p['_file_sha256']=$upload['sha256']??($logo?hash('sha256',$logo[0]):null);
$db=db();$db->beginTransaction();$op=operation_begin($u,'documents_'.$action,$p);
if($action==='save')$result=d_save($u,$p,$upload);else{d_save_template($u,$p,$logo);$result=[];}
operation_commit($op,$result);
