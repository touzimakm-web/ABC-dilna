<?php
declare(strict_types=1);
require __DIR__.'/app/bootstrap.php';require __DIR__.'/app/migrations.php';
$u=login_required();require_role($u,['owner']);$error='';$changes=null;
if(($_SERVER['REQUEST_METHOD']??'GET')==='POST'){
    require_csrf();if(($_POST['backup_confirmed']??'')!=='1')fail('Nejprve potvrď zálohu a samostatnou testovací databázi.');
    $db=db();$key='abc_upgrade_'.substr(hash('sha256',(string)$config['db_name']),0,24);$s=$db->prepare('SELECT GET_LOCK(?,10)');$s->execute([$key]);if((int)$s->fetchColumn()!==1)fail('Aktualizace právě probíhá.',409);
    try{$changes=abc_migrate_a12($db);log_event((int)$u['id'],0,'schema_upgraded',ABC_A_SCHEMA);}catch(Throwable $ex){error_log('ABC migrace: '.$ex->getMessage());$error='Migraci nelze dokončit. Ověř známé schéma 2.1.1 a práva databáze. Záznamy nebyly mazány. Podrobnost je v serverovém logu.';}finally{$s=$db->prepare('SELECT RELEASE_LOCK(?)');$s->execute([$key]);}
}
?><!doctype html><html lang="cs"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Aktualizace ABC Dílny</title><link rel="stylesheet" href="assets/mechanic.css"></head><body class="login-body"><main class="login-card wide"><h1>Aktualizace Etapy A</h1><p>Pro samostatnou kopii známé databáze 3.1/M02 nebo 2.1.1. Přidává sloupce a pomocné tabulky; nemaže zákazníky, zakázky ani platby. Starší úkony nepřeznačuje podle odhadu.</p><?php if($changes!==null):?><p class="notice">Aktualizace Etapy A 3.5.1 je dokončená.</p><a class="button orange" href="office.php">Otevřít recepci</a><?php else:if($error):?><p class="notice error"><?=e($error)?></p><?php endif;?><form method="post"><input type="hidden" name="csrf" value="<?=e(csrf())?>"><label class="inline-option"><input type="checkbox" name="backup_confirmed" value="1" required>Pracuji se samostatnou kopií databáze a mám zálohu.</label><button class="button orange">Provést přidávací migraci</button></form><?php endif;?></main></body></html>
