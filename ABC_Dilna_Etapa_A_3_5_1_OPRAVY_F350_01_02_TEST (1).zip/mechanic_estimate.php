<?php
/** ABC Dílna 2.0.6: Předběžný zakázkový list (návrh). */
declare(strict_types=1);
require __DIR__.'/app/bootstrap.php';
$u=login_required();require_role($u,['owner','mechanic']);
$id=filter_var($_GET['job']??null,FILTER_VALIDATE_INT,['options'=>['min_range'=>1]]);
if(!$id)fail('Neplatná zakázka.');
get_job((int)$id,$u);
$payload=['scope'=>db_scope(),'id'=>(int)$id,'csrf'=>csrf()];
?><!doctype html><html lang="cs"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>Předběžný zakázkový list – ABC Dílna</title>
<link rel="stylesheet" href="assets/mechanic.css?v=<?= (int)filemtime(__DIR__.'/assets/mechanic.css') ?>">
<link rel="stylesheet" href="assets/mechanic_work.css?v=<?= (int)filemtime(__DIR__.'/assets/mechanic_work.css') ?>">
<link rel="stylesheet" href="assets/mechanic_estimate.css?v=<?= (int)filemtime(__DIR__.'/assets/mechanic_estimate.css') ?>"></head><body>
<script>window.ABC_ESTIMATE=<?=json_encode($payload,JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT)?>;</script>
<header class="header"><div class="header-inner"><div><strong>ABC <span>DÍLNA</span></strong><small>ZAKÁZKOVÝ LIST / PŘEDBĚŽNÁ CENA</small></div><div class="header-links"><a href="mechanic_work.php?job=<?=(int)$id?>">Zpět na auto</a></div></div></header>
<div class="main-wrap estimate-wrap"><main id="estimate-app"><p>Načítám požadované práce…</p></main><div id="estimate-notice" role="status" hidden></div></div>
<script src="assets/mechanic_estimate.js?v=<?= (int)filemtime(__DIR__.'/assets/mechanic_estimate.js') ?>" defer></script>
</body></html>
