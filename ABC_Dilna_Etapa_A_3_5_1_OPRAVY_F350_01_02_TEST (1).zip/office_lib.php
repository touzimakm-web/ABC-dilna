<?php
declare(strict_types=1);
class OfficeRule extends RuntimeException {}
require_once __DIR__.'/app/calendar_a.php';
function office_slot(string $date,string $time,$duration,bool $future=true): array {
    $d=DateTimeImmutable::createFromFormat('!Y-m-d H:i',$date.' '.$time);
    if(!$d||$d->format('Y-m-d H:i')!==$date.' '.$time)throw new OfficeRule('Zadej platné datum a čas.');
    if($future&&$d<new DateTimeImmutable('-5 minutes'))throw new OfficeRule('Termín musí být v budoucnosti.');
    $end=null;
    if($duration!==null&&$duration!==''){$n=filter_var($duration,FILTER_VALIDATE_INT);$s=a_settings();if(!$n||$n<$s['min_duration']||$n>$s['max_duration'])throw new OfficeRule('Délka musí být '.$s['min_duration'].'–'.$s['max_duration'].' minut.');$end=$d->modify('+'.$n.' minutes')->format('Y-m-d H:i:s');}
    return [$d->format('Y-m-d H:i:s'),$end];
}
function office_lock_calendar(PDO $db): void {
    $s=$db->query('SELECT GET_LOCK('.$db->quote(office_calendar_key($db)).',5)');
    if ((int)$s->fetchColumn()!==1) throw new OfficeRule('Kalendář právě upravuje kolega. Zkus to znovu.');
}
function office_calendar_key(PDO $db): string {return 'abc_calendar_'.substr(hash('sha256',(string)$db->query('SELECT DATABASE()')->fetchColumn()),0,24);}
function office_unlock_calendar(PDO $db): void { $db->query('SELECT RELEASE_LOCK('.$db->quote(office_calendar_key($db)).')'); }
function office_ensure_slot(PDO $db,string $start,?string $end,int $exclude,int $mechanic): void {
    $r=$exclude?query('SELECT resource_id,resource_start,resource_end,work_mode,job_id FROM office_appointments WHERE id=?',[$exclude])->fetch():null;
    a_calendar_check($db,$start,$end,$exclude,$mechanic,$r['resource_id']??null,$r['resource_start']??null,$r['resource_end']??null,$r['work_mode']??'inside',(int)($r['job_id']??0));
}

function lock_job(int $id,array $u): array {
    query('SELECT id FROM jobs WHERE id=? FOR UPDATE',[$id]);
    return get_job($id,$u);
}
function require_priced(int $id): void {
    if((int)query("SELECT COUNT(*) FROM abc_quick_tasks WHERE job_id=? AND entry_type='work' AND status<>'cancelled' AND kind='labor' AND quantity IS NULL",[$id])->fetchColumn())
        fail('Hodiny doplnit: bez účtovaného množství nelze vystavit doklad, přijmout platbu ani uzavřít zakázku.',409,['code'=>'quantity_required']);
    if ((int)query("SELECT COUNT(*) FROM abc_quick_tasks t LEFT JOIN items i ON i.id=t.item_id AND i.job_id=t.job_id WHERE t.job_id=? AND t.entry_type='work' AND t.status='done' AND i.unit_price IS NULL",[$id])->fetchColumn())
        fail('Některé práce ještě nemají cenu. Nejdřív je naceň, případně zruš.',409);
}
