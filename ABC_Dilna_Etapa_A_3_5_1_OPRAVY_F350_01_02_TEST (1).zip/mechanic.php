<?php
declare(strict_types=1);
require __DIR__.'/app/bootstrap.php';require __DIR__.'/app/layout.php';
$u=login_required();page_header('Dílna',$u);
?><script>window.ABC_MECH=<?=json_encode(auth_payload($u),JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT)?>;</script><div id="mech-notice" role="status" hidden></div><div id="mech-app" class="mechanic-content"><p>Načítám dílnu…</p></div><script src="assets/mechanic.js?v=350" defer></script><?php page_footer();
