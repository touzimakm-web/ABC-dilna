<?php
declare(strict_types=1);
require __DIR__.'/app/bootstrap.php';
$error='';
if(saas_enabled()&&empty($GLOBALS['abc_tenant'])){
    // Výběr kódu servisu je veřejný GET formulář bez relace a CSRF.
    // Opožděná odpověď tohoto portálu nesmí přepsat cookie nového přihlášení.
    // Skutečný přihlašovací formulář pro vybraný servis dál cookie i CSRF má.
    if(($_SERVER['REQUEST_METHOD']??'GET')==='GET')header_remove('Set-Cookie');
    require __DIR__.'/saas_portal.php';exit;
}

if (!empty($_SESSION['user_id'])) {
    $u=login_required();redirect($u['role']==='owner'?'office.php':'mechanic.php');
}
if (($_SERVER['REQUEST_METHOD']??'GET')==='POST') {
    require_csrf();
    if (!$secure&&!in_array($_SERVER['REMOTE_ADDR']??'',['127.0.0.1','::1'],true)) fail('Pro přihlášení použij HTTPS.',400);
    $email=mb_strtolower(post_str($_POST,'email',190));$password=post_str($_POST,'password',200);
    $eh=hash('sha256',$email);$ip=hash('sha256',$_SERVER['REMOTE_ADDR']??'');
    $attempts=(int)query('SELECT COUNT(*) FROM login_attempts WHERE attempted_at>DATE_SUB(NOW(),INTERVAL 10 MINUTE) AND (email_hash=? OR ip_hash=?)',[$eh,$ip])->fetchColumn();
    if ($attempts>=10) { http_response_code(429);$error='Příliš mnoho pokusů. Zkus přihlášení za 10 minut.'; }
    else {
        $u=query('SELECT * FROM users WHERE email=? AND active=1',[$email])->fetch();
        $valid=password_verify($password,$u?$u['password_hash']:'$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi');
        if ($u&&$valid) {
            $selectedTenant=$_SESSION['tenant_id']??null;session_regenerate_id(true);$_SESSION=['tenant_id'=>$selectedTenant,'user_id'=>(int)$u['id'],'last_seen'=>time(),'session_version'=>(int)$u['session_version'],'db_scope'=>db_scope()];csrf();
            query('DELETE FROM login_attempts WHERE attempted_at<DATE_SUB(NOW(),INTERVAL 1 DAY) OR (email_hash=? AND ip_hash=?)',[$eh,$ip]);
            redirect($u['role']==='owner'?'office.php':'mechanic.php');
        }
        query('INSERT INTO login_attempts(email_hash,ip_hash) VALUES (?,?)',[$eh,$ip]);
        $error='E-mail nebo heslo není správné.';
    }
}
?><!doctype html><html lang="cs"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>ABC Dílna · Přihlášení</title><link rel="stylesheet" href="assets/mechanic.css?v=310"></head><body class="login-body"><div class="login-brand">ABC <span>DÍLNA</span></div><main class="login-card"><div class="eyebrow">SERVISNÍ SYSTÉM</div><h1>Vítejte<br>v ABC Dílně<span class="accent">.</span></h1><p><strong><?=e($config['company_name'])?></strong><br>Zakázky, auta a celý tým.</p><?php if(isset($_SESSION['flash'])):?><div class="notice"><?=e($_SESSION['flash'])?></div><?php unset($_SESSION['flash']);endif;?><?php if($error):?><div class="notice error" role="alert"><?=e($error)?></div><?php endif;?><form method="post"><input type="hidden" name="csrf" value="<?=e(csrf())?>"><label class="field">E-mail<input type="email" name="email" required maxlength="190" autocomplete="username" value="<?=e($_POST['email']??'')?>" placeholder="vas@email.cz"></label><label class="field">Heslo<input type="password" name="password" required maxlength="200" autocomplete="current-password" placeholder="Vaše heslo"></label><button class="button orange">Přihlásit se <span>→</span></button></form><p class="minor">Přístup pouze pro tým <?=e($config['company_name'])?>.</p></main></body></html>
