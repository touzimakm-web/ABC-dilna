<?php
require __DIR__.'/office_document.php';
