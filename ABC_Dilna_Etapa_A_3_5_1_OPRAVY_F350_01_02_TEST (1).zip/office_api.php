<?php
declare(strict_types=1);
require __DIR__.'/app/bootstrap.php';require __DIR__.'/office_lib.php';
$u=login_required();$p=payload();$action=(string)($_GET['action']??'');
if($action!=='issue_invoice')fail('Neznámá operace.',404);
permission($u,'issue_invoices');issuer_ready();$id=positive_id($p['job_id']??null);
get_job($id,$u);
db()->beginTransaction();$op=operation_begin($u,'invoice',$p);$j=lock_job($id,$u);
if(!in_array($j['status'],['done','closed'],true))fail('Nejdřív dokonči opravu.',409);
if(query('SELECT id FROM office_invoices WHERE job_id=?',[$id])->fetch())fail('Zakázka už má fakturu.',409);
card_version($p,(int)$j['revision'],'job',array_intersect_key($j,array_flip(['id','status','revision'])));
require_priced($id);$t=totals($id);if($t['discount']>$t['subtotal']+.009)fail('Sleva je vyšší než cena skutečně provedených položek. Uprav slevu.',409);if($t['total']<=0)fail('Faktura musí mít kladnou částku.');
if(card_incomplete_labor($id))fail('Práce ještě nejsou dokončené.',409);
$name=post_str($p,'customer_name',160);if(!$name||!post_str($p,'customer_address',500))fail('Vyplň odběratele a jeho adresu.');
$email=post_str($p,'customer_email',190);if($email&&!filter_var($email,FILTER_VALIDATE_EMAIL))fail('Neplatný e-mail.');
$ico=post_str($p,'customer_ico',20);if($ico&&!preg_match('/^\d{8}$/D',$ico))fail('IČO musí mít osm číslic.');
$dic=post_str($p,'customer_dic',20);if($dic&&!preg_match('/^[A-Z]{2}[A-Z0-9]{2,18}$/D',$dic))fail('Neplatné DIČ odběratele.');
$days=filter_var($p['due_days']??14,FILTER_VALIDATE_INT);if($days===false||$days<0||$days>90)fail('Splatnost musí být 0–90 dní.');
$lines=card_items($id,true);$context=card_document_context($j);
$supplier=[];foreach(['company_name','company_address','company_ico','company_phone','company_email','company_bank_account','company_vat','company_dic'] as $key)$supplier[$key]=$config[$key];
$supplier['tax_summary']=billing_tax($t['total'],$config);$supplier['taxable_on']=date('Y-m-d');
query('INSERT INTO office_invoices(job_id,customer_name,customer_address,customer_ico,customer_email,issued_on,due_on,total,payment_method,lines_json,supplier_json,note,created_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)',
    [$id,$name,post_str($p,'customer_address',500),$ico,$email,date('Y-m-d'),date('Y-m-d',strtotime('+'.$days.' days')),$t['total'],'transfer',json_encode($lines,JSON_UNESCAPED_UNICODE),json_encode($supplier,JSON_UNESCAPED_UNICODE),post_str($p,'note',1000),$u['id']]);
$invoice=(int)db()->lastInsertId();query('UPDATE office_invoices SET context_json=? WHERE id=?',[json_encode($context,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR),$invoice]);if(saas_enabled())query('UPDATE office_invoices SET customer_dic=? WHERE id=?',[$dic,$invoice]);query('UPDATE office_invoices SET discount_amount=? WHERE id=?',[$t['discount'],$invoice]);$number=date('Y').'-'.str_pad((string)$invoice,6,'0',STR_PAD_LEFT);
query('UPDATE office_invoices SET invoice_no=? WHERE id=?',[$number,$invoice]);
query('INSERT IGNORE INTO abc_job_access(job_id,user_id,granted_by) VALUES (?,?,?)',[$id,$u['id'],$u['id']]);
query("UPDATE jobs SET billing_state='documented',revision=revision+1 WHERE id=?",[$id]);
log_event((int)$u['id'],$id,'invoice_issued',$number);operation_commit($op,['invoice_id'=>$invoice,'invoice_no'=>$number]);
