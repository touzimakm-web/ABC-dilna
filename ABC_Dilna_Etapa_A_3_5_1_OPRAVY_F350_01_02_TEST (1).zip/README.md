Aktuální vydání: **3.5.1 – opravy F350-01 a F350-02**, pokračování stejné 3.5.0 se zachovanou M02, ceníkem, dokumenty a Frontou V2.

Začněte v `CTI_ME_351.txt`. Rozsah: `ZMENY_351.txt`; migrace: `sql/MIGRACE_351.txt`; skutečné výsledky: `TESTOVANI_351.txt`; přejímka: `SCENARE_351.txt`; změny zdrojů: `docs/DIFF_350_351.patch`. Na WEDOS nic nenasazeno. Následující texty dokumentují předchozí vydání.

Aktuální vydání: **3.5.0 – vlastní ceník a firemní dokumenty**, pokračování stejného projektu 3.4.0 se zachovanou M02 a Frontou V2.

Začněte v `CTI_ME_350.txt`. Audit výchozího stavu: `docs/AUDIT_CENIK_DOKUMENTY_350.txt`. Změny: `ZMENY_350.txt`, migrace: `sql/MIGRACE_350.txt`, skutečné testy a omezení: `TESTOVANI_350.txt`, ruční přejímka: `SCENARE_350.txt`. Na WEDOS nic nenasazeno. Následující texty dokumentují předchozí milníky.

Aktuální vydání: **3.4.0 – Etapa A / Fronta V2**, pokračování 3.3.1 se stejnou M02.

Začněte v `CTI_ME_340.txt`. Změny: `ZMENY_340.txt`, migrace: `sql/MIGRACE_340.txt`, skutečné výsledky a omezení: `TESTOVANI_340.txt`, přejímka: `SCENARE_340.txt`. Původní vydání zůstalo zachováno; na WEDOS nic nenasazeno. Následující texty dokumentují starší milníky.

Aktuální vydání: **3.3.1 – opravy F01–F06 v Etapě A**.

Postup: `CTI_ME_331.txt`; rozsah: `ZMENY_331.txt`; skutečné zkoušky: `TESTOVANI_331.txt`; migrace: `sql/MIGRACE_331.txt`. Kód i testy lze porovnat přes `DIFF_330_331.patch`. Texty níže dokumentují předchozí milníky. Na WEDOS nebylo nasazeno.

Aktuální vydání: **Etapa A / 3.3.0**, pokračování SaaS 3.1 + M02.

Začněte v `CTI_ME_ETAPA_A.txt`. Rozsah je v `ZMENY_ETAPA_A.txt`, skutečné výsledky v `TESTOVANI_ETAPA_A.txt`, přejímka v `SCENARE_ETAPA_A.txt` a migrace v `sql/MIGRACE_ETAPA_A.txt`. Starší text níže dokumentuje historii základu. Na WEDOS nebylo nasazeno.

# ABC Dílna – milník A1 + A2 (3.2.0-a12)

Pokračování dodaného SaaS 3.1 + M02. Schválené řádky pracovní karty zůstávají zachované. Tento balíček je samostatně kontrolovatelný první milník; A3–A6 navazují. Na WEDOS nebyl nasazen.

Začněte [CTI_ME_A12.txt](CTI_ME_A12.txt). Změny jsou v [ZMENY_A12.txt](ZMENY_A12.txt), skutečné výsledky a limity v [TESTOVANI_A12.txt](TESTOVANI_A12.txt). Novou verzi instalujte jen do nové složky a oddělených databází.

Níže je dokumentace výchozího SaaS základu; aktuální stav tohoto milníku určují dokumenty A12 výše.

# ABC Dílna SaaS 3.1.0

Funkční PHP aplikace pro poskytování autoservisům za měsíční poplatek. Jeden společný projekt, oddělená databáze každého servisu a samostatná správa provozovatele služby. Mechanik a recepce stejného servisu používají společná data. Základ vznikl rozšířením ověřené verze 3.0; původní zakázky, položky a vazby se nepřepisují novým systémem.

**Začněte [CTI_ME_START.txt](CTI_ME_START.txt).** Starou instalaci ponechte nedotčenou. Pro tuto verzi použijte novou složku `/abc-saas-test/` a nové databáze.

## Co funguje

- Provozovatel: vlastní přihlášení, evidence klientských servisů, zřízení klienta s jeho samostatnou databází, tarify, měsíční předpisy předplatného, odkaz na externí fakturu, potvrzení skutečných i částečných bankovních plateb, audit změn přístupu.
- Servis: vlastní název, fakturační údaje, tým, oprávnění, zákazníci, vozidla a historie, ceník, samostatné číselné řady, zakázky, kalendář, faktury a pokladna. Stejný e-mail může být účtem v různých servisech.
- Mechanik: čtyři hlavní tlačítka, příjem pomocí SPZ/zákazníka a karet služeb, nepovinný termín. Karty jsou požadavky, nevytvářejí placenou práci. Později konkrétní práce a díly ze skutečného ceníku nebo ručně, neznámé ceny, desetinné množství, dokončení, tisk, částečná hotovost/karta a předání hotovosti majiteli.
- Recepce: všechna auta vlastního servisu, přiřazování mechaniků, kalendář a kontrola kolizí, firma s více auty, ceník, slevy, faktury a skutečné úhrady, pohledávky, správa týmu.
- Doklady: neplátce DPH i standardní tuzemská fakturace plátce se sazbou 21 %. Všechny zadávané ceny jsou konečné včetně případné DPH. U plátce se nejdříve vystaví faktura, poté se k ní přijme platba; potvrzení platby nenahrazuje daňový doklad. Položky, sleva, dodavatel a vyčíslení daně se při vystavení uchovají. Zvláštní daňové režimy ani jiné sazby nejsou podporované.
- Neaktivní/propadlé předplatné: zákaz dalších změn na serveru, zachované prohlížení, tisk a export vlastních dat. Data se automaticky nemažou.
- Export majitele: obchodní data vlastního servisu v JSON, bez hesel a databázových přístupů. Je to přenosný datový export, nikoli náhrada SQL zálohy.

## Jak jsou servisy oddělené

Platforma má vlastní databázi s tarify, předplatným a registrací servisů. Každý servis má jinou databázi a jiného databázového uživatele. Přístupové údaje jsou v registru šifrované AES-256-GCM klíčem uloženým v serverové konfiguraci. Databáze nese vlastní neměnnou identitu servisu; stejné zákaznické databázi nelze přidělit druhý servis. SQL dotazy obchodní části nevycházejí z tenant_id poslaného klientem. Přihlášení je navázané na serverem zvolený servis a jeho databázi.

Provozovatel a zaměstnanci servisů mají různé relace. Správce platformy nemá v aplikaci přihlášení za klienta. Provozovatel hostingu má z podstaty správy serveru přístup ke konfiguraci a zálohám; oddělené databáze nejsou ochranou před kompromitovaným hostitelem. Koncepty v prohlížeči jsou oddělené i podle servisu; stará záložka nemůže poslat API požadavek s kontextem jiného účtu.

Zůstává CSRF, kontrola role a přiřazení auta, rušení relací při deaktivaci účtu/změně hesla, omezení přihlašovacích pokusů a oprava veřejné cesty cookie pro WEDOS. Založení zakázky, účetní položky, faktury, úhrady, předání hotovosti a potvrzení platby předplatného mají ochranu před duplicitou. Úpravy cen a plateb jsou dohledatelné.

## Rozsah první komerční verze

Jde o základ pro **kontrolovaný pilot placené služby**. Zřízení databází na WEDOSu a potvrzení platby předplatného jsou ruční. Registrace veřejnosti uloží skutečnou žádost provozovateli, nevytváří automaticky webhosting a neposílá e-mail. Předpis předplatného je interní evidence, nikoli automaticky vytvořená faktura: skutečnou fakturu za pronájem vystavíte například v iDokladu mimo aplikaci a zadáte její číslo. Měsíční cena je vámi zadaná konečná cena v Kč. Automatická platební brána není připojená.

Běžný sdílený hosting má limity počtu databází, spojení a výkonu. Před přijetím dalšího klienta ověřte jeho kapacitu. Růst služby může vyžadovat jiný tarif nebo vlastní server. Databáze jednotlivých klientů lze přestěhovat bez změny jejich pracovního postupu.

Storna, opravné daňové doklady a vratky nemají dokončený pracovní postup; vystavené ceny ani zapsané úhrady se nepřepisují. Aplikace není kompletní účetní systém. Napojení na iDoklad API, EET, registr vozidel, ARES a dodavatele dílů nejsou připojená. Existující API ministerstva lze doplnit po dodání dokumentace a bezpečném nastavení; žádné údaje se nesimulují. AI je v klientských servisech vypnutá.

## Instalace, migrace a testy

- [WEDOS: platforma a první dva servisy](docs/INSTALACE_SAAS_WEDOS.md)
- [Architektura a migrace 3.1](docs/ARCHITEKTURA_310.md)
- [Přejímací scénáře SaaS](docs/PREJIMACI_ZKOUSKA_SAAS.md)
- [Změny proti 3.0](docs/ZMENY_310.md)
- [Skutečné testování a limity](TESTOVANI.md)

PHP 8.1+ s PDO MySQL, mbstring, OpenSSL a sessions; MySQL/MariaDB s InnoDB. Ověřené runtime verze jsou uvedené v testovacím protokolu. Žádné povinné externí API klíče ani Node proces na hostingu. `app/config.php` se do ZIPu nepřidává.

Starší dokumentace 2.1/3.0 v `docs` vysvětluje původní workflow a migrace, není aktuálním návodem k instalaci SaaS. Zkoušky obsahují pouze dočasná testovací data; čistá instalace nevytváří ukázkové zákazníky, zakázky ani ceny.
