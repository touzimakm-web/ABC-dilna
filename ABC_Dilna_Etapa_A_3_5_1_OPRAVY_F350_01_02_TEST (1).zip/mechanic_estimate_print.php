<?php
/** ABC Dílna 2.0.6 – tisk uloženého předběžného odhadu. */
declare(strict_types=1);
require __DIR__.'/app/bootstrap.php';
$u=login_required();require_role($u,['owner','mechanic']);
$id=filter_var($_GET['id']??null,FILTER_VALIDATE_INT,['options'=>['min_range'=>1]]);
if(!$id)fail('Neplatné číslo odhadu.');
$s=db()->prepare('SELECT * FROM abc_job_estimates WHERE id=?');$s->execute([(int)$id]);$quote=$s->fetch();
if(!$quote)fail('Odhad nebyl nalezen.',404);
$job=get_job((int)$quote['job_id'],$u);
$lines=json_decode((string)$quote['lines_json'],true);
if(!is_array($lines))fail('Neplatná data uloženého odhadu.',500);
function ee($value):string{return htmlspecialchars((string)($value??''),ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');}
function money_cz($value):string{return number_format((float)$value,2,',',' ').' Kč';}
$app=db()->prepare("SELECT start_at FROM office_appointments WHERE job_id=? AND status IN ('confirmed','requested') ORDER BY start_at DESC LIMIT 1");
$app->execute([(int)$quote['job_id']]);$arrival=$app->fetchColumn()?:null;
$hasMissing=false;foreach($lines as $l){if(!isset($l['min_price'],$l['max_price'])){$hasMissing=true;break;}}
?><!doctype html><html lang="cs"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>Zakázkový list – ABC Autoslužby</title>
<style>
@page{size:A4;margin:18mm}*{box-sizing:border-box}body{font-family:Arial,'DejaVu Sans',sans-serif;color:#14283d;background:#e9eef2;margin:0;line-height:1.4}.paper{max-width:820px;background:#fff;margin:20px auto;padding:36px;box-shadow:0 2px 12px #aab8c5}.brand{display:flex;justify-content:space-between;gap:16px;border-bottom:4px solid #d78315;padding-bottom:16px}.brand h1{font-size:25px;margin:0}.brand p{font-size:12px;margin:6px 0}.brand aside{text-align:right;font-size:12px}.doc-title{font-size:21px;margin:24px 0 14px}.meta{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin:14px 0}.meta div{padding:9px 12px;background:#f5f7f9;border-radius:8px;font-size:13px}.meta strong{display:block;font-size:11px;color:#5c7180;margin-bottom:3px}table{width:100%;border-collapse:collapse;margin:16px 0;font-size:12px}th{text-align:left;background:#122e42;color:white;padding:10px}td{padding:10px;border-bottom:1px solid #ccd7df}td:nth-child(n+2),th:nth-child(n+2){text-align:right}.total{margin-top:16px;border:2px solid #d78315;padding:15px;font-size:20px;font-weight:800;text-align:right}.small{font-size:11px;color:#4e6170;margin-top:12px}.foot{font-size:12px;margin:18px 0}.signs{display:grid;grid-template-columns:1fr 1fr;gap:48px;margin-top:55px}.signs div{border-top:1px solid #9aabb5;padding-top:8px;font-size:12px;text-align:center}.tools{max-width:820px;margin:16px auto;display:flex;justify-content:space-between;gap:8px}.tools button,.tools a{padding:14px 18px;background:#152e41;color:#fff;border:0;border-radius:9px;text-decoration:none;font-weight:bold;cursor:pointer}@media print{body{background:white}.paper{box-shadow:none;margin:0;padding:0;max-width:none}.tools{display:none}}
</style></head><body>
<div class="tools"><a href="mechanic_estimate.php?job=<?=(int)$quote['job_id']?>">← Upravit nový odhad</a><button onclick="window.print()">🖨 Vytisknout / uložit jako PDF</button></div>
<div class="paper"><div class="brand"><div><h1><?=ee($config['company_name'])?></h1><p><?=ee($config['company_address'])?></p><p>Telefon: <?=ee($config['company_phone'])?> · IČO: <?=ee($config['company_ico'])?></p></div><aside><strong>Zakázkový list – předběžný odhad</strong><p>Odhad č. <?= (int)$quote['id'] ?></p><p>Vytvořeno: <?=ee(date('d. m. Y H:i',strtotime((string)$quote['created_at'])))?></p></aside></div>
<h2 class="doc-title">Požadované práce a orientační cena</h2>
<div class="meta"><div><strong>Zákazník / firma</strong><?=ee($job['customer_name']?:'Neuvedeno')?></div><div><strong>Telefon</strong><?=ee($job['customer_phone']?:'Neuvedeno')?></div><div><strong>Vozidlo</strong><?=ee($job['vehicle']?:'Neuvedeno')?></div><div><strong>SPZ</strong><?=ee($job['plate']?:'Neuvedeno')?></div><div><strong>Číslo zakázky</strong>#<?= (int)$job['id']?></div><div><strong>VIN</strong><?=ee($job['vin']?:'Neuvedeno')?></div>
<?php if($arrival): ?><div><strong>Objednaný příjezd</strong><?=ee(date('d. m. Y H:i',strtotime((string)$arrival)))?></div><?php endif; ?></div>
<table><thead><tr><th>Požadovaná práce / materiál</th><th>Množství</th><th>Odhad za položku celkem</th></tr></thead><tbody>
<?php foreach($lines as $l): $q=array_key_exists('quantity',$l)&&$l['quantity']===null?null:(float)($l['quantity']??1);$min=$l['min_price']??null;$max=$l['max_price']??null; ?>
<tr><td><?=ee($l['description']??'Úkon')?><div class="small"><?=ee($l['category']??'')?></div></td><td><?=$q===null?'Hodiny doplnit':ee($q)?> <?=ee($l['unit']??'jedn.')?></td><td><?php if($q===null||$min===null||$max===null): ?>Bude upřesněno<?php elseif((float)$min===(float)$max): ?><?=ee(money_cz((float)$min*$q))?><?php else: ?><?=ee(money_cz((float)$min*$q))?> – <?=ee(money_cz((float)$max*$q))?><?php endif; ?></td></tr>
<?php endforeach; ?>
</tbody></table>
<div class="total">Předběžný odhad oceněných položek: <?=ee(money_cz($quote['lower_total']))?><?php if((float)$quote['lower_total']!==(float)$quote['upper_total']): ?> – <?=ee(money_cz($quote['upper_total']))?><?php endif;?></div>
<?php if($hasMissing): ?><p class="foot"><strong>Pozor:</strong> Některé práce či díly zatím nemají cenu a nejsou v součtu zahrnuty. Konečná cena tedy může být vyšší.</p><?php endif; ?>
<?php if(trim((string)$quote['note'])!==''): ?><div class="foot"><strong>Poznámka servisu:</strong> <?=nl2br(ee($quote['note']))?></div><?php endif; ?>
<p class="foot">Tento dokument je orientační odhad podle známého rozsahu prací, nikoli faktura ani potvrzení o úhradě. Cena se může upřesnit po prohlídce vozidla a určení dílů. Při zjištění potřeby podstatně vyšší ceny musí servis zákazníka bez zbytečného odkladu informovat. Další práce nad dohodnutý rozsah vyžadují odsouhlasení.</p>
<div class="signs"><div>Přijal servis / datum</div><div>Zákazník / převzal návrh</div></div>
</div></body></html>
