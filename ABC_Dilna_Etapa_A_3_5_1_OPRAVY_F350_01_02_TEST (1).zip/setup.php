<?php
declare(strict_types=1);
require __DIR__.'/app/bootstrap.php';require __DIR__.'/app/migrations.php';
$error='';$configured=$config['db_name']&&$config['db_user'];
if ($configured) {
    try {
        if (db()->query("SHOW TABLES LIKE 'schema_meta'")->fetchColumn()) fail('Aplikace už je nainstalovaná. Přihlas se na úvodní stránce.',409);
    } catch (PDOException $ex) { $error='Připojení k databázi se nezdařilo. Ověř údaje v app/config.php.'; }
}
if (($_SERVER['REQUEST_METHOD']??'GET')==='POST') {
    require_csrf();
    if (!$secure && !in_array($_SERVER['REMOTE_ADDR']??'',['127.0.0.1','::1'],true)) fail('Instalaci otevři přes HTTPS.',400);
    $token=post_str($_POST,'setup_token',200);
    if (strlen((string)$config['setup_token'])<24||str_contains((string)$config['setup_token'],'ZDE_NASTAVTE')||!hash_equals((string)$config['setup_token'],$token)) fail('Neplatný instalační klíč. Nastav vlastní klíč v app/config.php.',403);
    $name=post_str($_POST,'name',120);$email=mb_strtolower(post_str($_POST,'email',190));$password=post_str($_POST,'password',200);
    if (!$name||!filter_var($email,FILTER_VALIDATE_EMAIL)||mb_strlen($password)<12||strlen($password)>72) fail('Vyplň jméno, platný e-mail a heslo alespoň 12 znaků, nejvýše 72 bajtů.');
    $p=db();$lock='abc_install_'.substr(hash('sha256',(string)$config['db_name']),0,24);
    $s=$p->prepare('SELECT GET_LOCK(?,5)');$s->execute([$lock]);
    if ((int)$s->fetchColumn()!==1) fail('Právě probíhá jiná instalace.',409);
    try {
        if ($p->query('SHOW TABLES')->fetchColumn()) fail('Databáze není prázdná. Založ novou databázi; instalátor nepřepisuje existující data.',409);
        $sql=preg_replace('/^--.*$/m','',file_get_contents(__DIR__.'/sql/schema.sql'));
        foreach(explode(';',$sql) as $statement) if(trim($statement)!=='') $p->exec($statement);
        abc_migrate_a12($p);
        $p->beginTransaction();
        query('INSERT INTO users(name,email,password_hash,role,permissions) VALUES (?,?,?,?,?)',[$name,$email,password_hash($password,PASSWORD_DEFAULT),'owner','[]']);
        query('INSERT IGNORE INTO schema_meta(version) VALUES (?)',['3.0.0']);
        $p->commit();tenant_setup_complete();
        flash('Instalace je hotová. Přihlas se svým e-mailem a heslem.');redirect('index.php');
    } finally { $s=$p->prepare('SELECT RELEASE_LOCK(?)');$s->execute([$lock]); }
}
?><!doctype html><html lang="cs"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Instalace · ABC Dílna</title><link rel="stylesheet" href="assets/mechanic.css"></head><body class="login-body"><main class="login-card wide"><div class="eyebrow">ABC DÍLNA · <?=e($config['company_name'])?></div><h1>Spustíme tvoji dílnu.</h1><p>Nová instalace ABC Dílny Etapa A do prázdné MySQL databáze.</p>
<?php if(!$configured):?><div class="info">Zkopíruj soubor <code>app/config.example.php</code> jako <code>app/config.php</code>. Doplň přístup k nové databázi, vlastní instalační klíč alespoň 24 znaků a údaje firmy. Poté obnov tuto stránku.</div><?php else:?>
<?php if($error):?><div class="notice error"><?=e($error)?></div><?php endif;?><form method="post"><input type="hidden" name="csrf" value="<?=e(csrf())?>"><label class="field"><?=saas_enabled()?'Instalační klíč servisu':'Instalační klíč z konfigurace'?><input name="setup_token" type="password" required autocomplete="off"></label><label class="field">Jméno majitele<input name="name" required maxlength="120" autocomplete="name"></label><label class="field">E-mail majitele<input name="email" type="email" required maxlength="190" autocomplete="username"></label><label class="field">Vlastní heslo (alespoň 12 znaků)<input name="password" type="password" minlength="12" maxlength="200" required autocomplete="new-password"></label><button class="button orange">Vytvořit aplikaci a účet majitele →</button></form><?php endif;?><p class="minor">Instalátor nepřevádí ani nepřepisuje databázi původní aplikace.</p></main></body></html>
