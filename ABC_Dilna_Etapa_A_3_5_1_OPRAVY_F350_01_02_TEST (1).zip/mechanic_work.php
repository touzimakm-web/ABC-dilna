<?php
declare(strict_types=1);
require __DIR__.'/app/bootstrap.php';require __DIR__.'/app/layout.php';
$u=login_required();if(isset($_GET['job']))get_job(positive_id($_GET['job']),$u);
page_header(isset($_GET['job'])?'Pracovní karta':'Rychlý příjem',$u);
?><link rel="stylesheet" href="assets/mechanic_work.css?v=351"><script>window.ABC_MECH=<?=json_encode(auth_payload($u),JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT)?>;</script><div id="work-notice" role="status" hidden></div><div id="work-app" class="mechanic-content"><p>Načítám pracovní kartu…</p></div><link rel="stylesheet" href="assets/operations_v2.css?v=351"><script src="assets/operations_v2.js?v=351" defer></script><script src="assets/mechanic_work.js?v=351" defer></script><?php page_footer();
