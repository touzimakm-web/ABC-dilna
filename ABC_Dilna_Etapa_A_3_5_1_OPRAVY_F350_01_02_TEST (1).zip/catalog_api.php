<?php
declare(strict_types=1);require __DIR__.'/app/bootstrap.php';require __DIR__.'/office_lib.php';$u=login_required();$action=post_str($_GET,'action',40);
if(($_SERVER['REQUEST_METHOD']??'GET')==='GET'){
 if($action==='list'){$manage=abc_perm($u,'manage_catalog');json_ok(['items'=>c_list($manage,$manage),'state'=>query('SELECT * FROM abc_catalog_state WHERE id=1')->fetch(),'can_manage'=>$manage]);}
 if($action==='price_preview'){
  a_edit($u,'price_jobs');$j=get_job(positive_id($_GET['job_id']??null),$u);card_mutable((int)$j['id'],$j);$t=card_line((int)$j['id'],positive_id($_GET['task_id']??null));if(!$t['catalog_id'])fail('Tento řádek nemá doložený zdroj v ceníku.',409);$c=c_row((int)$t['catalog_id']);json_ok(['line'=>$t,'catalog'=>c_sale($c),'job_revision'=>$j['revision'],'compatible'=>$t['unit']===$c['unit']&&$t['kind']===$c['kind']]);
 }fail('Neznámá operace.',404);
}
$p=payload();$db=db();$db->beginTransaction();$op=operation_begin($u,'catalog_'.$action,$p);
if($action==='save'){$id=c_save($u,$p);operation_commit($op,['id'=>$id]);}
if($action==='settings'){
 permission($u,'manage_catalog');$old=query('SELECT * FROM abc_catalog_state WHERE id=1 FOR UPDATE')->fetch();card_version($p,(int)$old['revision'],'catalog_state',$old);$date=post_str($p,'valid_from',10);if($date&&!a_date($date))fail('Neplatné datum platnosti.');query('UPDATE abc_catalog_state SET valid_from=?,revision=revision+1 WHERE id=1',[$date?:null]);log_event((int)$u['id'],0,'catalog_validity','Platnost ceníku',['before'=>$old['valid_from'],'after'=>$date?:null]);operation_commit($op);
}
if($action==='bind_template'){
 permission($u,'manage_catalog');$old=query('SELECT * FROM abc_workshop_settings WHERE id=1 FOR UPDATE')->fetch();card_version($p,(int)$old['revision'],'templates',['revision'=>$old['revision']]);$s=json_decode($old['settings_json'],true);$code=post_str($p,'template_code',60);$index=filter_var($p['row_index']??null,FILTER_VALIDATE_INT,['options'=>['min_range'=>0,'max_range'=>11]]);if($index===false)fail('Neplatný řádek.');$found=false;
 foreach($s['service_templates'] as &$template)if($template['code']===$code&&isset($template['rows'][$index])){$r=&$template['rows'][$index];if(empty($p['catalog_id']))unset($r['catalog_id']);else{$c=c_row(positive_id($p['catalog_id']),true);$r['catalog_id']=$c['id'];$r['description']=$c['description'];$r['kind']=$c['kind'];$r['unit']=$c['unit'];$r['quantity']=$c['unit']==='hod'?null:($r['quantity']??1);}$found=true;unset($r);}unset($template);if(!$found)fail('Karta nebo řádek se změnily.',409);
 query('UPDATE abc_workshop_settings SET settings_json=?,revision=revision+1 WHERE id=1',[json_encode($s,JSON_UNESCAPED_UNICODE)]);log_event((int)$u['id'],0,'catalog_binding',$code.' / '.$index,['catalog_id'=>$p['catalog_id']??null]);operation_commit($op);
}
if($action==='reprice'){
 a_edit($u,'edit_lines');permission($u,'price_jobs');$id=positive_id($p['id']??null);$j=lock_job($id,$u);card_mutable($id,$j);card_version(['revision'=>$p['job_revision']??null],(int)$j['revision'],'job',['id'=>$id,'revision'=>$j['revision']]);$task=positive_id($p['task_id']??null);$t=card_line($id,$task);card_version($p,(int)$t['revision'],'line',$t);if(!$t['catalog_id']||$t['status']==='cancelled'||$t['entry_type']!=='work')fail('Tuto položku nelze přecenit.',409);$c=c_row((int)$t['catalog_id'],true);c_check($c,$p['catalog_revision']??null);if(empty($p['confirmed']))fail('Nejprve potvrď zobrazený rozdíl.');if($t['kind']!==$c['kind']||$t['unit']!==$c['unit'])fail('Druh nebo jednotka ceníku se změnila. Cenu nelze bez změny významu množství převzít.',409);
 $item=$t['item_id'];if($item)query('UPDATE items SET unit_price=? WHERE id=? AND job_id=?',[$c['unit_price'],$item,$id]);else{query('INSERT INTO items(job_id,kind,description,quantity,unit,unit_price,unit_cost) VALUES(?,?,?,?,?,?,?)',[$id,$t['kind'],$t['description'],$t['quantity'],$t['unit'],$c['unit_price'],$c['unit_cost']]);$item=(int)$db->lastInsertId();}
 query('UPDATE abc_quick_tasks SET item_id=?,revision=revision+1 WHERE id=?',[$item,$task]);c_source($task,$c,'catalog');price_history($u,$id,$task,$t['unit_price'],$c['unit_price'],$t['quantity']===null?null:(float)$t['quantity'],'reprice_catalog');$job=card_touch($u,$j,'Potvrzené převzetí aktuální ceny');log_event((int)$u['id'],$id,'catalog_reprice','#'.$task,['before'=>$t,'after'=>card_line($id,$task)]);operation_commit($op,['line'=>card_line($id,$task),'job'=>$job]);
}
fail('Neznámá operace.',404);
