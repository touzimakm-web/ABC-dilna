"""Real Chromium mobile/desktop actions; route.fetch commits before lost response."""
import re,json,secrets
from runtime import ROOT
from playwright.sync_api import sync_playwright,expect

def run_browser(r,check,wid,password,lift,bay):
 evidence=ROOT/('tests/evidence/340/browser-wedos' if r.prefix else 'tests/evidence/340/browser');evidence.mkdir(parents=True,exist_ok=True)
 o=r.owner
 def oi(j):return o.api('operations_api.php','info',id=j)[1]['operations']
 def op(j,action,**kw):
  st,d=o.api('operations_api.php',action,{'id':j,'revision':oi(j)['revision'],'request_key':secrets.token_hex(20),**kw});assert st==200,d
 # Release previous test's actual holds with explicit actions, never SQL delete.
 for jid in r.sql('SELECT job_id FROM abc_test.abc_job_presence WHERE ended_at IS NULL').splitlines():op(int(jid),'move_yard',move_confirmed=True)
 with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage']);phone=b.new_context(viewport={'width':412,'height':820},is_mobile=True,has_touch=True,locale='cs-CZ',timezone_id='Europe/Prague');desk=b.new_context(viewport={'width':1440,'height':1000},locale='cs-CZ');pg=phone.new_page();owner=desk.new_page();errors=[]
  for page in [pg,owner]:page.on('pageerror',lambda e:errors.append(str(e)));page.on('dialog',lambda d:d.accept())
  def goto(path,page=pg):page.goto(r.url+'/'+path);page.wait_for_load_state('networkidle')
  def act(selector,page=pg):
   target=page.locator(selector)
   if target.count() and not target.first.is_visible():
    group=target.first.locator('xpath=ancestor::details[1]')
    if group.count() and group.get_attribute('open') is None:group.locator('summary').first.click()
   target.click();page.wait_for_load_state('networkidle')
  def open_parts():
   outer=pg.locator('#ops-panel > section > details').filter(has=pg.locator('[data-ops-form="preparation"]')).first
   if outer.get_attribute('open') is None:outer.locator('summary').first.click()
   detail=pg.locator('.ops-part')
   if detail.get_attribute('open') is None:detail.locator('summary').click()
  def login(page,email,pw):
   goto('index.php',page);page.get_by_label('E-mail',exact=True).fill(email);page.get_by_label('Heslo',exact=True).fill(pw);page.get_by_role('button',name=re.compile('^Přihlásit se')).click();page.wait_for_load_state('networkidle')
  login(pg,'prvni@v2.test',password);login(owner,'owner@example.test',r.ownerpass)
  goto('mechanic_work.php');pg.locator('#find').fill('MOBILEV2')
  for service in ['Pneuservis','Oleje a filtry','Brzdy']:act('[data-service="'+service+'"]')
  act('[data-action="create"]');pg.wait_for_url(re.compile(r'mechanic.php\?saved=\d+'));j=int(pg.url.rsplit('=',1)[1]);goto('mechanic_work.php?job='+str(j));expect(pg.locator('#ops-panel')).to_contain_text('Na dvoře')
  check(oi(j)['location']=='yard' and oi(j)['appointment'] is None,'Browser 01: mobile intake with plate and three cards saves to real persistent queue without reservation')
  goto('mechanic.php?view=waiting');expect(pg.locator('.garage-car')).to_contain_text(['MOBILEV2']);check(pg.evaluate('document.documentElement.scrollWidth<=innerWidth'),'Browser queue fits Samsung width')
  goto('mechanic_work.php?job='+str(j));act('[data-ops-open="take_inside"]');pg.locator('dialog [data-ops-field="resource_id"]').select_option(str(lift));act('dialog [data-ops-confirm]');expect(pg.locator('dialog')).to_have_count(0);expect(pg.locator('#ops-panel')).to_contain_text('Hever 1')
  before=oi(j);act('[data-ops-open="wait_parts"]');expect(pg.locator('dialog')).to_contain_text('Hever 1');act('dialog [data-ops-cancel]');check(oi(j)['revision']==before['revision'] and oi(j)['status']==before['status'] and oi(j)['presence']==before['presence'],'Browser 09: cancelling resource-specific question changes neither phase nor occupancy')
  act('[data-ops-open="wait_parts"]');pg.locator('dialog [data-ops-field="release_choice"]').select_option('keep');act('dialog [data-ops-confirm]');expect(pg.locator('dialog')).to_have_count(0);check(oi(j)['status']=='parts' and oi(j)['presence']['resource_id']==lift,'Browser 05: mechanic explicitly keeps non-running car on named lift')
  act('[data-ops-open="wait_parts"]');pg.locator('dialog [data-ops-field="release_choice"]').select_option('move');pg.locator('dialog [data-ops-field="resource_id"]').select_option(str(bay));act('dialog [data-ops-confirm]');expect(pg.locator('dialog')).to_have_count(0);check(oi(j)['presence']['resource_id']==bay and len(oi(j)['history'])==2,'Browser 08: wait-and-transfer to ordinary bay commits phase and movement together')
  goto('office.php?view=jobs&job='+str(j),owner);expect(owner.locator('#office-ops-panel')).to_contain_text('Stání 1');act('[data-ops-open="wait_parts"]',owner);owner.locator('dialog [data-ops-field="release_choice"]').select_option('yard');act('dialog [data-ops-confirm]',owner);expect(owner.locator('dialog')).to_have_count(0);check(oi(j)['location']=='yard' and oi(j)['presence'] is None,'Browser 18: office uses same atomic wait/release action against same job')
  pg.reload();pg.wait_for_load_state('networkidle');expect(pg.locator('#ops-panel')).to_contain_text('Na dvoře');check(pg.locator('.m02-sheet').count()==1,'Browser 18: mechanic sees office release after refresh without losing M02')
  # Add a real priced part, directly edit its blue M02 row, then record partial receipt.
  st,d=o.api('mechanic_flow_api.php','add',{'id':j,'kind':'part','description':'Filtr V2','quantity':2,'unit':'ks','unit_price':100,'request_key':secrets.token_hex(20)});assert st==200,d;t=d['task_id'];pg.reload();pg.wait_for_load_state('networkidle');act('[data-edit-line="'+str(t)+'"]');pg.locator('[data-line-id="'+str(t)+'"] [data-line-field="unit_price"]').fill('125');act('[data-save-line="'+str(t)+'"]');expect(pg.locator('[data-line-id="'+str(t)+'"]')).to_contain_text('125 Kč')
  open_parts();part=pg.locator('[data-ops-form="part:'+str(t)+'"]');part.locator('[data-ops-field="stage"]').select_option('ordered');part.locator('[data-ops-field="ordered_quantity"]').fill('2');part.locator('[data-ops-field="expected_on"]').fill('2027-09-20');act('[data-ops-save-part="'+str(t)+'"]');part=pg.locator('[data-ops-form="part:'+str(t)+'"]');part.locator('[data-ops-field="quantity"]').fill('1');act('[data-ops-receive="'+str(t)+'"]');expect(pg.locator('#ops-panel')).to_contain_text('Částečně připravené díly');check(oi(j)['readiness']['state']=='partial' and oi(j)['parts'][0]['status']=='planned','Browser 12: manual order and actual partial receipt remain distinct from installed/billed part')
  # Lost server response: real DB write commits, browser gets network failure, exact operation retries.
  def lost(route):
   response=route.fetch();assert response.status==200,response.text();route.abort('failed')
  pg.route('**/operations_api.php?action=take_inside',lost);act('[data-ops-open="take_inside"]');pg.locator('dialog [data-ops-field="resource_id"]').select_option(str(lift));act('dialog [data-ops-confirm]');expect(pg.locator('dialog [data-ops-dialog-error]')).to_contain_text('není ověřené');check(oi(j)['presence']['resource_id']==lift,'Browser 17: dropped response happens after real committed admission')
  pg.unroute('**/operations_api.php?action=take_inside',lost);act('dialog [data-ops-confirm]');expect(pg.locator('dialog')).to_have_count(0);check(len(oi(j)['history'])==3,'Browser 17: retry after lost response acknowledges original admission and creates no duplicate interval')
  # Optimistic conflict: edited procurement fields remain after another user saves.
  open_parts();part=pg.locator('[data-ops-form="part:'+str(t)+'"]');part.locator('[data-ops-field="procurement_note"]').fill('Rozepsáno na mobilu')
  op(j,'assign_preparation',target=1);act('[data-ops-save-part="'+str(t)+'"]');expect(pg.locator('[data-ops-notice]')).to_contain_text('mezitím');check(pg.locator('[data-ops-field="procurement_note"]').input_value()=='Rozepsáno na mobilu','Browser conflict preserves unsaved procurement data and explicitly rejects stale version')
  pg.reload();pg.wait_for_load_state('networkidle');check(pg.locator('[data-ops-field="procurement_note"]').input_value()=='Rozepsáno na mobilu','Browser draft survives page reload after conflict')
  # A pending form is compared explicitly before rebasing and saving; fresh price does not change.
  act('[data-ops-save-part="'+str(t)+'"]')
  def fail_rebase(route):route.abort('failed')
  pg.route('**/operations_api.php?action=info*',fail_rebase);act('[data-ops-rebase]');expect(pg.locator('[data-ops-notice]')).to_contain_text('Spojení se přerušilo');check(pg.locator('[data-ops-field="procurement_note"]').input_value()=='Rozepsáno na mobilu','Browser failed conflict refresh keeps typed data and shows connection failure without JavaScript crash');pg.unroute('**/operations_api.php?action=info*',fail_rebase)
  act('[data-ops-rebase]');act('[data-ops-save-part="'+str(t)+'"]');expect(pg.locator('[data-ops-notice]')).to_contain_text('Uloženo');check(oi(j)['parts'][0]['procurement_note']=='Rozepsáno na mobilu','Browser explicit reload/review permits deliberate saving of preserved draft')
  check(pg.evaluate('document.documentElement.scrollWidth<=innerWidth'),'Browser M02 with occupancy and procurement fits 412px');pg.set_viewport_size({'width':360,'height':800});check(pg.evaluate('document.documentElement.scrollWidth<=innerWidth'),'Browser M02 also fits 360px without horizontal scroll');pg.screenshot(path=str(evidence/'m02-fronta-priprava-360.png'),full_page=True)
  # Calendar selected day still scrolls directly to the cars; queue remains available any day.
  goto('mechanic.php?view=calendar&month=2027-09&day=2027-09-11');expect(pg.locator('#a-day-list')).to_contain_text('září');check(pg.get_by_role('link',name='Fronta / Na dvoře →',exact=True).count()==1,'Browser calendar always links persistent queue, including days after intake');pg.screenshot(path=str(evidence/'kalendar-fronta.png'),full_page=True)
  goto('office.php?view=jobs&job='+str(j),owner);expect(owner.locator('#office-ops-panel')).to_contain_text('Hever 1');owner.screenshot(path=str(evidence/'kancelar-stejna-zakazka.png'),full_page=True)
  check(not errors,'Browser no JavaScript errors in mobile/office V2: '+str(errors));b.close()
