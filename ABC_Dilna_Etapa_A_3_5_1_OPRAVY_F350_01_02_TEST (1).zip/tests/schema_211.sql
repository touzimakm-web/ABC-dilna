-- ABC Dílna 2.1.0: kompletní NOVÁ instalace do PRÁZDNÉ databáze.
-- Není určeno k importu přes existující databázi předchozí aplikace.
CREATE TABLE users (
 id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(120) NOT NULL,
 email VARCHAR(190) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL,
 role VARCHAR(20) NOT NULL,
 permissions LONGTEXT NOT NULL,
 active TINYINT NOT NULL DEFAULT 1,
 session_version INT NOT NULL DEFAULT 1,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE crm_customers (
 id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 type VARCHAR(20) NOT NULL DEFAULT 'person',
 name VARCHAR(160) NOT NULL,
 phone VARCHAR(60) NOT NULL DEFAULT '',
 email VARCHAR(190) NOT NULL DEFAULT '',
 address VARCHAR(500) NOT NULL DEFAULT '',
 ico VARCHAR(20) NOT NULL DEFAULT '',
 note TEXT NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX customer_name_idx(name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE crm_vehicles (
 id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 customer_id INT NOT NULL,
 plate VARCHAR(30) NULL UNIQUE,
 vin VARCHAR(32) NULL UNIQUE,
 brand VARCHAR(80) NOT NULL DEFAULT '',
 model VARCHAR(160) NOT NULL DEFAULT '',
 mileage INT NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(customer_id) REFERENCES crm_customers(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE jobs (
 id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 customer_name VARCHAR(160) NOT NULL DEFAULT '',
 customer_phone VARCHAR(60) NOT NULL DEFAULT '',
 plate VARCHAR(30) NOT NULL DEFAULT '',
 vehicle VARCHAR(160) NOT NULL DEFAULT '',
 vin VARCHAR(32) NOT NULL DEFAULT '',
 mileage INT NULL,
 title VARCHAR(220) NOT NULL,
 assigned_to INT NULL,
 created_by INT NOT NULL,
 status VARCHAR(20) NOT NULL DEFAULT 'new',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 FOREIGN KEY(assigned_to) REFERENCES users(id),
 FOREIGN KEY(created_by) REFERENCES users(id),
 INDEX job_status_idx(status,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE crm_vehicle_jobs (
 job_id INT NOT NULL PRIMARY KEY,
 vehicle_id INT NOT NULL,
 FOREIGN KEY(job_id) REFERENCES jobs(id),
 FOREIGN KEY(vehicle_id) REFERENCES crm_vehicles(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE items (
 id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 job_id INT NOT NULL,
 kind VARCHAR(20) NOT NULL,
 description VARCHAR(220) NOT NULL,
 quantity DECIMAL(10,3) NOT NULL DEFAULT 1,
 unit_price DECIMAL(12,2) NOT NULL,
 unit_cost DECIMAL(12,2) NOT NULL DEFAULT 0,
 FOREIGN KEY(job_id) REFERENCES jobs(id),
 INDEX item_job_idx(job_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE abc_quick_catalog (
 id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 category VARCHAR(80) NOT NULL,
 description VARCHAR(220) NOT NULL,
 kind VARCHAR(20) NOT NULL,
 unit_price DECIMAL(12,2) NOT NULL,
 unit_cost DECIMAL(12,2) NOT NULL DEFAULT 0,
 active TINYINT NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE abc_quick_tasks (
 id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 job_id INT NOT NULL,
 category VARCHAR(80) NOT NULL,
 description VARCHAR(220) NOT NULL,
 kind VARCHAR(20) NOT NULL,
 quantity DECIMAL(10,3) NOT NULL DEFAULT 1,
 status VARCHAR(20) NOT NULL DEFAULT 'planned',
 item_id INT NULL UNIQUE,
 created_by INT NOT NULL,
 FOREIGN KEY(job_id) REFERENCES jobs(id),
 FOREIGN KEY(item_id) REFERENCES items(id),
 FOREIGN KEY(created_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE office_appointments (
 id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 start_at DATETIME NOT NULL,
 end_at DATETIME NOT NULL,
 source VARCHAR(20) NOT NULL DEFAULT 'staff',
 status VARCHAR(20) NOT NULL DEFAULT 'confirmed',
 customer_name VARCHAR(160) NOT NULL,
 customer_phone VARCHAR(60) NOT NULL DEFAULT '',
 customer_email VARCHAR(190) NOT NULL DEFAULT '',
 vehicle VARCHAR(160) NOT NULL DEFAULT '',
 plate VARCHAR(30) NOT NULL DEFAULT '',
 service VARCHAR(250) NOT NULL,
 note TEXT NULL,
 job_id INT NULL,
 created_by INT NOT NULL,
 mechanic_id INT NOT NULL,
 FOREIGN KEY(job_id) REFERENCES jobs(id),
 FOREIGN KEY(created_by) REFERENCES users(id),
 FOREIGN KEY(mechanic_id) REFERENCES users(id),
 INDEX appointment_slot_idx(mechanic_id,status,start_at,end_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE office_invoices (
 id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 job_id INT NOT NULL UNIQUE,
 invoice_no VARCHAR(40) NULL UNIQUE,
 status VARCHAR(20) NOT NULL DEFAULT 'issued',
 customer_name VARCHAR(160) NOT NULL,
 customer_address VARCHAR(500) NOT NULL DEFAULT '',
 customer_ico VARCHAR(20) NOT NULL DEFAULT '',
 customer_email VARCHAR(190) NOT NULL DEFAULT '',
 issued_on DATE NOT NULL,
 due_on DATE NOT NULL,
 total DECIMAL(12,2) NOT NULL,
 payment_method VARCHAR(20) NOT NULL DEFAULT 'transfer',
 lines_json LONGTEXT NOT NULL,
 supplier_json LONGTEXT NOT NULL,
 note TEXT NULL,
 created_by INT NOT NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(job_id) REFERENCES jobs(id),
 FOREIGN KEY(created_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE cash_handovers (
 id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 user_id INT NOT NULL,
 declared_amount DECIMAL(12,2) NOT NULL,
 status VARCHAR(20) NOT NULL DEFAULT 'pending',
 submitted_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 accepted_at DATETIME NULL,
 accepted_by INT NULL,
 FOREIGN KEY(user_id) REFERENCES users(id),
 FOREIGN KEY(accepted_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE payments (
 id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 job_id INT NOT NULL,
 user_id INT NOT NULL,
 amount DECIMAL(12,2) NOT NULL,
 method VARCHAR(20) NOT NULL,
 handover_id INT NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(job_id) REFERENCES jobs(id),
 FOREIGN KEY(user_id) REFERENCES users(id),
 FOREIGN KEY(handover_id) REFERENCES cash_handovers(id),
 INDEX payment_job_idx(job_id),
 INDEX payment_cash_idx(user_id,method,handover_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE notes (
 id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 job_id INT NOT NULL,
 user_id INT NOT NULL,
 kind VARCHAR(30) NOT NULL DEFAULT 'work',
 body TEXT NOT NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(job_id) REFERENCES jobs(id),
 FOREIGN KEY(user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE part_requests (
 id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 job_id INT NOT NULL,
 user_id INT NOT NULL,
 description VARCHAR(220) NOT NULL,
 quantity DECIMAL(10,3) NOT NULL DEFAULT 1,
 state VARCHAR(20) NOT NULL DEFAULT 'requested',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(job_id) REFERENCES jobs(id),
 FOREIGN KEY(user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE abc_job_estimates (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 job_id INT NOT NULL,
 created_by INT NOT NULL,
 lower_total DECIMAL(12,2) NOT NULL DEFAULT 0,
 upper_total DECIMAL(12,2) NOT NULL DEFAULT 0,
 lines_json LONGTEXT NOT NULL,
 note VARCHAR(500) NOT NULL DEFAULT '',
 origin VARCHAR(24) NOT NULL DEFAULT 'manual',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(job_id) REFERENCES jobs(id),
 FOREIGN KEY(created_by) REFERENCES users(id),
 INDEX abc_estimates_job_idx(job_id,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE events (
 id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 user_id INT NOT NULL,
 job_id INT NULL,
 action VARCHAR(60) NOT NULL,
 detail VARCHAR(500) NOT NULL DEFAULT '',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id),
 FOREIGN KEY(job_id) REFERENCES jobs(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE login_attempts (
 id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 email_hash CHAR(64) NOT NULL,
 ip_hash CHAR(64) NOT NULL,
 attempted_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX attempt_email_idx(email_hash,attempted_at),
 INDEX attempt_ip_idx(ip_hash,attempted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE schema_meta (version VARCHAR(30) PRIMARY KEY, installed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)
 ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
