"""A3-A6 acceptance, actual database, APIs, concurrency and Chromium."""
from runtime import Runtime,Client,ROOT
import json,secrets,concurrent.futures,os
checks=[]
def key():return secrets.token_hex(20)
def check(ok,label):
 if not ok:raise AssertionError(label)
 checks.append(label);print('OK '+label,flush=True)
def main():
 with Runtime() as r:
  o=r.owner
  def call(c,action,p=None,**params):return c.safe_api('phase_a_api.php',action,p,**params) if action=='tyres' else c.api('phase_a_api.php',action,p,**params)
  def info(j,c=o):
   s,d=c.api('mechanic_flow_api.php','info',id=j);assert s==200,d;return d
  def create(plate,c=o,**kw):
   p={'plate':plate,'vehicle':'Skoda Octavia','services':['Brzdy','Oleje a filtry','Pneuservis'],'request_key':key(),**kw};return c.api('mechanic_flow_api.php','create',p)
  def worker(n,rights):
   pw=secrets.token_hex(12);status,body=o.form('save_user',name=n,email=n+'@example.test',password=pw,permissions=rights,rights_version=2);assert status==200,(status,body[:300]);uid=int(r.sql("SELECT id FROM abc_test.users WHERE email='"+n+"@example.test'"));c=Client(r.url);assert c.login(n+'@example.test',pw)[0]==200;return uid,c,pw
  base=['create_jobs','edit_jobs','edit_lines','edit_identity','change_status','move_appointments','handover_billing']
  uid,w,wp=worker('Kozel',base);u2,w2,_=worker('Kolega',base);billid,biller,_=worker('Uctujici',['issue_invoices','collect_payments','receive_billing','print_receipts'])
  check(r.sql("SELECT COUNT(*) FROM abc_test.schema_meta WHERE version='3.3.0-a'")=='1','Complete A schema is installed without demo jobs')
  s,d=create('A300001',w);assert s==200,d;j=d['id'];check(r.sql('SELECT COUNT(*) FROM abc_test.office_appointments')=='0','No date creates today job and no time or resource occupancy')
  check(w.api('api.php','handover_summary')[0]==403 and w.api('api.php','add_payment',{'id':j,'amount':1,'method':'cash','request_key':key()})[0]==403,'No payment right means cash API is denied')
  denied,viewer,_=worker('PouzeCteni',[])
  s,d=create('A300003',viewer);check(s==403,'Individual intake permission is enforced server-side')
  check(info(j,w)['permissions']['edit'] and not info(j,w)['permissions']['collect'],'Working and cash permissions are independent')
  check(w2.api('mechanic_flow_api.php','info',id=j)[0]==403,'Uninvited colleague cannot open job')
  sh={'id':j,'revision':info(j)['job']['revision'],'target':u2,'request_key':key()};check(call(o,'share',sh)[0]==200,'Owner explicitly shares the same job')
  check(w2.api('mechanic_flow_api.php','info',id=j)[0]==200 and any(int(x['id'])==j for x in w2.api('api.php','list_jobs')[1]['jobs']),'Shared job appears without duplicate records')
  sh={'id':j,'revision':info(j)['job']['revision'],'target':denied,'request_key':key()};assert call(o,'share',sh)[0]==200
  check(viewer.api('mechanic_flow_api.php','add',{'id':j,'description':'Forbidden','kind':'labor','quantity':1,'unit':'hod','unit_price':'','request_key':key()})[0]==403,'Read access does not grant editing even through direct API')
  assert w.api('api.php','set_status',{'id':j,'status':'done','revision':info(j,w)['job']['revision'],'request_key':key()})[0]==200
  p={'id':j,'revision':info(j,w)['job']['revision'],'target':billid,'request_key':key()};check(call(w,'handover_billing',p)[0]==200 and call(w,'handover_billing',p)[0]==200,'Done repair can be handed to a real authorized worker idempotently')
  check(len(call(biller,'billing_queue')[1]['jobs'])==1 and info(j,biller)['job']['billing_state']=='queued','Recipient queue opens the same repair without inventing payment')
  check(r.sql('SELECT COUNT(*) FROM abc_test.payments')=='0','Billing handover creates no money')
  add={'id':j,'description':'Dalsi prace','kind':'labor','quantity':1,'unit':'hod','unit_price':'','request_key':key()};s,d=w.api('mechanic_flow_api.php','add',add);assert s==200,d
  check(info(j,w)['job']['status']=='work' and info(j,w)['job']['billing_state']=='unbilled','New unfinished work reopens repair and visibly recalls billing handover')
  # Finish and hand back to finance: authorized recipient keeps document access.
  line=d['line'];price={'id':j,'task_id':line['id'],'kind':'labor','description':line['description'],'quantity':1,'unit':'hod','unit_price':200,'revision':line['revision'],'request_key':key()};assert o.api('mechanic_flow_api.php','update_line',price)[0]==200
  line=next(t for t in info(j)['tasks'] if t['id']==line['id']);assert w.api('mechanic_api.php','quick_task_status',{'id':j,'task_id':line['id'],'revision':line['revision'],'status':'done','request_key':key()})[0]==200
  assert w.api('api.php','set_status',{'id':j,'revision':info(j,w)['job']['revision'],'status':'done','request_key':key()})[0]==200
  assert call(w,'handover_billing',{'id':j,'revision':info(j,w)['job']['revision'],'target':billid,'request_key':key()})[0]==200
  invoice={'job_id':j,'revision':info(j,biller)['job']['revision'],'customer_name':'Skutecny prijemce','customer_address':'Test 1','due_days':14,'request_key':key()};s,inv=biller.api('office_api.php','issue_invoice',invoice);check(s==200 and biller.api('office_api.php','issue_invoice',invoice)[0]==200,'Recipient issues one actual invoice without being owner or changing repair rights')
  check(biller.request('office_document.php?invoice='+str(inv['invoice_id']))[0]==200 and info(j,biller)['job']['billing_state']=='documented','Actual issuer keeps access after repair leaves billing queue')
  check(info(j,biller)['totals']['paid']==0,'Invoice from queue remains genuinely unpaid')
  # Technical records and exact vehicle reuse.
  v=info(j)['vehicle'];c=info(j)['customer'];p={'id':j,'vehicle':{'revision':v['revision'],'plate':v['plate'],'vin':'WVWZZZ1JZXW000009','brand':'Skoda','model':'Octavia','mileage':'151000','engine_code':'BKC','fuel':'nafta','engine_cc':'1896','power_kw':'77.0','year':'2005','stk_due':'2027-06-20'},'customer':{'revision':c['revision'],'name':'Pravidelny','phone':'700111222','email':''},'request_key':key()};check(w.api('mechanic_flow_api.php','update_identity',p)[0]==200,'Technical vehicle data and contact persist in shared CRM')
  check(call(w,'vehicles',q='WVWZZZ')[1]['vehicles'][0]['engine_code']=='BKC','Vehicle register search supports VIN and saved technical specification')
  s,d=create('A300001',w,vehicle_id=v['id'],vin='WVWZZZ1JZXW000009');assert s==200,d;check(r.sql('SELECT COUNT(*) FROM abc_test.crm_vehicles')=='1' and r.sql('SELECT COUNT(*) FROM abc_test.items WHERE job_id='+str(d['id']))=='0','Repeat intake reuses vehicle without copying charged work')
  # Configure, no hardcoded 2 cars/1 lift.
  settings=call(o,'settings')[1]['settings'];settings['car_capacity']=2;settings['hours']={};p={'settings':settings,'revision':settings['revision'],'request_key':key()};s,d=call(o,'settings',p);assert s==200,d
  check(call(o,'settings',p)[0]==200,'Lost settings response can be retried with original operation key')
  check(call(w,'settings',p)[0]==403,'Only workshop owner can change shared capacities')
  p={'name':'Hever 1','kind':'lift','capacity':1,'active':True,'request_key':key()};s,resource=call(o,'resource',p);assert s==200,resource;rid=resource['id']
  date='2027-02-15'
  def slot(plate,assignee,at='09:00',duration=60,resource=None,**kw):return create(plate,assigned_to=assignee,date=date,time=at,duration=duration,resource_id=resource,**kw)
  s,d=slot('CAL001',uid,resource=rid);assert s==200,d;first=d['id']
  check(slot('CAL002',u2,resource=rid)[0]==409,'Second simultaneous use of one lift is rejected')
  s,d=slot('CAL003',u2);assert s==200,d;second=d['id'];check(slot('CAL004',billid)[0]==409,'Third simultaneous car exceeds configured workshop capacity')
  check(slot('CAL005',billid,at='10:00')[0]==200,'Adjacent intervals are allowed without false overlap')
  before=call(o,'settings')[1];resource=next(x for x in before['resources'] if x['id']==rid);p={**resource,'capacity':2,'request_key':key()};check(call(o,'resource',p)[0]==200,'Lift capacity changes in database without source edits')
  s,d=slot('CAL006',uid,at='11:00',resource=rid);assert s==200,d;s,d=slot('CAL007',u2,at='11:00',resource=rid);check(s==200,'Two lifts now permit the formerly conflicting concurrent use')
  # Shorter lift interval than actual stay.
  s,d=slot('CAL008',uid,at='13:00',duration=120,resource=rid,resource_start=date+'T13:00',resource_end=date+'T13:30');assert s==200,d
  check(r.sql('SELECT resource_end FROM abc_test.office_appointments WHERE job_id='+str(d['id']))==date+' 13:30:00','Car stay does not imply continuous lift use')
  # Unknown end remains NULL and flagged, never false free.
  s,d=slot('CAL009',u2,at='16:00',duration='');assert s==200,d;unknown=d['id']
  check(r.sql('SELECT end_at FROM abc_test.office_appointments WHERE job_id='+str(unknown))=='NULL','Unknown duration is SQL NULL rather than invented 60 minutes')
  s,cal=call(w,'calendar',month='2027-02');check(s==200 and cal['days'][date]['state']=='unknown','Unknown repair length prevents a false free-capacity claim')
  check(all(int(a['mechanic_id'])==uid or int(a['job_id'])==j for a in cal['appointments']),'Personal calendar hides colleagues job details while occupancy is aggregated')
  check(slot('CAL010',u2,at='17:00',duration=30)[0]==409,'Unknown length collision asks for clarification instead of assuming availability')
  check(slot('CAL011',billid,at='18:00',duration='',resource=rid)[0]==409,'Lift cannot be booked with an invented unknown interval')
  check(call(w,'calendar',month='2027-03')[1]['days']['2027-03-01']['state']=='unknown','Unresolved duration remains uncertain across days instead of inventing midnight release')
  # Mechanic moves same done job before document.
  s,d=w.api('api.php','set_status',{'id':first,'status':'done','revision':info(first,w)['job']['revision'],'request_key':key()});assert s==200,d
  p={'id':first,'revision':info(first,w)['job']['revision'],'date':'2027-02-16','time':'09:00','duration':60,'request_key':key()};check(call(w,'appointment',p)[0]==200 and call(w,'appointment',p)[0]==200,'Assigned mechanic can move Hotovo before billing and safely retry')
  check(call(w,'appointment',{**p,'time':'10:00','request_key':key()})[0]==409,'Stale schedule update cannot overwrite a newer schedule')
  p={'id':first,'revision':info(first,w)['job']['revision'],'cancel':True,'request_key':key()};check(call(w,'appointment',p)[0]==200 and r.sql('SELECT COUNT(*) FROM abc_test.jobs WHERE id='+str(first))=='1','Cancelling reservation preserves the actual repair')
  # Real simultaneous calendar writes.
  def reserve(i):
   c=Client(r.url);c.login('owner@example.test',r.ownerpass);return create('RACE'+str(i),c,assigned_to=uid,date='2027-03-01',time='10:00',duration=60)[0]
  with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:statuses=list(ex.map(reserve,[1,2]))
  check(sorted(statuses)==[200,409],'Concurrent calendar reservations serialize and detect the actual collision')
  assert call(w2,'appointment',{'id':unknown,'revision':info(unknown,w2)['job']['revision'],'date':date,'time':'16:00','duration':60,'request_key':key()})[0]==200
  # Independent resource collision, working hours and safe reductions.
  s,race_resource=call(o,'resource',{'name':'Samostatny hever','kind':'lift','capacity':1,'active':True,'request_key':key()});assert s==200
  def reserve_resource(pair):
   c=Client(r.url);c.login('owner@example.test',r.ownerpass);i,who=pair;return create('LIFT'+str(i),c,assigned_to=who,date='2027-03-03',time='10:00',duration=60,resource_id=race_resource['id'])[0]
  with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:statuses=list(ex.map(reserve_resource,[(1,uid),(2,u2)]))
  check(sorted(statuses)==[200,409],'Two concurrent different mechanics cannot take the same last lift')
  settings=call(o,'settings')[1]['settings'];low={**settings,'car_capacity':1};check(call(o,'settings',{'settings':low,'revision':settings['revision'],'request_key':key()})[0]==409,'Capacity reduction cannot silently invalidate existing future bookings')
  settings['hours']={'1':['09:00','17:00']};assert call(o,'settings',{'settings':settings,'revision':settings['revision'],'request_key':key()})[0]==200
  check(create('HOURS01',assigned_to=uid,date='2027-03-08',time='18:00',duration=30)[0]==409,'Configured workshop hours are enforced during real intake')
  check(create('HOURS02',assigned_to=uid,date='2027-03-09',time='10:00',duration=30)[0]==409,'Unconfigured weekday is closed once weekly hours are specified')
  settings=call(o,'settings')[1]['settings'];settings['hours']={};assert call(o,'settings',{'settings':settings,'revision':settings['revision'],'request_key':key()})[0]==200
  # Repeat intake, migrations and private API authority.
  scheduled={'assigned_to':uid,'date':'2027-04-01','time':'10:00','duration':60,'request_key':key()};s,replay=create('REPEAT01',**scheduled);assert s==200
  check(create('REPEAT01',**scheduled)[1]['id']==replay['id'],'Scheduled intake replay returns its original job instead of a false calendar collision')
  check(o.request('phase_a_api.php?action=settings',{'revision':1,'settings':{}},api=True,token=False)[0]==403,'New settings mutations retain actual CSRF validation')
  # Real configured tyre rows, no supplier/stock illusion.
  for desc,kind,price in [('Prezuti za kolo','labor',250),('Ventilek','part',30)]:assert o.form('save_catalog',description=desc,category='Pneuservis',kind=kind,unit='ks',unit_price=price,unit_cost=10,active=1)[0]==200
  cat=[int(x) for x in r.sql('SELECT id FROM abc_test.abc_quick_catalog ORDER BY id').splitlines()];settings=call(o,'settings')[1]['settings'];settings['tyres']=[{'operation':'complete','vehicle':'van','diameter':16,'balance':True,'runflat':False,'catalog_id':cat[0],'valve_catalog_id':cat[1]}];assert call(o,'settings',{'settings':settings,'revision':settings['revision'],'request_key':key()})[0]==200
  s,d=create('TYRE001',w);assert s==200;ty=d['id'];p={'id':ty,'revision':info(ty,w)['job']['revision'],'operation':'complete','vehicle':'van','diameter':16,'balance':True,'runflat':False,'valves':True,'count':4,'request_key':key()};check(call(w,'tyres',p)[0]==200 and call(w,'tyres',p)[0]==200,'Pneuservis uses exact workshop variant and repeated click returns same operation')
  ti=info(ty,w);check(ti['totals']['estimated_total']==1120 and ti['totals']['total']==0 and len([t for t in ti['tasks'] if t['entry_type']=='work'])==2,'Four wheels and valves create correct planned rows, no automatic use or payment')
  p['request_key']=key();p['revision']=ti['job']['revision'];check(call(w,'tyres',p)[0]==409,'Repeated tyre bundle cannot silently duplicate billed services')
  p['diameter']=17;check(call(w,'tyres',p)[0]==409,'Unconfigured tyre variant does not invent a price')
  # Optional surcharges use configured items; mutually exclusive alternatives fail atomically.
  for name in ['TPMS','Nizky profil']:assert o.form('save_catalog',description=name,category='Pneuservis',kind='labor',unit='ks',unit_price=50,unit_cost=0,active=1)[0]==200
  ids=[int(x) for x in r.sql('SELECT id FROM abc_test.abc_quick_catalog ORDER BY id DESC LIMIT 2').splitlines()];settings=call(o,'settings')[1]['settings'];settings['tyre_extras']=[{'code':'tpms','label':'TPMS','catalog_id':ids[0],'exclusive_group':'alternativa','per_wheel':True},{'code':'profil','label':'Nizky profil','catalog_id':ids[1],'exclusive_group':'alternativa','per_wheel':False}];assert call(o,'settings',{'settings':settings,'revision':settings['revision'],'request_key':key()})[0]==200
  s,d=create('EXTRA001',w);assert s==200;ej=d['id'];p={**p,'id':ej,'diameter':16,'revision':info(ej,w)['job']['revision'],'extras':['tpms'],'request_key':key()};check(call(w,'tyres',p)[0]==200 and info(ej,w)['totals']['estimated_total']==1320,'Configured optional surcharge is priced per wheel without automatic completion')
  s,d=create('EXTRA002',w);assert s==200;ej=d['id'];p={**p,'id':ej,'revision':info(ej,w)['job']['revision'],'extras':['tpms','profil'],'request_key':key()};check(call(w,'tyres',p)[0]==409 and r.sql('SELECT COUNT(*) FROM abc_test.items WHERE job_id='+str(ej))=='0','Incompatible surcharge group is rejected atomically without duplicate work')
  s,late=create('',w,customer_name='Udaje doplnim',vehicle='');assert s==200;lateid=late['id'];lv=info(lateid,w)['vehicle'];check(lv is not None and not lv['plate'] and not lv['vin'],'Name-only intake keeps a linked blank vehicle ready for later facts without inventing a plate')
  # Preserve historical prices, identifiers and newly denied rights through repeat migration.
  check(viewer.api('mechanic_flow_api.php','add',add)[0]==403,'Explicitly denied rights stay denied after normal refresh')
  o.request('upgrade.php');s,body=o.request('upgrade.php',{'csrf':o.csrf,'backup_confirmed':'1'});check(s==200 and viewer.api('mechanic_flow_api.php','add',add)[0]==403 and info(j)['vehicle']['engine_code']=='BKC','Repeat full migration preserves explicitly denied rights and saved technical data')
  if os.environ.get('ABC_TEST_BROWSER')=='1':
   from phase_a_browser import run_browser
   run_browser(r,check,uid,wp,j,first)
  r.weblog.flush();log=(r.tmp/'php.log').read_text();errors=[line for line in log.splitlines() if any(t in line for t in ['PHP Warning','PHP Fatal','PHP Parse','PHP Deprecated'])];
  if errors:(ROOT/'tests/evidence/a6-php-failure.txt').write_text(log);print('\n'.join(line for line in log.splitlines() if 'ABC Dílna:' in line or 'PHP Warning' in line));check(False,'No PHP runtime errors')
  check(not errors,'No PHP warnings fatal errors or deprecations during complete A acceptance')
  out=ROOT/'tests/evidence/a6';out.mkdir(parents=True,exist_ok=True);(out/('results-wedos.json' if r.prefix else 'results.json')).write_text(json.dumps({'milestone':'A3-A6','passed':len(checks),'checks':checks,'browser':os.environ.get('ABC_TEST_BROWSER')=='1','wedos_rewrite':bool(r.prefix)},ensure_ascii=False,indent=2))
 print(json.dumps({'passed':len(checks)}))
if __name__=='__main__':main()
