"""Current browser acceptance uses the retained M02 card; old selectors are archived."""
from a12_browser import run_browser
