"""18 acceptance scenarios: actual isolated MariaDB/PHP, migration and concurrency."""
from runtime import Runtime,Client,ROOT,PHP,INI
from datetime import datetime
from zoneinfo import ZoneInfo
import runtime,os,json,secrets,concurrent.futures,subprocess,tempfile,zipfile
checks=[]
def key():return secrets.token_hex(20)
def check(ok,label):
 if not ok:raise AssertionError(label)
 checks.append(label);print('OK '+label,flush=True)
def migration():
 old=runtime.ROOT
 with tempfile.TemporaryDirectory(prefix='abc-331-baseline-') as folder:
  with zipfile.ZipFile(ROOT/'tests/fixtures/331_source.zip') as z:z.extractall(folder)
  runtime.ROOT=__import__('pathlib').Path(folder)
  try:
   with Runtime() as r:
    o=r.owner;s,d=o.api('mechanic_flow_api.php','create',{'plate':'LEGACYV2','services':['Brzdy'],'request_key':key()});assert s==200,d;j=d['id']
    s,d=o.api('mechanic_flow_api.php','add',{'id':j,'kind':'part','description':'Původní díl','unit_price':'45','request_key':key()});assert s==200,d
    before=r.sql('SELECT id,description,quantity,unit,status,item_id FROM abc_test.abc_quick_tasks');money=r.sql('SELECT * FROM abc_test.items');r.sql("INSERT INTO abc_test.abc_resources(name,kind,capacity) VALUES ('Původní hever','lift',1)")
    script=r.tmp/'upgrade-current.php';script.write_text("<?php require "+repr(str(old/'app/bootstrap.php'))+"; require "+repr(str(old/'app/migrations.php'))+";abc_migrate_a12(db());")
    cmd=[PHP]+(['-c',INI] if INI else [])+['-d','session.save_path='+str(r.tmp/'sessions'),str(script)]
    for _ in range(2):
     p=subprocess.run(cmd,env=r.env,capture_output=True,text=True);assert p.returncode==0 and not p.stdout,p.stderr+p.stdout
    check(r.sql('SELECT location_state,received_at FROM abc_test.jobs WHERE id='+str(j))=='unknown\tNULL' and r.sql('SELECT COUNT(*) FROM abc_test.abc_job_presence')=='0','Migration 3.3.1: old location stays unknown, no invented physical presence')
    check(r.sql('SELECT id,description,quantity,unit,status,item_id FROM abc_test.abc_quick_tasks')==before and r.sql('SELECT * FROM abc_test.items')==money,'Migration 3.3.1: repeated additive upgrade preserves IDs, original tasks and prices')
    check(r.sql('SELECT procurement_stage FROM abc_test.abc_quick_tasks WHERE kind=\'part\'')=='unknown','Migration 3.3.1: old parts are not falsely ordered, received or installed')
  finally:runtime.ROOT=old

def main():
 migration()
 with Runtime() as r:
  raw_sql=r.sql;offset=datetime.now(ZoneInfo('Europe/Prague')).strftime('%z');offset=offset[:3]+':'+offset[3:];r.sql=lambda statement:raw_sql("SET time_zone='"+offset+"';"+statement)
  o=r.owner
  def call(file,action,p=None,c=o,expected=200,**q):
   if p is not None:p={'request_key':key(),**p}
   s,d=c.api(file,action,p,**q);assert s==expected,(file,action,s,d);return d
  def info(j,c=o):return call('operations_api.php','info',c=c,id=j)['operations']
  def card(j,c=o):return call('mechanic_flow_api.php','info',c=c,id=j)
  def job(plate,c=o,**p):return call('mechanic_flow_api.php','create',{'plate':plate,'services':['Brzdy'],**p},c)['id']
  def op(j,a,**p):return call('operations_api.php',a,{'id':j,'revision':info(j)['revision'],**p})
  def plan(j,**p):return call('phase_a_api.php','appointment',{'id':j,'revision':info(j)['revision'],**p})
  def add(j,kind,name,quantity=1,price=100):return call('mechanic_flow_api.php','add',{'id':j,'kind':kind,'description':name,'quantity':quantity,'unit':'ks' if kind=='part' else 'hod','unit_price':price})['task_id']
  def part(j,t,a,**p):return op(j,a,task_id=t,line_revision=next(x['revision'] for x in info(j)['parts'] if x['id']==t),**p)
  def worker(n,perms=None):
   pw=key();assert o.form('save_user',name='Mechanik '+n,email=n+'@v2.test',password=pw,permissions=perms or ['price_jobs'],**({'rights_version':2} if perms is not None else {}))[0]==200
   c=Client(r.url);assert c.login(n+'@v2.test',pw)[0]==200;uid=int(r.sql("SELECT id FROM abc_test.users WHERE email='"+n+"@v2.test'"));return c,uid,pw
  w,wid,wp=worker('prvni');w2,wid2,wp2=worker('druhy')
  sett=call('phase_a_api.php','settings')['settings'];sett['car_capacity']=2;call('phase_a_api.php','settings',{'settings':sett,'revision':sett['revision']})
  lift=call('phase_a_api.php','resource',{'name':'Hever 1','kind':'lift','capacity':1})['id'];bay=call('phase_a_api.php','resource',{'name':'Stání 1','kind':'bay','capacity':1})['id']
  a=job('V2YARD01');r.sql('UPDATE abc_test.jobs SET created_at=DATE_SUB(NOW(),INTERVAL 1 DAY),received_at=DATE_SUB(NOW(),INTERVAL 1 DAY) WHERE id='+str(a))
  queue=call('operations_api.php','queue');check(any(x['id']==a for x in queue['jobs']) and r.sql('SELECT COUNT(*) FROM abc_test.office_appointments')=='0','01: intake without time remains in permanent queue next day, no invented booking')
  b=job('V2DAYONLY',date='2027-09-01',time='',received=True);check(info(b)['location']=='yard' and not info(b)['appointment'] and '2027-09-01' not in call('phase_a_api.php','calendar',month='2027-09')['days'],'02: selected day without hour is work list only, yard can have a future day')
  for i in range(8):job('V2QUEUE'+str(i))
  check(call('operations_api.php','queue')['total']==10 and r.sql('SELECT COUNT(*) FROM abc_test.office_appointments')=='0','03: ten yard cars do not consume two inside spaces, lift or mechanic intervals')
  task=add(a,'labor','Kontrola před opravou',price=350);p1=add(a,'part','Konkrétní filtr ABC',2,200);p2=add(a,'part','Těsnění XYZ',1,25);before=card(a)['tasks'];created=r.sql('SELECT created_at FROM abc_test.jobs WHERE id='+str(a));op(a,'take_inside',resource_id=lift)
  check(info(a)['presence']['resource_id']==lift and card(a)['tasks']==before and r.sql('SELECT created_at FROM abc_test.jobs WHERE id='+str(a))==created,'04: admission NOW keeps original job ID, receipt, tasks, quantities and prices')
  op(a,'wait_parts',release_choice='keep');r.sql("UPDATE abc_test.abc_job_presence SET started_at=DATE_SUB(NOW(),INTERVAL 2 DAY),expected_end=DATE_SUB(NOW(),INTERVAL 1 DAY) WHERE job_id="+str(a)+' AND ended_at IS NULL')
  call('operations_api.php','take_inside',{'id':b,'revision':info(b)['revision'],'resource_id':lift},expected=409)
  check(info(a)['presence']['ended_at'] is None and info(a)['status']=='parts','05: explicit keep on lift survives midnight and expired estimate, blocks second admission')
  c=job('V2BAY',w);op(c,'take_inside',resource_id=bay);op(c,'wait_parts',release_choice='keep');call('operations_api.php','take_inside',{'id':b,'revision':info(b)['revision'],'resource_id':bay},expected=409)
  check(info(c)['presence']['resource_kind']=='bay','06: ordinary bay has the same physical hold protection as a lift')
  op(a,'wait_parts',release_choice='yard');op(b,'take_inside',resource_id=lift);check(info(a)['location']=='yard' and info(a)['history'][0]['ended_at'] is not None and info(b)['presence']['resource_id']==lift,'07: confirmed yard move closes exact physical interval and releases lift for another car')
  op(c,'move_yard',move_confirmed=True);op(b,'move_inside',resource_id=bay,move_confirmed=True);op(a,'take_inside',resource_id=lift)
  call('operations_api.php','move_inside',{'id':a,'revision':info(a)['revision'],'resource_id':bay,'move_confirmed':True},expected=409)
  cal=call('phase_a_api.php','calendar');today=r.sql('SELECT CURRENT_DATE()');check(cal['days'][today]['peak']==2 and info(b)['presence']['resource_id']==bay and info(a)['presence']['resource_id']==lift,'08: lift to bay transfers one car, keeps capacity at two, occupied target rejected atomically')
  before=info(a);call('operations_api.php','wait_parts',{'id':a,'revision':before['revision']},expected=409);check(info(a)['revision']==before['revision'] and info(a)['status']==before['status'] and info(a)['presence']==before['presence'],'09: missing/cancelled release decision makes no partial status or occupancy change')
  out=job('V2OUT',w2);ot=add(out,'labor','Oprava na dvoře',price=200);om=add(out,'part','Materiál na dvoře',price=30);op(out,'start_outside');check(info(out)['presence']['mode']=='outside_work' and info(out)['presence']['resource_id'] is None and len(card(out)['tasks'])==3,'10: explicit outside start and real M02 work/material function with both inside spaces occupied')
  plan(out,date='2027-09-05',time='09:00',duration=60,work_mode='outside',mechanic_id=wid2)
  other=job('V2OUT2',w2);call('phase_a_api.php','appointment',{'id':other,'revision':info(other)['revision'],'date':'2027-09-05','time':'09:30','duration':60,'work_mode':'outside'},expected=409)
  check(call('phase_a_api.php','calendar',month='2027-09')['days']['2027-09-05']['peak']==2,'11: planned outside work blocks only mechanic; yard assignments do not reserve his day')
  for t,n in [(p1,2),(p2,1)]:part(a,t,'prepare_part',stage='ordered',ordered_quantity=n,expected_on='2027-09-10',required_for_start=True,supplier_name='Ruční dodavatel',order_reference='OBJ-ABC')
  part(a,p1,'receive_part',quantity=1,source='delivery');check(info(a)['readiness']['state']=='partial' and info(a)['readiness']['ready_items']==0 and card(a)['totals']['total']==0,'12a: partial quantity does not mark whole item/repair ready and bills nothing')
  part(a,p1,'receive_part',quantity=1,source='delivery');check(info(a)['readiness']['state']=='partial' and info(a)['readiness']['ready_items']==1 and all(t['status']=='planned' for t in card(a)['tasks']),'12b: one of two ordered parts received never confirms the other or marks installed')
  call('mechanic_flow_api.php','update_line',{'id':a,'task_id':p1,'revision':next(t['revision'] for t in card(a)['tasks'] if t['id']==p1),'description':'Filtr','unit':'l','quantity':2},expected=409)
  op(b,'move_yard',move_confirmed=True);op(a,'move_yard',move_confirmed=True)
  plan(a,date='2027-09-11',time='10:00',duration=60,resource_id=lift,mechanic_id=wid)
  check(info(a)['location']=='yard' and info(a)['readiness']['state']=='partial' and info(a)['appointment']['mechanic_id']==wid and info(a)['presence'] is None,'13: ETA permits future plan and assignment while uncertainty and yard location remain explicit')
  part(a,p2,'receive_part',quantity=1,source='delivery');prices=card(a)['tasks'];op(a,'take_inside',resource_id=lift,expected_end=r.sql("SELECT DATE_FORMAT(DATE_ADD(NOW(),INTERVAL 30 MINUTE),'%Y-%m-%dT%H:%i')"))
  check(info(a)['readiness']['state']=='ready' and card(a)['tasks']==prices and len(info(a)['history'])==3,'14: prepared parts survive real admission with all entered prices; arrival alone had not started repair')
  op(a,'move_yard',move_confirmed=True);payload={'id':a,'revision':info(a)['revision'],'resource_id':lift,'request_key':key(),'expected_end':r.sql("SELECT DATE_FORMAT(DATE_ADD(NOW(),INTERVAL 30 MINUTE),'%Y-%m-%dT%H:%i')")}
  call('operations_api.php','take_inside',payload);call('operations_api.php','take_inside',payload);check(len(info(a)['history'])==4 and sum(x['ended_at'] is None for x in info(a)['history'])==1,'15: return creates next historical interval of same job; exact retry creates no duplicate')
  future=job('V2FOLLOW',w2);dt=r.sql("SELECT DATE_FORMAT(DATE_ADD(NOW(),INTERVAL 2 HOUR),'%Y-%m-%d %H:%i')");plan(future,date=dt[:10],time=dt[11:],duration=60,resource_id=lift)
  r.sql('UPDATE abc_test.abc_job_presence SET expected_end=DATE_SUB(NOW(),INTERVAL 5 MINUTE) WHERE job_id='+str(a)+' AND ended_at IS NULL')
  conf=call('phase_a_api.php','calendar')['conflicts'];check(any(x['holder_job_id']==a and x['booking_job_id']==future and x['severity']=='conflict' for x in conf) and info(future)['appointment'] is not None and info(a)['presence']['ended_at'] is None,'16: overrun retains future reservation, exposes conflict and keeps real lift hold')
  op(a,'update_expected',expected_end=r.sql("SELECT DATE_FORMAT(DATE_ADD(NOW(),INTERVAL 3 HOUR),'%Y-%m-%dT%H:%i')"))
  check(info(a)['presence']['ended_at'] is None and info(a)['presence']['expected_end'] is not None and any(c['severity']=='conflict' for c in info(a)['conflicts']),'Boundary: editing expected release changes forecast only, keeps physical hold and visible following conflict')
  # Test setup: clear only plans created in this disposable DB, through their existing API.
  for jj in [a,future,out]:plan(jj,cancel=True)
  op(a,'move_yard',move_confirmed=True);x=job('V2RACE1',w);y=job('V2RACE2',w2)
  def race(c,j):return c.api('operations_api.php','take_inside',{'id':j,'revision':info(j)['revision'],'resource_id':lift,'request_key':key()})
  with concurrent.futures.ThreadPoolExecutor(2) as pool:results=list(pool.map(lambda cj:race(*cj),[(w,x),(w2,y)]))
  check(sorted(x[0] for x in results)==[200,409] and r.sql('SELECT COUNT(*) FROM abc_test.abc_job_presence WHERE resource_id='+str(lift)+' AND ended_at IS NULL')=='1','17a: two simultaneous HTTP workers contend for last lift; exactly one succeeds')
  winner=x if results[0][0]==200 else y;stale=info(winner)['revision'];op(winner,'wait_parts',release_choice='keep');call('operations_api.php','move_yard',{'id':winner,'revision':stale,'move_confirmed':True},expected=409);check(info(winner)['presence'] is not None,'17b: stale office/mechanic move cannot silently overwrite a newer operation')
  limited,lid,lp=worker('omezena',['create_jobs','edit_jobs','prepare_jobs']);pj=job('V2PREP');op(pj,'assign_preparation',target=lid)
  check(call('operations_api.php','info',c=limited,id=pj)['operations']['preparation_assigned_to']==lid and info(pj)['assigned_to']==1,'18a: preparation responsibility grants job access without changing mechanic or blocking time')
  call('operations_api.php','take_inside',{'id':pj,'revision':info(pj)['revision'],'resource_id':bay},c=limited,expected=403)
  call('operations_api.php','info',c=limited,id=a,expected=403)
  check(o.request('operations_api.php?action=move_yard',{'id':a},api=True,token=False)[0]==403,'18b: individual permissions, job scope and CSRF protect all physical actions')
  # immutable document, actual outside work and independent operational departure
  for tid in [ot,om]:
   t=next(t for t in card(out)['tasks'] if t['id']==tid);call('mechanic_api.php','quick_task_status',{'id':out,'task_id':tid,'revision':t['revision'],'status':'done'})
  call('api.php','set_status',{'id':out,'revision':info(out)['revision'],'status':'done'})
  inv=call('office_api.php','issue_invoice',{'job_id':out,'revision':info(out)['revision'],'customer_name':'Zákazník venku','customer_address':'Test','due_days':14})['invoice_id'];snapshot=r.sql('SELECT * FROM abc_test.office_invoices WHERE id='+str(inv));op(out,'depart',move_confirmed=True)
  check(r.sql('SELECT * FROM abc_test.office_invoices WHERE id='+str(inv))==snapshot and card(out)['totals']['due']==230 and card(out)['totals']['paid']==0,'18c: operational departure after invoice preserves immutable document, due amount and payments')
  # Boundary cases around existing M02 and live vehicle history.
  call('api.php','set_status',{'id':winner,'revision':info(winner)['revision'],'status':'done'})
  check(info(winner)['presence'] is not None,'Boundary: Hotovo never releases an actual resource')
  add(winner,'labor','Dodatečná nedokončená práce',price=75)
  check(info(winner)['status']=='work' and info(winner)['presence'] is not None,'Boundary: new unfinished labor reopens completed unbilled job without rewriting physical interval')
  call('operations_api.php','start_outside',{'id':winner,'revision':info(winner)['revision']},expected=400)
  op(winner,'start_outside',move_confirmed=True)
  check(info(winner)['presence']['mode']=='outside_work' and info(winner)['history'][1]['ended_at'] is not None,'Boundary: inside to outside requires explicit movement confirmation and closes previous resource')
  clone=job('V2RACE1' if winner==x else 'V2RACE2');call('operations_api.php','take_inside',{'id':clone,'revision':info(clone)['revision'],'resource_id':lift},expected=409)
  check(info(clone)['presence'] is None,'Boundary: same CRM vehicle cannot have two active physical jobs even at different resources')
  tt=add(pj,'part','Kontrolovaný díl',2,50);t=info(pj)['parts'][0];receipt={'id':pj,'revision':info(pj)['revision'],'task_id':tt,'line_revision':t['revision'],'quantity':1,'source':'delivery','request_key':key()}
  call('operations_api.php','receive_part',receipt);call('operations_api.php','receive_part',receipt)
  check(float(info(pj)['parts'][0]['received_quantity'])==1 and len(info(pj)['receipts'])==1,'Boundary: replayed real receipt is added exactly once and remains only partially prepared')
  op(clone,'wait_parts')
  check(info(clone)['status']=='parts' and info(clone)['presence'] is None,'Boundary: a yard car can wait for parts without asking about nonexistent interior occupancy')
  for i in range(52):job('V2PAGE'+str(i))
  first=call('operations_api.php','queue');second=call('operations_api.php','queue',page=2)
  check(first['total']>50 and len(first['jobs'])==50 and bool(second['jobs']) and not ({x['id'] for x in first['jobs']}&{x['id'] for x in second['jobs']}),'Boundary: queue has pagination beyond ten cars and fifty displayed rows, no capacity limit')
  if os.environ.get('ABC_TEST_BROWSER')=='1':
   from operations_v2_browser import run_browser
   run_browser(r,check,wid,wp,lift,bay)
  log=(r.tmp/'php.log').read_text();errs=[l for l in log.splitlines() if any(tag in l for tag in ['PHP Warning','PHP Fatal','PHP Parse','PHP Deprecated'])];check(not errs,'No PHP warnings/fatal errors in V2 acceptance: '+str(errs[:2]))
  target=ROOT/'tests/evidence/340';target.mkdir(parents=True,exist_ok=True);(target/('results-wedos.json' if r.prefix else 'results.json')).write_text(json.dumps({'version':'3.4.0-a-v2','passed':len(checks),'browser':os.environ.get('ABC_TEST_BROWSER')=='1','checks':checks},ensure_ascii=False,indent=2))
 print(json.dumps({'passed':len(checks)}))
if __name__=='__main__':main()
