"""Focused remaining regressions: estimate separation and live permissions/session revocation."""
from runtime import Runtime,Client,ROOT
import secrets,json
checks=[]
def check(v,label):
 if not v:raise AssertionError(label)
 checks.append(label);print('OK '+label,flush=True)
def run():
 with Runtime() as r:
  o=r.owner
  own={'plate':'8ZZ0001','services':['Pneuservis','Brzdy'],'request_key':secrets.token_hex(20)}
  status,d=o.safe_api('mechanic_flow_api.php','create',own);check(status==200,'Owner can create requests for estimate')
  jid=d['id'];info=o.safe_api('mechanic_estimate_api.php','info',id=jid)[1];check(len(info['tasks'])==2 and not info['ai_available'],'Before actual work estimate can include requests; AI truthfully disabled')
  rows=[{'task_id':t['id'],'min_price':'100','max_price':'200'} for t in info['tasks']]
  status,est=o.safe_api('mechanic_estimate_api.php','save',{'id':jid,'lines':rows,'note':'Lidsky zkontrolovaný odhad','origin':'manual'});check(status==200,'Manual human-reviewed estimate persists independently')
  check(r.sql('SELECT COUNT(*) FROM abc_test.items')=='0' and r.sql('SELECT COUNT(*) FROM abc_test.payments')=='0' and r.sql('SELECT COUNT(*) FROM abc_test.office_invoices')=='0','Estimate creates no bill item, invoice or payment')
  o.safe_api('mechanic_flow_api.php','add',{'id':jid,'description':'Konkrétní přezutí','category':'Pneuservis','kind':'labor','quantity':1,'unit_price':'900','request_key':secrets.token_hex(20)})
  after=o.safe_api('mechanic_estimate_api.php','info',id=jid)[1];check(len(after['tasks'])==1 and after['tasks'][0]['description']=='Konkrétní přezutí','Estimate uses actual work when present and never adds requested categories again')
  password=secrets.token_hex(12);o.form('save_user',name='Omezený mechanik',email='limited@example.test',password=password,permissions=[])
  uid=int(r.sql("SELECT id FROM abc_test.users WHERE email='limited@example.test'"));w=Client(r.url);w.login('limited@example.test',password)
  status,j=w.safe_api('mechanic_flow_api.php','create',{'plate':'8ZZ0002','services':['Brzdy'],'request_key':secrets.token_hex(20)});check(status==200,'Mechanic without financial authority can create own intake')
  status,_=w.safe_api('mechanic_flow_api.php','add',{'id':j['id'],'description':'Vlastní práce','category':'Brzdy','kind':'labor','quantity':1,'unit_price':'500','request_key':secrets.token_hex(20)});check(status==403,'Mechanic cannot inject manual price without permission')
  o.form('update_user',id=uid,active='1',password='',permissions=['price_jobs'])
  check(w.safe_api('mechanic_flow_api.php','info',id=j['id'])[1]['permissions']['price'],'Granted authority takes effect in existing login')
  changed=secrets.token_hex(12);o.form('update_user',id=uid,active='1',password=changed,permissions=['price_jobs'])
  check(w.safe_api('api.php','list_jobs')[0]==401,'Password reset revokes existing authenticated session')
  check(w.login('limited@example.test',changed)[0]==200,'Mechanic can log in with changed password')
  o.form('update_user',id=uid,password='',permissions=[])
  check(w.safe_api('api.php','list_jobs')[0]==401,'Account deactivation is enforced immediately')
 (ROOT/'tests/evidence/security-estimates.json').write_text(json.dumps({'passed':len(checks),'checks':checks},ensure_ascii=False,indent=2))
if __name__=='__main__':run()
