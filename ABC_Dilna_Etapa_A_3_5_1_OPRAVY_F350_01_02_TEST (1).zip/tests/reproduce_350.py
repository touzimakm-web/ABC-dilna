"""Reproduce original F350 defects using frozen source and a real isolated database/browser."""
import json,tempfile,zipfile
import runtime
from pathlib import Path
from playwright.sync_api import sync_playwright
current=runtime.ROOT
with tempfile.TemporaryDirectory(prefix='abc350-reproduce-') as folder:
 with zipfile.ZipFile(current/'tests/fixtures/350_source.zip') as z:z.extractall(folder)
 runtime.ROOT=Path(folder)
 try:
  with runtime.Runtime() as r:
   o=r.owner
   def call(f,a,p=None,**kw):
    st,d=o.safe_api(f,a,p,**kw);assert st==200,(st,d);return d
   rate=call('catalog_api.php','save',{'description':'Sazba F350','category':'Oleje a filtry','kind':'labor','unit':'hod','unit_price':950,'active':1})['id']
   part=call('catalog_api.php','save',{'description':'Filtr F350','category':'Oleje a filtry','kind':'part','unit':'ks','unit_price':'','active':1})['id']
   for code,cid in [('oil-change',rate),('oil-filter',part)]:
    s=call('phase_a_api.php','settings')['settings'];call('catalog_api.php','bind_template',{'revision':s['revision'],'template_code':code,'row_index':0,'catalog_id':cid})
   s=call('phase_a_api.php','settings')['settings']
   st,d=o.safe_api('mechanic_flow_api.php','create',{'plate':'BASE351','services':['Oleje a filtry'],'manual_plan':{'revision':s['revision'],'codes':['oil-change'],'quantities':{},'catalog_revisions':{str(rate):1}}})
   assert st==400 and 'hodiny' in d['error'],(st,d)
   c=next(c for c in call('catalog_api.php','list')['items'] if c['id']==part);call('catalog_api.php','save',{**c,'active':0})
   with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage']);page=b.new_page(viewport={'width':412,'height':820})
    page.goto(r.url+'/index.php');page.get_by_label('E-mail',exact=True).fill('owner@example.test');page.get_by_label('Heslo',exact=True).fill(r.ownerpass);page.locator('form button').click();page.wait_for_load_state('networkidle')
    page.goto(r.url+'/mechanic_work.php');page.wait_for_load_state('networkidle');page.locator('[data-service="Oleje a filtry"]').click();button=page.locator('[data-manual-code="oil-filter"]');assert button.is_enabled();button.click();assert 'Nenaceněno' in page.locator('.manual-preview').inner_text();b.close()
   result={'baseline':'3.5.0','real_database':True,'hourly_empty_hours':{'status':st,'error':d['error']},'inactive_card_enabled':True,'inactive_mislabelled_unpriced':True}
   out=current/'tests/evidence/351';out.mkdir(parents=True,exist_ok=True);(out/'baseline.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False))
 finally:runtime.ROOT=current
