"""Run actual HTTP/database checks and optionally the full Chromium walkthrough."""
from runtime import Runtime,Client,ROOT,PHP,INI
import secrets,json,subprocess,os,concurrent.futures
checks=[]
def check(value,label):
 if not value:raise AssertionError(label)
 checks.append(label);print('OK '+label,flush=True)
def key():return secrets.token_hex(20)
def main():
 with Runtime() as r:
  owner=r.owner
  check(r.sql('SELECT COUNT(*) FROM abc_test.jobs')=='0' and r.sql('SELECT COUNT(*) FROM abc_test.abc_quick_catalog')=='0','Fresh install contains no demo jobs or prices')
  check(owner.request('setup.php')[0]==409,'Installer refuses nonempty installed DB')
  check(Client(r.url).safe_api('api.php','list_jobs')[0]==401,'Anonymous access refused')
  check(owner.request('api.php?action=add_payment',{'id':1},api=True,token=False)[0]==403,'CSRF remains required')
  check(owner.form('save_customer',name='Jan Řidič',phone='700000001',email='customer@example.test',address='Testovací 1, Praha',ico='',note='')[0]==200,'Customer saved in shared database')
  cid=int(r.sql('SELECT id FROM abc_test.crm_customers LIMIT 1'))
  check(owner.form('save_vehicle',customer_id=cid,plate='5AB 1234',vin='WVWZZZ1JZXW000001',brand='Škoda',model='Octavia',mileage='123456')[0]==200,'Vehicle saved with customer relationship')
  vid=int(r.sql('SELECT id FROM abc_test.crm_vehicles LIMIT 1'))
  for desc,cat,kind,price in [('Kompletní přezutí 15″ s vyvážením','Pneuservis','labor','1000'),('Výměna motorového oleje','Oleje a filtry','labor','500')]:check(owner.form('save_catalog',description=desc,category=cat,kind=kind,unit_price=price,unit_cost='0',active='1')[0]==200,'Catalog '+desc)
  check(owner.form('save_user',name='Kozel',email='mechanic@example.test',password=r.workerpass,permissions=['price_jobs','collect_payments','issue_invoices','print_receipts'])[0]==200,'Mechanic account created')
  workerid=int(r.sql("SELECT id FROM abc_test.users WHERE email='mechanic@example.test'"));worker=Client(r.url);check(worker.login('mechanic@example.test',r.workerpass)[0]==200,'Mechanic login')
  check(worker.request('office.php')[0]==403,'Mechanic cannot open reception')
  check(worker.request('mechanic.php')[0]==200,'Login survives next page request')
  data={'plate':'9AA1001','services':['Pneuservis','Oleje a filtry','Brzdy'],'requested':'Kontrola zadních tlumičů','request_key':key()}
  status,d=worker.safe_api('mechanic_flow_api.php','create',data);check(status==200,'Rapid intake with only plate and three services');jid=int(d['id'])
  status,replay=worker.safe_api('mechanic_flow_api.php','create',data);check(status==200 and replay['id']==jid,'Repeated intake returns the same job')
  check(r.sql('SELECT COUNT(*) FROM abc_test.jobs')=='1','Repeated intake did not duplicate database record')
  check(r.sql('SELECT COUNT(*) FROM abc_test.crm_vehicle_jobs WHERE job_id='+str(jid))=='1','Plate-only intake creates searchable vehicle history')
  check(r.sql('SELECT COUNT(*) FROM abc_test.office_appointments WHERE job_id='+str(jid))=='0','No appointment created without selected arrival')
  check(r.sql('SELECT COUNT(*) FROM abc_test.items WHERE job_id='+str(jid))=='0','Requested service cards do not create bill items')
  check(r.sql("SELECT COUNT(*) FROM abc_test.abc_quick_tasks WHERE job_id="+str(jid)+" AND entry_type='request'")=='3','Requests are stored separately from actual work')
  check(worker.safe_api('mechanic_api.php','quick_lookup',q='9AA')[1]['vehicles'][0]['plate']=='9AA1001','New registration is offered on next intake')
  check(len(worker.safe_api('mechanic_api.php','quick_lookup',q='Jan')[1]['customers'])==1,'Customer autocomplete')
  check(len(worker.safe_api('mechanic_api.php','quick_lookup',q='5AB 1234')[1]['vehicles'])==1,'Autocomplete normalizes registration whitespace')
  check('Cena bude upřesněna' in worker.request('job_sheet.php?job='+str(jid))[1],'Job sheet prints before prices exist')
  check(owner.safe_api('api.php','get_job',id=jid)[0]==200,'Reception sees mechanic record from independent session')
  add={'id':jid,'description':'Motorový olej 5W-30','kind':'part','category':'Oleje a filtry','quantity':'4.5','unit_price':'100','request_key':key()}
  status,out=worker.safe_api('mechanic_flow_api.php','add',add);check(status==200,'Custom part without stock and decimal oil quantity');task=int(out['task_id'])
  check(worker.safe_api('mechanic_flow_api.php','add',add)[1]['task_id']==task,'Repeating add does not duplicate work')
  check(worker.safe_api('api.php','set_status',{'id':jid,'status':'done'})[0]==200,'Planned unused material is not billed and does not pretend actual use');check(worker.safe_api('mechanic_flow_api.php','info',id=jid)[1]['totals']['total']==0,'Unconfirmed material creates no amount to collect');worker.safe_api('api.php','set_status',{'id':jid,'status':'work'})
  check(worker.safe_api('mechanic_api.php','quick_task_status',{'id':jid,'task_id':task,'status':'done'})[0]==200,'Work can be checked complete')
  check(worker.safe_api('api.php','set_status',{'id':jid,'status':'done'})[0]==200,'Request cards do not block completed actual work')
  invoice={'job_id':jid,'customer_name':'Jan Řidič','customer_address':'Testovací 1, Praha','customer_ico':'','customer_email':'','due_days':14,'note':'','request_key':key()}
  status,inv=worker.safe_api('office_api.php','issue_invoice',invoice);check(status==200,'Invoice issued');check(worker.safe_api('office_api.php','issue_invoice',invoice)[1]['invoice_id']==inv['invoice_id'],'Repeated invoice returns the same number')
  check(r.sql('SELECT COUNT(*) FROM abc_test.payments')=='0','Invoice alone records neither cash nor payment')
  check(worker.safe_api('mechanic_flow_api.php','price',{'id':jid,'task_id':task,'unit_price':999})[0]==409,'Invoice locks bill prices')
  payment={'id':jid,'amount':'100','method':'cash','request_key':key()}
  status,pay=worker.safe_api('api.php','add_payment',payment);check(status==200,'Partial cash payment of invoice')
  check(worker.safe_api('api.php','add_payment',payment)[1]['payment_id']==pay['payment_id'],'Repeated partial payment is idempotent')
  check(r.sql('SELECT COUNT(*) FROM abc_test.payments')=='1','Repeated partial payment did not create revenue')
  check(worker.safe_api('api.php','add_payment',{**payment,'amount':'101'})[0]==409,'Same operation key cannot change amount')
  check(abs(worker.safe_api('mechanic_flow_api.php','info',id=jid)[1]['totals']['due']-350)<.001,'Correct remaining balance after partial payment')
  check(worker.safe_api('api.php','add_payment',{'id':jid,'amount':'1','method':'transfer','request_key':key()})[0]==403,'Only owner confirms bank transfers')
  check(worker.safe_api('api.php','add_payment',{'id':jid,'amount':'351','method':'card','request_key':key()})[0]==409,'Overpayment refused')
  def concurrent_payment(_):
   c=Client(r.url);c.login('owner@example.test',r.ownerpass);return c.safe_api('api.php','add_payment',{'id':jid,'amount':'350','method':'transfer','request_key':key()})[0]
  with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:statuses=list(pool.map(concurrent_payment,[0,1]))
  check(sorted(statuses)==[200,409],'Concurrent final payments cannot overpay')
  check(r.sql('SELECT SUM(amount) FROM abc_test.payments WHERE job_id='+str(jid))=='450.00','Collected payments exactly match charge')
  check('P-20' in worker.request('mechanic_receipt.php?payment='+str(pay['payment_id']))[1],'Receipt has stable numbered document')
  hdata={'declared_amount':'100','request_key':key()};status,h=worker.safe_api('api.php','submit_handover',hdata);check(status==200,'Mechanic submits cash handover');check(worker.safe_api('api.php','submit_handover',hdata)[1]['id']==h['id'],'Repeated handover is idempotent')
  check(owner.form('accept_handover',id=h['id'],counted_amount='99')[0]==409,'Cash discrepancy is not accepted')
  check(owner.form('accept_handover',id=h['id'],counted_amount='100')[0]==200,'Owner confirms handover from separate session')
  check(r.sql('SELECT SUM(amount) FROM abc_test.payments WHERE job_id='+str(jid))=='450.00','Handover does not create additional revenue')
  # A separately scheduled record is not confused with the intake timestamp.
  date=r.sql("SELECT DATE_FORMAT(DATE_ADD(CURDATE(),INTERVAL 1 DAY),'%Y-%m-%d')")
  scheduled={'vehicle_id':vid,'services':['Brzdy'],'date':date,'time':'10:00','duration':60,'request_key':key()}
  status,sch=worker.safe_api('mechanic_flow_api.php','create',scheduled);check(status==200 and sch['scheduled'],'Optional arrival creates linked appointment')
  check(worker.safe_api('mechanic_flow_api.php','create',{**scheduled,'request_key':key()})[0]==409,'Mechanic calendar collision rejected')
  check(any(int(a['job_id'])==int(sch['id']) for a in worker.safe_api('mechanic_api.php','calendar')[1]['appointments']),'Calendar API links appointment and job')
  anon_status,anon_doc=Client(r.url).request('office_document.php?invoice='+str(inv['invoice_id']));check(anon_status==200 and 'Přihlásit se' in anon_doc and 'FAKTURA' not in anon_doc,'Document requires authentication and discloses no invoice before login')
  # A different mechanic is denied even with a known job/document ID.
  p2=secrets.token_hex(12);owner.form('save_user',name='Druhý mechanik',email='other@example.test',password=p2,permissions=['price_jobs'])
  second=Client(r.url);second.login('other@example.test',p2);check(second.safe_api('mechanic_flow_api.php','info',id=jid)[0]==403,'Other mechanic cannot read job')
  check(second.request('office_document.php?invoice='+str(inv['invoice_id']))[0]==403,'Other mechanic cannot read invoice')
  # Additive migration against the supplied 2.1 schema, preserving existing rows.
  r.sql('CREATE DATABASE abc_old CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;USE abc_old;'+(ROOT/'tests/schema_211.sql').read_text())
  oldhash=r.sql('SELECT password_hash FROM abc_test.users WHERE id=1')
  r.sql("USE abc_old;INSERT INTO users(id,name,email,password_hash,role,permissions) VALUES (7,'Archiv','archive@example.test','"+oldhash+"','owner','[]');INSERT INTO crm_customers(id,name) VALUES (12,'Původní zákazník');INSERT INTO crm_vehicles(id,customer_id,plate) VALUES (16,12,'OLD1234');INSERT INTO jobs(id,title,created_by,assigned_to) VALUES (23,'Původní zakázka',7,7);INSERT INTO abc_quick_tasks(id,job_id,category,description,kind,created_by) VALUES (31,23,'Ostatní','Původní úkon','labor',7);INSERT INTO payments(id,job_id,user_id,amount,method) VALUES (41,23,7,123.45,'cash');INSERT INTO schema_meta(version) VALUES ('2.1.0');")
  before=r.sql('SELECT id,job_id,user_id,amount,method FROM abc_old.payments;SELECT id,name FROM abc_old.crm_customers;SELECT id,title FROM abc_old.jobs;')
  code="require 'app/migrations.php';$p=new PDO('mysql:host=127.0.0.1;port='.getenv('ABC_DB_PORT').';dbname=abc_old','root','',[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);echo json_encode(abc_migrate_v300($p));"
  cmd=[PHP]+(['-c',INI] if INI else [])+['-r',code]
  # TCP root account is local only on this temporary server.
  migrated=subprocess.run(cmd,cwd=ROOT,env=r.env,text=True,capture_output=True);check(migrated.returncode==0,'Legacy additive migration runs on real MariaDB: '+migrated.stderr[:150])
  check(before==r.sql('SELECT id,job_id,user_id,amount,method FROM abc_old.payments;SELECT id,name FROM abc_old.crm_customers;SELECT id,title FROM abc_old.jobs;'),'Migration preserves original customer/job/payment IDs and values')
  again=subprocess.run(cmd,cwd=ROOT,env=r.env,text=True,capture_output=True);check(again.returncode==0 and again.stdout=='[]','Migration is repeatable without duplicate columns or data')
  check(r.sql('SELECT entry_type FROM abc_old.abc_quick_tasks WHERE id=31')=='work','Migration never guesses meaning of existing task')
  if os.environ.get('ABC_TEST_BROWSER')=='1':
   from browser_flow import run_browser
   run_browser(r,check)
  r.weblog.flush();errors=(r.tmp/'php.log').read_text();check(not any(x in errors for x in ['PHP Warning','PHP Fatal error','PHP Parse error']),'No PHP warnings or fatal errors')
 report={'passed':len(checks),'checks':checks,'php':'PHP 8.4.24','database':'MariaDB 11.8.6','browser':os.environ.get('ABC_TEST_BROWSER')=='1','wedos_rewrite':os.environ.get('ABC_TEST_WEDOS_REWRITE')=='1'}
 evidence=ROOT/'tests/evidence';evidence.mkdir(exist_ok=True);(evidence/('results-wedos.json' if report['wedos_rewrite'] else 'results.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({'passed':len(checks),'browser':report['browser']}))
if __name__=='__main__':main()
