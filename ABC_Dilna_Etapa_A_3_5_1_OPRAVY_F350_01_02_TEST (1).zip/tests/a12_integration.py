"""A1/A2 acceptance: real HTTP, database constraints, snapshots and conflicts."""
from runtime import Runtime,Client,ROOT,PHP,INI
import secrets,json,subprocess,os,concurrent.futures
checks=[]
def key():return secrets.token_hex(20)
def check(ok,label):
 if not ok:raise AssertionError(label)
 checks.append(label);print('OK '+label,flush=True)
def info(c,j):
 s,d=c.api('mechanic_flow_api.php','info',id=j);assert s==200,d;return d
def main():
 with Runtime() as r:
  o=r.owner
  def create(plate):
   p={'plate':plate,'customer_name':'Test Zakaznik','customer_phone':'700000001','vehicle':'Skoda Octavia','services':['Oleje a filtry','Brzdy','Pneuservis'],'request_key':key()};s,d=o.api('mechanic_flow_api.php','create',p);assert s==200,d;return int(d['id'])
  def add(j,name,kind='labor',price='',q='1',unit='hod'):
   p={'id':j,'description':name,'kind':kind,'category':'Oleje a filtry','quantity':q,'unit':unit,'unit_price':price,'request_key':key()};s,d=o.api('mechanic_flow_api.php','add',p);assert s==200,d;return d['line']
  def row(c,j,tid):return next(t for t in info(c,j)['tasks'] if int(t['id'])==int(tid))
  def update(c,j,t,**fields):
   p={'id':j,'task_id':t['id'],'kind':t['kind'],'description':t['description'],'quantity':t['quantity'],'unit':t['unit'],'unit_price':t['unit_price'],'note':t['note'],'part_code':t['part_code'],'revision':t['revision'],'request_key':key(),**fields};return c.api('mechanic_flow_api.php','update_line',p),p
  def status(j,value):
   p={'id':j,'status':value,'revision':info(o,j)['job']['revision'],'request_key':key()};return o.api('api.php','set_status',p)
  def done(j,t):
   return o.api('mechanic_api.php','quick_task_status',{'id':j,'task_id':t['id'],'status':'done','revision':row(o,j,t['id'])['revision'],'request_key':key()})
  anonymous=Client(r.url);check(anonymous.api('api.php','list_jobs')[0]==401 and not any(k.lower()=='set-cookie' for k in anonymous.last_headers),'Unauthorized late API cannot issue a cookie that overwrites a new login')
  check(r.sql('SELECT COUNT(*) FROM abc_test.jobs')=='0','Fresh installation contains no demo jobs')
  check(r.sql("SELECT COUNT(*) FROM abc_test.schema_meta WHERE version='3.2.0-a12'")=='1','Fresh install has completed A12 migration marker')
  j=create('A120001');check(r.sql('SELECT COUNT(*) FROM abc_test.office_appointments WHERE job_id='+str(j))=='0','Unscheduled intake creates no time reservation or lift occupancy')
  check(r.sql('SELECT COUNT(*) FROM abc_test.items WHERE job_id='+str(j))=='0','Three requested services do not generate billed lines')
  check(info(o,j)['job']['status']=='work','Unscheduled job is active for today work list')
  labor=add(j,'Vymena oleje','labor','500','1','hod');oil=add(j,'Olej 10W40','part','100','5','l');filter_=add(j,'Olejovy filtr','part','','1','ks');unused=add(j,'Pouze planovany sprej','part','200','2','ks')
  check(info(o,j)['totals']['estimated_total']==1400 and info(o,j)['totals']['total']==0,'Planned prices form an estimate; unperformed work and unused parts create no bill')
  r.sql('UPDATE abc_test.items SET unit_cost=42 WHERE id='+str(oil['item_id']))
  (s,d),payload=update(o,j,oil,quantity='6',note='Poznamka',part_code='TEST-01');check(s==200,'Inline quantity note and part code save to real DB')
  check(r.sql('SELECT unit_cost FROM abc_test.items WHERE id='+str(oil['item_id']))=='42.00','Sale edit retains purchase cost')
  check(o.api('mechanic_flow_api.php','update_line',payload)[0]==200,'Identical repeated line save is idempotent')
  (s,d),_=update(o,j,row(o,j,oil['id']),unit_price='');check(s==200 and d['line']['unit_price'] is None,'Existing price can be cleared to genuinely unknown')
  check(r.sql('SELECT id,unit_cost,unit_price FROM abc_test.items WHERE id='+str(oil['item_id']))==str(oil['item_id'])+'\t42.00\tNULL','Unknown price keeps linked item ID and purchase metadata')
  (s,d),_=update(o,j,row(o,j,oil['id']),unit_price='120',quantity='5',unit_cost='0');check(s==200 and r.sql('SELECT unit_cost FROM abc_test.items WHERE id='+str(oil['item_id']))=='42.00','Repricing cannot overwrite purchase cost even via extra payload field')
  current=row(o,j,oil['id']);p={'id':j,'task_id':oil['id'],'kind':'part','description':'Missing version','quantity':5,'unit':'l','unit_price':120,'request_key':key()};check(o.api('mechanic_flow_api.php','update_line',p)[0]==428,'Version is required by the actual server, not silently supplied')
  (s,d),_=update(o,j,current,quantity='7');check(s==200,'First editor saves quantity')
  (s,d),_=update(o,j,current,description='Stale second editor');check(s==409 and d['code']=='revision_conflict' and d['current']['quantity']=='7.000','Stale editor cannot overwrite newer quantity; conflict provides current safe row')
  check('unit_cost' not in json.dumps(d),'Conflict response does not leak purchase cost')
  (s,d),_=update(o,j,row(o,j,oil['id']),quantity='5');assert s==200
  check(status(j,'done')[0]==409,'Unfinished labor blocks repair completion')
  check(done(j,labor)[0]==200,'Actual labor completion is recorded')
  bad={'id':j,'rows':[{'id':oil['id'],'revision':1},{'id':filter_['id'],'revision':1}],'request_key':key()};check(o.api('mechanic_flow_api.php','confirm_materials',bad)[0]==409 and row(o,j,filter_['id'])['status']=='planned','Bulk material conflict rolls back all selected items')
  confirm={'id':j,'rows':[{'id':oil['id'],'revision':row(o,j,oil['id'])['revision']},{'id':filter_['id'],'revision':1}],'request_key':key()};check(o.api('mechanic_flow_api.php','confirm_materials',confirm)[0]==200,'Selected actually used materials can be confirmed together')
  check(o.api('mechanic_flow_api.php','confirm_materials',confirm)[0]==200,'Repeated batch confirmation never duplicates consumption or money')
  check(row(o,j,unused['id'])['status']=='planned','Unselected material is still planned and not silently installed')
  check(status(j,'done')[0]==200,'Repair completes with unused planned material left outside the bill')
  inv={'job_id':j,'revision':info(o,j)['job']['revision'],'customer_name':'Original Customer','customer_address':'Original Address 1','due_days':14,'request_key':key()}
  check(o.api('office_api.php','issue_invoice',inv)[0]==409,'Used unpriced material blocks document issue instead of inventing zero price')
  (s,d),_=update(o,j,row(o,j,filter_['id']),unit_price='150');assert s==200
  new=add(j,'Dodatecna kontrola','labor','100');check(info(o,j)['job']['status']=='work','New unfinished work automatically reopens Hotovo so it cannot remain hidden')
  check(o.api('api.php','add_payment',{'id':j,'method':'cash','amount':'1','request_key':key()})[0]==409,'Payment cannot ignore newly unfinished work')
  check(done(j,new)[0]==200 and status(j,'done')[0]==200,'Same repair can be completed again after additional work')
  check(status(j,'parts')[0]==200 and status(j,'work')[0]==200 and status(j,'done')[0]==200,'Hotovo can reopen to waiting for parts or work before billing')
  inv.update(revision=info(o,j)['job']['revision'],request_key=key());s,issued=o.api('office_api.php','issue_invoice',inv);check(s==200,'Invoice issued for actual completed labor and confirmed material')
  snapshot=json.loads(r.sql('SELECT lines_json FROM abc_test.office_invoices WHERE id='+str(issued['invoice_id'])));check(len(snapshot)==4 and not any(x['description']=='Pouze planovany sprej' for x in snapshot),'Planned unused parts are absent from immutable invoice lines')
  check(r.sql('SELECT total FROM abc_test.office_invoices WHERE id='+str(issued['invoice_id']))=='1350.00','Invoice total matches only completed/used items')
  check(r.sql('SELECT COUNT(*) FROM abc_test.payments')=='0','Invoice issue alone creates no money')
  before_doc=o.request('office_document.php?invoice='+str(issued['invoice_id']))[1]
  identity=info(o,j);v=identity['vehicle'];c=identity['customer']
  identity_payload={'id':j,'vehicle':{'revision':v['revision'],'plate':'A120002','vin':'WVWZZZ1JZXW000001','brand':'Skoda','model':'Octavia zmena','mileage':'234567'},'customer':{'revision':c['revision'],'name':'Current Customer','phone':'700000999','email':'current@example.test'},'request_key':key()}
  check(o.api('mechanic_flow_api.php','update_identity',identity_payload)[0]==200,'Live customer and vehicle can be updated after document issue')
  check(o.request('office_document.php?invoice='+str(issued['invoice_id']))[1]==before_doc,'Already-issued invoice remains byte-identical after live VIN contact mileage and plate changes')
  check(info(o,j)['job']['vin']=='WVWZZZ1JZXW000001' and info(o,j)['job']['mileage']==234567,'Working card uses updated live records')
  old_identity={**identity_payload,'request_key':key()};check(o.api('mechanic_flow_api.php','update_identity',old_identity)[0]==409,'Stale live CRM update is also rejected without silent overwrite')
  (s,d),_=update(o,j,row(o,j,oil['id']),unit_price='1');check(s==409,'Document financial lines remain locked')
  pay={'id':j,'amount':'100','method':'cash','request_key':key()};s,paid=o.api('api.php','add_payment',pay);again=o.api('api.php','add_payment',pay);check(s==200 and again[0]==200 and paid['payment_id']==again[1]['payment_id'],'Partial payments remain idempotent')
  check(info(o,j)['totals']['due']==1250,'Unselected planned stock never appears after partial invoice payment')
  # Cash document without invoice also freezes the amount and excludes unused parts.
  cashj=create('A12CASH');cl=add(cashj,'Prace','labor','300');cu=add(cashj,'Nepouzity dil','part','900','1','ks');done(cashj,cl);status(cashj,'done');cash={'id':cashj,'amount':'100','method':'cash','request_key':key()};check(o.api('api.php','add_payment',cash)[0]==200 and info(o,cashj)['totals']['due']==200,'Cash partial payment without invoice freezes actual charge and does not include unused part')
  freej=create('A12FREE');fl=add(freej,'Bezplatna kontrola','labor','0');done(freej,fl);status(freej,'done');check(status(freej,'closed')[0]==200 and status(freej,'work')[0]==200,'Handed-over job without any issued document can reopen; document presence controls financial lock')
  # Non-price edits and explicit denial of price changes for a regular mechanic.
  o.form('save_user',name='Mechanik',email='worker@example.test',password=r.workerpass,permissions=[]);w=Client(r.url);w.login('worker@example.test',r.workerpass)
  s,d=w.api('mechanic_flow_api.php','create',{'plate':'A12WORK','services':['Brzdy'],'request_key':key()});wj=d['id'];wt=add(wj,'Dil naceneny kancelari','part','100','1','ks')
  (s,d),_=update(w,wj,wt,quantity='2',description='Upresneni mechanikem');check(s==200,'Mechanic can edit quantity and description while unit-price permission stays separate')
  (s,d),_=update(w,wj,row(w,wj,wt['id']),unit_price='1');check(s==403,'Mechanic cannot change unit sale price through direct API')
  check('unit_cost' not in json.dumps(info(w,wj)),'Mechanic detail never returns purchase prices')
  check(w.api('mechanic_flow_api.php','update_line',{'id':j,'task_id':oil['id'],'revision':1,'request_key':key()})[0]==403,'Different assigned mechanic cannot edit another job')
  # Concurrent valid writers cannot both save the same revision.
  ct=row(o,wj,wt['id']);reqs=[]
  for n in [3,4]:reqs.append({'id':wj,'task_id':ct['id'],'kind':'part','description':ct['description'],'quantity':str(n),'unit':'ks','unit_price':'100','revision':ct['revision'],'request_key':key()})
  def writer(p):
   c=Client(r.url);c.login('owner@example.test',r.ownerpass);return c.api('mechanic_flow_api.php','update_line',p)[0]
  with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:codes=list(pool.map(writer,reqs))
  check(sorted(codes)==[200,409],'Real simultaneous requests produce one save and one explicit conflict')
  cancelled=row(o,wj,wt['id']);s,d=o.api('mechanic_flow_api.php','cancel_line',{'id':wj,'task_id':cancelled['id'],'revision':cancelled['revision'],'request_key':key()});check(s==200 and r.sql('SELECT COUNT(*) FROM abc_test.items WHERE id='+str(cancelled['item_id']))=='1','Cancellation keeps original cost record while excluding it from estimate and bill')
  check(info(o,wj)['totals']['estimated_total']==0,'Cancelled row is not counted in totals')
  catj=create('A12CAT');o.form('save_catalog',description='Cenikovy olej',category='Oleje a filtry',kind='part',unit='l',unit_price='200',unit_cost='90',active='1');cid=int(r.sql("SELECT id FROM abc_test.abc_quick_catalog WHERE description='Cenikovy olej'"));s,cat=o.api('mechanic_flow_api.php','add',{'id':catj,'kind':'part','description':'Cenikovy olej','quantity':'2','catalog_id':cid,'catalog_revision':1,'unit_price':'','request_key':key()});check(s==200 and cat['line']['unit_price'] is None and cat['line']['unit']=='l' and r.sql('SELECT unit_cost FROM abc_test.items WHERE id='+str(cat['line']['item_id']))=='90.00','Catalog unit and purchase cost survive an explicitly unknown sale price')
  # Schema guard is read-only until owner explicitly runs upgrade on the test copy.
  before=r.sql('SELECT COUNT(*) FROM abc_test.events');r.sql("DELETE FROM abc_test.schema_meta WHERE version='3.2.0-a12'")
  check(o.api('mechanic_flow_api.php','info',id=j)[0]==503 and r.sql('SELECT COUNT(*) FROM abc_test.events')==before,'Missing schema marker produces a clear upgrade requirement without DDL on normal GET')
  o.request('upgrade.php');s,d=o.request('upgrade.php',{'csrf':o.csrf,'backup_confirmed':'1'});check(s==200 and r.sql("SELECT COUNT(*) FROM abc_test.schema_meta WHERE version='3.2.0-a12'")=='1','Owner upgrade route runs complete repeatable A12 migration')
  check(o.api('mechanic_flow_api.php','info',id=j)[0]==200,'Working card is available after explicit upgrade')
  # Repeatable migration over actual historical data, including immutable invoice snapshot.
  r.sql('CREATE DATABASE a12_old CHARACTER SET utf8mb4;USE a12_old;'+(ROOT/'tests/schema_211.sql').read_text())
  ph=r.sql('SELECT password_hash FROM abc_test.users WHERE id=1');supplier=json.dumps({'company_name':'Old supplier','company_address':'Old address','company_ico':'12345678','company_phone':'','company_bank_account':''});lines=json.dumps([{'description':'Original work','kind':'labor','quantity':2,'unit_price':300}])
  r.sql("USE a12_old;INSERT INTO users(id,name,email,password_hash,role,permissions) VALUES(1,'Old','old@example.test','"+ph+"','owner','[]');INSERT INTO jobs(id,title,plate,created_by,assigned_to,status) VALUES(44,'Old repair','OLD123',1,1,'done');INSERT INTO items(id,job_id,kind,description,quantity,unit_price,unit_cost) VALUES(66,44,'labor','Original work',2,300,99);INSERT INTO abc_quick_tasks(id,job_id,category,description,kind,quantity,status,item_id,created_by) VALUES(77,44,'Old','Original work','labor',2,'done',66,1);INSERT INTO office_invoices(id,job_id,invoice_no,customer_name,issued_on,due_on,total,lines_json,supplier_json,created_by) VALUES(88,44,'OLD-88','Old customer','2025-01-01','2025-01-15',600,'"+lines+"','"+supplier+"',1);INSERT INTO schema_meta(version) VALUES('3.0.0');")
  before=r.sql('SELECT id,job_id,quantity,unit_price,unit_cost FROM a12_old.items;SELECT id,invoice_no,lines_json,supplier_json FROM a12_old.office_invoices;')
  code="require 'app/migrations.php';$p=new PDO('mysql:host=127.0.0.1;port='.getenv('ABC_DB_PORT').';dbname=a12_old','root','',[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);echo json_encode(abc_migrate_a12($p));";cmd=[PHP]+(['-c',INI] if INI else [])+['-r',code]
  first=subprocess.run(cmd,cwd=ROOT,env=r.env,text=True,capture_output=True);second=subprocess.run(cmd,cwd=ROOT,env=r.env,text=True,capture_output=True)
  check(first.returncode==0 and second.returncode==0 and second.stdout=='[]','Historical A12 migration runs and is repeatable')
  check(before==r.sql('SELECT id,job_id,quantity,unit_price,unit_cost FROM a12_old.items;SELECT id,invoice_no,lines_json,supplier_json FROM a12_old.office_invoices;'),'Migration preserves all historical money, item IDs and invoice JSON bytes')
  context=json.loads(r.sql('SELECT context_json FROM a12_old.office_invoices WHERE id=88'));check(context['job']['plate']=='OLD123' and context['capture']=='legacy_at_migration','Historical document freezes previously printed facts with honest migration provenance')
  check(r.sql('SELECT unit FROM a12_old.items WHERE id=66')=='úkon','Migration never invents worked hours for legacy actions')
  if os.environ.get('ABC_TEST_BROWSER')=='1':
   from a12_browser import run_browser
   run_browser(r,check)
  r.weblog.flush();log=(r.tmp/'php.log').read_text();
  for line in log.splitlines():
   if any(tag in line for tag in ['PHP Warning','PHP Fatal error','PHP Parse error']):print(line,flush=True)
  check(not any(s in log for s in ['PHP Warning','PHP Fatal error','PHP Parse error']),'No PHP warnings or fatal errors during A12 acceptance')
 report={'milestone':'A1+A2','passed':len(checks),'checks':checks,'browser':os.environ.get('ABC_TEST_BROWSER')=='1','wedos_rewrite':bool(os.environ.get('ABC_TEST_WEDOS_REWRITE'))};dest=ROOT/'tests/evidence/a12';dest.mkdir(exist_ok=True,parents=True);(dest/('results-wedos.json' if report['wedos_rewrite'] else 'results.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({'passed':len(checks)}))
if __name__=='__main__':main()
