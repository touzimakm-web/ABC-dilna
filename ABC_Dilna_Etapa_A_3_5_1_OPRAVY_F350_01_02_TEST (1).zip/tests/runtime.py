"""Isolated PHP + MariaDB fixture. Never uses app/config.php or a production DB."""
from pathlib import Path
import os,subprocess,tempfile,socket,time,signal,secrets,json,re,urllib.request,urllib.parse,urllib.error,http.cookiejar
ROOT=Path(__file__).resolve().parents[1]
PHP=os.environ.get('ABC_TEST_PHP','php');BASE=Path(os.environ.get('ABC_TEST_MARIADB_BASE','/usr'));INI=os.environ.get('ABC_TEST_PHP_INI')
def port():
 with socket.socket() as s:s.bind(('127.0.0.1',0));return s.getsockname()[1]
class Client:
 def __init__(self,url):self.url=url;self.csrf='';self.operation_revisions={};self.catalog_quotes={};self.opener=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
 def request(self,path,data=None,api=False,token=True):
  headers={};body=None
  if data is not None:
   if api:
    body=json.dumps(data).encode();headers['Content-Type']='application/json'
    if token:headers['X-CSRF-Token']=self.csrf
   else:body=urllib.parse.urlencode(data,doseq=True).encode()
  try:
   with self.opener.open(urllib.request.Request(self.url+'/'+path,data=body,headers=headers),timeout=20) as r:status=r.status;raw=r.read().decode();typ=r.headers.get('Content-Type','');self.last_headers=dict(r.headers)
  except urllib.error.HTTPError as r:status=r.code;raw=r.read().decode();typ=r.headers.get('Content-Type','');self.last_headers=dict(r.headers)
  if 'application/json' in typ:return status,json.loads(raw)
  m=re.search(r'name="csrf" value="([a-f0-9]+)"',raw)
  if m:self.csrf=m[1]
  return status,raw
 def api(self,file,action,data=None,**params):return self.request(file+'?'+urllib.parse.urlencode({'action':action,**params}),data,api=data is not None)
 def safe_api(self,file,action,data=None,**params):
  """Compatibility for old test scenarios: acts like an updated UI reading revisions.
  New concurrency/required-version tests deliberately use raw api()/request()."""
  if data is not None:
   data=dict(data);data.setdefault('request_key',secrets.token_hex(20))
   op=(file,action,data['request_key'])
   if file=='mechanic_estimate_api.php' and action=='save':
    st,quoteinfo=self.api(file,'info',id=data.get('id'));data.setdefault('job_revision',quoteinfo.get('job',{}).get('revision'));qmap={int(t['id']):t for t in quoteinfo.get('tasks',[])}
    for line in data.get('lines',[]):line.setdefault('revision',qmap.get(int(line.get('task_id',0)),{}).get('revision'))
   if action=='add' and data.get('catalog_id') and 'catalog_revision' not in data:
    if op not in self.catalog_quotes:
     st,quoted=self.api('mechanic_api.php','catalog');self.catalog_quotes[op]=next((x['revision'] for x in quoted.get('items',[]) if int(x['id'])==int(data['catalog_id'])),None)
    data['catalog_revision']=self.catalog_quotes[op]
   if action=='tyres':
    if op not in self.catalog_quotes:
     st,quoted=self.api('phase_a_api.php','settings');self.catalog_quotes[op]={'settings_revision':quoted['settings']['revision'],'catalog_revisions':{str(x['id']):x['revision'] for x in quoted['catalog']}}
    for k,v in self.catalog_quotes[op].items():data.setdefault(k,v)
   if op in self.operation_revisions:data.setdefault('revision',self.operation_revisions[op])
   if 'revision' not in data and action in ['price','update_line','cancel_line','quick_task_status','classify_request','set_status','set_discount','issue_invoice']:
    jid=data.get('id') or data.get('job_id');status,info=self.api('mechanic_flow_api.php','info',id=jid)
    if status==200:
     if action in ['set_status','set_discount','issue_invoice']:data['revision']=info['job']['revision']
     else:
      row=next((t for t in info['tasks'] if int(t['id'])==int(data.get('task_id',0))),None)
      if row:data['revision']=row['revision']
   if 'revision' in data:self.operation_revisions[op]=data['revision']
  return self.api(file,action,data,**params)
 def form(self,action,**fields):
  if action=='save_catalog':fields.setdefault('request_key',secrets.token_hex(20))
  fields={(k+'[]' if isinstance(v,list) and not k.endswith('[]') else k):v for k,v in fields.items()}
  if fields.get('id') and action in ['save_customer','save_vehicle','assign_job','appointment'] and 'revision' not in fields:
   status,html=self.request('office.php?view=customers&customer='+str(fields.get('customer_id') or fields['id']) if action in ['save_customer','save_vehicle'] else 'office.php?view=jobs&job='+str(fields['id']))
   # Tests needing a stale form explicitly provide revision; ordinary existing scenarios use rendered pages.
   if action=='save_customer':
    match=re.search(r'name="revision" value="(\d+)"',html)
    if match:fields['revision']=int(match[1])
  return self.request('office_actions.php',{'csrf':self.csrf,'action':action,**fields})
 def login(self,email,password):self.request('index.php');return self.request('index.php',{'csrf':self.csrf,'email':email,'password':password})
class Runtime:
 def __enter__(self):
  self.folder=tempfile.TemporaryDirectory(prefix='abc-v300-');self.tmp=Path(self.folder.name);self.dbport=port();self.webport=port();self.socket=self.tmp/'maria.sock';self.processes=[]
  self.password=secrets.token_hex(20);self.ownerpass=secrets.token_hex(12);self.workerpass=secrets.token_hex(12);self.setup=secrets.token_hex(24)
  init=subprocess.run([str(BASE/'bin/mariadb-install-db'),'--no-defaults','--basedir='+str(BASE),'--datadir='+str(self.tmp/'db'),'--tmpdir='+str(self.tmp),'--auth-root-authentication-method=normal','--skip-test-db'],capture_output=True,text=True,timeout=60)
  if init.returncode:raise RuntimeError(init.stdout+init.stderr)
  self.dblog=(self.tmp/'mariadb.log').open('w+')
  self.processes.append(subprocess.Popen([str(BASE/'sbin/mariadbd'),'--no-defaults','--basedir='+str(BASE),'--datadir='+str(self.tmp/'db'),'--tmpdir='+str(self.tmp),'--socket='+str(self.socket),'--pid-file='+str(self.tmp/'maria.pid'),'--port='+str(self.dbport),'--bind-address=127.0.0.1','--skip-log-bin','--skip-name-resolve','--performance-schema=OFF','--innodb-buffer-pool-size=32M'],stdout=self.dblog,stderr=subprocess.STDOUT,start_new_session=True))
  for _ in range(150):
   try:self.sql('SELECT 1;');break
   except RuntimeError:time.sleep(.1)
  else:raise RuntimeError('Temporary MariaDB did not start')
  self.sql("CREATE DATABASE abc_test CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;CREATE USER 'abc_test'@'127.0.0.1' IDENTIFIED BY '"+self.password+"';GRANT ALL PRIVILEGES ON abc_test.* TO 'abc_test'@'127.0.0.1';")
  self.env=os.environ.copy();self.env.update({'ABC_DB_HOST':'127.0.0.1','ABC_DB_PORT':str(self.dbport),'ABC_DB_NAME':'abc_test','ABC_DB_USER':'abc_test','ABC_DB_PASSWORD':self.password,'ABC_SETUP_TOKEN':self.setup,'PHP_CLI_SERVER_WORKERS':'4','ABC_TEST_DROP_REPLY':'1'})
  self.prefix='/nova' if os.environ.get('ABC_TEST_WEDOS_REWRITE')=='1' else '';self.env['ABC_TEST_PUBLIC_PREFIX']=self.prefix
  sessions=self.tmp/'sessions';sessions.mkdir();self.weblog=(self.tmp/'php.log').open('w+')
  php=[PHP]+(['-c',INI] if INI else [])+['-d','session.save_path='+str(sessions)]
  self.processes.append(subprocess.Popen(php+['-S','127.0.0.1:'+str(self.webport),'-t',str(ROOT),str(ROOT/'tests/router.php')],env=self.env,stdout=self.weblog,stderr=subprocess.STDOUT,start_new_session=True))
  self.url='http://127.0.0.1:'+str(self.webport)+self.prefix;self.owner=Client(self.url)
  for _ in range(150):
   try:self.owner.request('setup.php');break
   except (urllib.error.URLError,ConnectionError):time.sleep(.1)
  else:raise RuntimeError('PHP HTTP server did not start')
  status,body=self.owner.request('setup.php',{'csrf':self.owner.csrf,'setup_token':self.setup,'name':'Test Majitel','email':'owner@example.test','password':self.ownerpass})
  if status!=200 or 'Přihlásit se' not in body:raise RuntimeError('Setup failed: '+str(status)+' '+str(body)[:500])
  status,_=self.owner.login('owner@example.test',self.ownerpass)
  if status!=200:raise RuntimeError('Owner login failed')
  return self
 def sql(self,statement):
  r=subprocess.run([str(BASE/'bin/mariadb'),'--no-defaults','--socket='+str(self.socket),'-uroot','--batch','--skip-column-names'],input=statement,text=True,capture_output=True,timeout=30)
  if r.returncode:raise RuntimeError(r.stderr)
  return r.stdout.strip()
 def __exit__(self,*args):
  for p in reversed(self.processes):
   if p.poll() is None:
    try:os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=10)
    except (ProcessLookupError,subprocess.TimeoutExpired):
     try:os.killpg(p.pid,signal.SIGKILL)
     except ProcessLookupError:pass
  self.weblog.close();self.dblog.close();self.folder.cleanup()
