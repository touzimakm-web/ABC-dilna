"""Skutečné integrační testy na dočasné MariaDB a PHP HTTP serveru.
Vyžaduje PHP 8.1+ s pdo_mysql, mbstring, ctype, curl a instalaci MariaDB.
Pouze dočasná databáze; nespojuje se s provozním serverem.
"""
from pathlib import Path
import concurrent.futures
import contextlib
import http.cookiejar
import json
import os
import re
import secrets
import shutil
import signal
import socket
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request

ROOT=Path(__file__).resolve().parents[1]
PHP=os.environ.get('ABC_TEST_PHP',shutil.which('php') or 'php')
BASE=Path(os.environ.get('ABC_TEST_MARIADB_BASE','/usr'))
INI=os.environ.get('ABC_TEST_PHP_INI')
checks=[]
def check(condition,label):
    if not condition:raise AssertionError(label)
    checks.append(label)
def free_port():
    with socket.socket() as s:s.bind(('127.0.0.1',0));return s.getsockname()[1]
class Client:
    def __init__(self,url):
        self.url=url;self.csrf='';self.jar=http.cookiejar.CookieJar()
        self.opener=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(self.jar))
    def request(self,path,data=None,json_body=False,token=True):
        headers={}
        if json_body:
            headers['Content-Type']='application/json'
            if token:headers['X-CSRF-Token']=self.csrf
            body=json.dumps(data).encode()
        elif data is not None:body=urllib.parse.urlencode(data,doseq=True).encode()
        else:body=None
        req=urllib.request.Request(self.url+'/'+path,data=body,headers=headers)
        try:
            with self.opener.open(req,timeout=20) as r:status=r.status;raw=r.read().decode();content=r.headers.get('Content-Type','')
        except urllib.error.HTTPError as r:
            status=r.code;raw=r.read().decode();content=r.headers.get('Content-Type','')
        return status,json.loads(raw) if 'application/json' in content else raw
    def get_token(self,page='index.php'):
        status,body=self.request(page)
        match=re.search(r'name="csrf" value="([a-f0-9]+)"',body)
        if match:self.csrf=match[1]
        return status,body
    def login(self,email,password):
        self.get_token();status,body=self.request('index.php',{'csrf':self.csrf,'email':email,'password':password})
        if status==200:
            m=re.search(r'name="csrf" value="([a-f0-9]+)"',body)
            if m:self.csrf=m[1]
        return status,body
    def api(self,endpoint,action,payload=None,**params):
        path=endpoint+'?'+urllib.parse.urlencode({'action':action,**params})
        return self.request(path,payload,json_body=payload is not None)
    def form(self,action,**fields):
        return self.request('office_actions.php',{'csrf':self.csrf,'action':action,**fields})

def run():
    with tempfile.TemporaryDirectory(prefix='abc-dilna-tests-') as folder:
        tmp=Path(folder);datadir=tmp/'db';datadir.mkdir();sock=tmp/'mariadb.sock'
        dbport=free_port();webport=free_port();dbproc=webproc=None
        try:
            print('Initializing temporary MariaDB…',flush=True)
            result=subprocess.run([str(BASE/'bin/mariadb-install-db'),'--no-defaults','--basedir='+str(BASE),'--datadir='+str(datadir),'--auth-root-authentication-method=normal','--skip-test-db'],capture_output=True,text=True,timeout=60)
            if result.returncode:raise RuntimeError('MariaDB initialization: '+result.stdout[-3000:]+result.stderr[-3000:])
            dblog=(tmp/'mariadb.log').open('w+')
            dbproc=subprocess.Popen([str(BASE/'sbin/mariadbd'),'--no-defaults','--basedir='+str(BASE),'--datadir='+str(datadir),'--socket='+str(sock),'--pid-file='+str(tmp/'mariadb.pid'),'--port='+str(dbport),'--bind-address=127.0.0.1','--skip-name-resolve','--skip-log-bin','--performance-schema=OFF','--innodb-buffer-pool-size=32M'],stdout=dblog,stderr=subprocess.STDOUT)
            def sql(statement):
                result=subprocess.run([str(BASE/'bin/mariadb'),'--no-defaults','--socket='+str(sock),'-u','root','--batch','--skip-column-names'],input=statement,text=True,capture_output=True,timeout=20)
                if result.returncode:raise RuntimeError('Test database query failed: '+result.stderr[:300])
                return result.stdout.strip()
            for _ in range(100):
                if sock.exists():
                    try:sql('SELECT 1;');break
                    except RuntimeError:pass
                if dbproc.poll() is not None:
                    dblog.seek(0);raise RuntimeError(dblog.read()[-4000:])
                time.sleep(.1)
            else:raise RuntimeError('MariaDB did not start')
            dbpassword=secrets.token_hex(20);setup=secrets.token_hex(24);ownerpass=secrets.token_hex(12);mechanicpass=secrets.token_hex(12)
            sql("CREATE DATABASE abc_test CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;CREATE USER 'abc_test'@'127.0.0.1' IDENTIFIED BY '"+dbpassword+"';GRANT ALL PRIVILEGES ON abc_test.* TO 'abc_test'@'127.0.0.1';")
            prefix='/nova' if os.environ.get('ABC_TEST_WEDOS_REWRITE')=='1' else ''
            env=os.environ.copy();env.update({'ABC_DB_HOST':'127.0.0.1','ABC_DB_PORT':str(dbport),'ABC_DB_NAME':'abc_test','ABC_DB_USER':'abc_test','ABC_DB_PASSWORD':dbpassword,'ABC_SETUP_TOKEN':setup,'PHP_CLI_SERVER_WORKERS':'4','ABC_TEST_PUBLIC_PREFIX':prefix})
            sessions=tmp/'sessions';sessions.mkdir()
            phpcmd=[PHP]+(['-c',INI] if INI else [])+['-d','session.save_path='+str(sessions)]
            web_log=(tmp/'php.log').open('w+')
            webproc=subprocess.Popen(phpcmd+['-S','127.0.0.1:'+str(webport),'-t',str(ROOT),str(ROOT/'tests/router.php')],env=env,stdout=web_log,stderr=subprocess.STDOUT,start_new_session=True)
            url='http://127.0.0.1:'+str(webport)+prefix;owner=Client(url)
            for _ in range(100):
                try:owner.get_token('setup.php');break
                except (urllib.error.URLError,ConnectionError):time.sleep(.1)
            else:raise RuntimeError('PHP HTTP test server did not start')
            initial_token=owner.csrf;owner.get_token('setup.php')
            check(initial_token==owner.csrf,'CSRF token survives a second GET with the same cookie')
            check(any(c.name=='abc_dilna_v210' and c.path==(prefix+'/' if prefix else '/') for c in owner.jar),'Session cookie uses the public URL directory')
            status,body=owner.request('setup.php',{'csrf':owner.csrf,'setup_token':setup,'name':'Test Majitel','email':'owner@example.test','password':ownerpass})
            check(status==200 and 'Přihlásit se' in body,'Fresh installation creates schema and owner (HTTP '+str(status)+')')
            status,_=owner.get_token('setup.php');check(status==409,'Installation cannot overwrite existing database')
            anon=Client(url);status,_=anon.api('api.php','list_jobs');check(status==401,'Anonymous API request denied')
            status,body=owner.login('owner@example.test',ownerpass);check(status==200 and 'Všechno pod kontrolou' in body,'Owner login opens reception')
            for view in ['overview','jobs','calendar','customers','catalog','payments','team','settings']:
                status,body=owner.request('office.php?view='+view);check(status==200 and '<!doctype html>' in body,'Reception page '+view)
            for path in ['mechanic.php','mechanic_work.php','assets/mechanic.css','assets/mechanic_work.js']:
                status,_=owner.request(path);check(status==200,'Available UI '+path)
            for path in ['app/config.example.php','sql/schema.sql','tests/integration.py','storage/.htaccess']:
                status,_=owner.request(path);check(status==403,'Internal path denied in test router '+path)
            status,_=owner.request('api.php?action=set_status',{'id':1,'status':'done'},json_body=True,token=False);check(status==403,'CSRF required for mutation')
            status,_=owner.form('save_customer',name='Test <script>auto</script>',phone='+420700000001',email='customer@example.test',address='Testovací 1',ico='',note='Test');check(status==200,'Customer can be created')
            customer=int(sql('SELECT id FROM abc_test.crm_customers LIMIT 1;'))
            status,body=owner.request('office.php?view=customers&customer='+str(customer));check('&lt;script&gt;' in body and '<script>auto' not in body,'Customer data is HTML escaped')
            status,_=owner.form('save_vehicle',customer_id=customer,plate='1AB 1234',vin='WVWZZZ1JZXW000001',brand='Škoda',model='Octavia',mileage=150000);check(status==200,'Vehicle can be saved')
            vehicle=int(sql('SELECT id FROM abc_test.crm_vehicles LIMIT 1;'))
            status,_=owner.form('save_vehicle',customer_id=customer,plate='1AB1234',vin='',brand='',model='',mileage='');check(status==409,'Duplicate registration rejected')
            status,_=owner.form('save_catalog',description='Výměna oleje',category='Oleje a filtry',kind='labor',unit_price='500',unit_cost='0',active='1');check(status==200,'Catalog item saved')
            catalog=int(sql('SELECT id FROM abc_test.abc_quick_catalog LIMIT 1;'))
            status,data=owner.api('mechanic_api.php','quick_lookup',q='1AB');check(status==200 and len(data['vehicles'])==1,'Vehicle autocomplete searches persisted records')
            status,data=owner.api('mechanic_flow_api.php','create',{'plate':'9AB0001','vehicle':'Ford Focus','customer_name':'Nový kontakt','customer_phone':'700000009','services':['Diagnostika'],'save_vehicle':True});check(status==200,'Quick intake can create customer and vehicle atomically')
            quickid=int(data['id']);check(sql('SELECT COUNT(*) FROM abc_test.crm_vehicle_jobs WHERE job_id='+str(quickid))=='1','Quick intake links newly saved vehicle')
            status,_=owner.api('mechanic_flow_api.php','create',{'plate':'9AB0001','customer_name':'Duplicita','services':['Brzdy'],'save_vehicle':True});check(status==409,'Quick intake rejects duplicate stored vehicle')
            status,data=owner.request('vin_lookup.php?vin=WVWZZZ1JZXW000001');check(status==200 and data['found'],'VIN lookup uses stored vehicle')
            status,data=owner.api('mechanic_flow_api.php','create',{'vehicle_id':vehicle,'services':['Brzdy','Oleje a filtry'],'save_vehicle':False});check(status==200,'Walk-in job created from saved car')
            job=int(data['id']);check(sql('SELECT COUNT(*) FROM abc_test.crm_vehicle_jobs WHERE job_id='+str(job))=='1','Vehicle service history linked')
            check(sql('SELECT COUNT(*) FROM abc_test.office_appointments WHERE job_id='+str(job))=='0','Walk-in does not create calendar booking')
            status,detail=owner.api('mechanic_flow_api.php','info',id=job);check(len(detail['tasks'])==2 and detail['totals']['total']==0,'Requested services are unpriced tasks')
            tasks=detail['tasks'];lines=[{'task_id':int(tasks[0]['id']),'min_price':100,'max_price':150},{'task_id':int(tasks[1]['id']),'min_price':None,'max_price':None}]
            status,data=owner.api('mechanic_estimate_api.php','save',{'id':job,'lines':lines,'note':'Zkontrolovat díly','origin':'manual'});check(status==200,'Estimate with unknown items saved')
            quote=int(data['quote_id']);status,body=owner.request('mechanic_estimate_print.php?id='+str(quote));check(status==200 and 'Bude upřesněno' in body and 'nejsou v součtu zahrnuty' in body,'Estimate print discloses missing prices')
            check(sql('SELECT COUNT(*) FROM abc_test.payments')=='0' and sql('SELECT COUNT(*) FROM abc_test.office_invoices')=='0','Estimate does not create payment or invoice')
            status,_=owner.api('mechanic_estimate_api.php','save',{'id':job,'lines':lines[:1]});check(status==409,'Estimate cannot omit tasks')
            status,_=owner.api('mechanic_estimate_ai.php','estimate',{'id':job});check(status==503,'AI is disabled without configured API key')
            status,data=owner.api('mechanic_estimate_api.php','info',id=job);check(data['ai_available'] is False,'UI is told AI unavailable')
            status,_=owner.api('api.php','add_note',{'id':job,'body':'Zkontrolovány brzdy.'});check(status==200,'Work note saved')
            status,_=owner.api('api.php','add_request',{'id':job,'description':'Brzdové destičky','quantity':2});check(status==200,'Part request saved')
            status,detail=owner.api('mechanic_flow_api.php','info',id=job);check(len(detail['notes'])==1 and len(detail['requests'])==1,'Notes and parts remain visible after reload')
            status,_=owner.api('api.php','set_status',{'id':job,'status':'done'});check(status==200,'Job can be marked complete')
            status,_=owner.api('api.php','add_payment',{'id':job,'amount':100,'method':'cash'});check(status==409,'Payment rejected while tasks unpriced')
            for task,price in zip(tasks,[100,200]):
                status,_=owner.api('mechanic_flow_api.php','price',{'id':job,'task_id':int(task['id']),'unit_price':price});check(status==200,'Task pricing persisted '+str(task['id']))
            status,_=owner.api('mechanic_flow_api.php','add',{'id':job,'kind':'part','description':'Testovací materiál','category':'Ostatní','quantity':3,'unit_price':'12.34'});check(status==200,'Parts with quantity and price added')
            status,detail=owner.api('mechanic_flow_api.php','info',id=job);check(abs(detail['totals']['total']-337.02)<.001,'Totals use quantity and cents')
            status,_=owner.api('office_api.php','issue_invoice',{'job_id':job,'customer_name':'Test Zákazník','customer_address':'Testovací 1','due_days':14});check(status==200,'Invoice issued')
            invoice=int(sql('SELECT id FROM abc_test.office_invoices LIMIT 1;'))
            check(sql('SELECT COUNT(*) FROM abc_test.payments')=='0','Invoice is not recorded as money received')
            status,_=owner.api('office_api.php','issue_invoice',{'job_id':job,'customer_name':'Test','due_days':14});check(status==409,'Duplicate invoice rejected')
            status,_=owner.api('mechanic_flow_api.php','price',{'id':job,'task_id':int(tasks[0]['id']),'unit_price':500});check(status==409,'Invoiced price cannot be changed')
            status,_=owner.api('mechanic_flow_api.php','add',{'id':job,'kind':'labor','description':'Dodatečná práce','quantity':1});check(status==409,'Unpriced task cannot be added after invoice')
            status,_=owner.api('api.php','add_payment',{'id':job,'amount':100,'method':'cash'});check(status==200,'Partial cash payment recorded')
            status,detail=owner.api('mechanic_flow_api.php','info',id=job);check(abs(detail['totals']['due']-237.02)<.001,'Partial payment leaves correct balance')
            status,_=owner.api('api.php','add_payment',{'id':job,'amount':238,'method':'card'});check(status==409,'Overpayment rejected')
            other=Client(url);other.login('owner@example.test',ownerpass)
            def pay(client):return client.api('api.php','add_payment',{'id':job,'amount':'237.02','method':'transfer'})[0]
            with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:statuses=list(pool.map(pay,[owner,other]))
            check(sorted(statuses)==[200,409],'Concurrent full-balance payments cannot double charge')
            check(sql('SELECT SUM(amount) FROM abc_test.payments WHERE job_id='+str(job))=='337.02','Stored payments equal charged total')
            for path in ['office_document.php?invoice='+str(invoice),'mechanic_invoice.php?id='+str(invoice),'mechanic_receipt.php?payment=1']:
                status,body=owner.request(path);check(status==200 and 'Vytisknout' in body,'Printable financial document '+path.split('?')[0])
            status,_=owner.api('api.php','set_status',{'id':job,'status':'closed'});check(status==200,'Fully paid job can be closed')
            status,_=owner.api('api.php','add_note',{'id':job,'body':'Další změna'});check(status==409,'Closed job resists edits')
            from datetime import date,timedelta
            day=(date.today()+timedelta(days=2)).isoformat()
            booked={'plate':'2AB1234','customer_name':'Termín','services':['Pneuservis'],'date':day,'time':'10:00','duration':60}
            status,data=owner.api('mechanic_flow_api.php','create',booked);check(status==200 and data['scheduled'],'Scheduled job creates reservation')
            booking_job=int(data['id']);status,_=owner.api('mechanic_flow_api.php','create',{**booked,'plate':'3AB1234','time':'10:30'});check(status==409,'Mechanic booking collision rejected')
            status,data=owner.api('mechanic_api.php','calendar');check(len(data['appointments'])==1,'Rejected booking does not leave orphan appointment')
            status,_=owner.form('save_user',name='Mechanik Test',email='mechanic@example.test',password=mechanicpass,**{'permissions[]':['take_jobs']});check(status==200,'Mechanic account created')
            mechanicid=int(sql("SELECT id FROM abc_test.users WHERE email='mechanic@example.test'"))
            mechanic=Client(url);status,body=mechanic.login('mechanic@example.test',mechanicpass);check(status==200 and 'mech-app' in body,'Mechanic login opens workshop')
            status,_=mechanic.request('office.php');check(status==403,'Mechanic cannot open reception')
            status,_=mechanic.api('mechanic_flow_api.php','info',id=job);check(status==403,'Mechanic cannot open another user job')
            status,_=mechanic.api('mechanic_flow_api.php','price',{'id':job,'task_id':int(tasks[0]['id']),'unit_price':1});check(status==403,'Mechanic needs explicit price permission')
            status,_=owner.form('assign_job',id=booking_job,mechanic_id=mechanicid);check(status==200,'Reception assigns scheduled job to mechanic')
            status,_=owner.api('mechanic_flow_api.php','create',{**booked,'plate':'5AB0001','assigned_to':1});check(status==200,'Different mechanics can have simultaneous reservations')
            status,_=owner.api('mechanic_flow_api.php','create',{**booked,'plate':'6AB0001','assigned_to':mechanicid});check(status==409,'Selected mechanic collision is still rejected at intake')
            status,_=mechanic.api('mechanic_flow_api.php','create',{'plate':'7AB0001','services':['Brzdy'],'assigned_to':1});check(status==403,'Mechanic cannot bypass owner assignment permissions')
            status,detail=mechanic.api('mechanic_flow_api.php','info',id=booking_job);check(status==200 and not detail['permissions']['price'],'Assigned job is visible without financial authority')
            ownpayload={'plate':'4AB1234','customer_name':'Mechanikův zákazník','services':['Brzdy']}
            status,data=mechanic.api('mechanic_flow_api.php','create',ownpayload);check(status==200,'Mechanic may create own walk-in')
            ownjob=int(data['id']);status,_=mechanic.api('api.php','set_status',{'id':ownjob,'status':'done'});check(status==403,'Mechanic without pricing must submit for review')
            status,_=mechanic.api('api.php','set_status',{'id':ownjob,'status':'review'});check(status==200,'Mechanic submits completed work for review')
            status,_=owner.form('update_user',id=mechanicid,active='1',password='',**{'permissions[]':['price_jobs','collect_payments','print_receipts','take_jobs']});check(status==200,'Owner can grant mechanic permissions')
            status,detail=mechanic.api('mechanic_flow_api.php','info',id=ownjob);task=int(detail['tasks'][0]['id']);check(detail['permissions']['price'],'Permission changes take effect on existing session')
            status,_=mechanic.api('mechanic_flow_api.php','price',{'id':ownjob,'task_id':task,'unit_price':'250'});check(status==200,'Authorized mechanic can price')
            status,data=mechanic.api('api.php','get_job',id=ownjob);check(all('unit_cost' not in item for item in data['items']),'Mechanic financial API does not disclose purchase costs')
            mechanic.api('api.php','set_status',{'id':ownjob,'status':'done'})
            status,_=mechanic.api('api.php','add_payment',{'id':ownjob,'amount':'250','method':'cash'});check(status==200,'Authorized mechanic can collect cash')
            status,data=mechanic.api('api.php','handover_summary');check(len(data['pending'])==1,'Cash available for handover')
            status,_=mechanic.api('api.php','submit_handover',{'declared_amount':'200'});check(status==409,'Wrong handover amount rejected')
            status,data=mechanic.api('api.php','submit_handover',{'declared_amount':'250'});check(status==200,'Mechanic submits exact cash amount')
            status,_=owner.form('accept_handover',id=data['id']);check(status==200,'Owner confirms cash handover')
            check(sql('SELECT SUM(amount) FROM abc_test.payments')=='587.02','Cash handover does not duplicate revenue')
            status,data=owner.api('mechanic_flow_api.php','info',id=quickid);cancelid=int(data['tasks'][0]['id'])
            owner.api('mechanic_flow_api.php','price',{'id':quickid,'task_id':cancelid,'unit_price':'100'})
            status,_=owner.api('mechanic_api.php','quick_task_status',{'id':quickid,'task_id':cancelid,'status':'cancelled'});check(status==200,'Unbilled priced task can be cancelled')
            status,data=owner.api('mechanic_flow_api.php','info',id=quickid);check(data['totals']['total']==0,'Cancellation removes item from bill')
            status,_=owner.api('mechanic_api.php','quick_task_status',{'id':quickid,'task_id':cancelid,'status':'planned'});check(status==409,'Cancelled bill item cannot silently reappear')
            newpass=secrets.token_hex(12)
            status,_=owner.form('update_user',id=mechanicid,active='1',password=newpass);check(status==200,'Owner can reset mechanic password')
            status,_=mechanic.api('api.php','list_jobs');check(status==401,'Password reset revokes existing mechanic session')
            status,_=mechanic.login('mechanic@example.test',newpass);check(status==200,'Mechanic can log in with reset password')
            status,_=owner.form('update_user',id=mechanicid,password='');check(status==200,'Mechanic account can be deactivated')
            status,_=mechanic.api('api.php','list_jobs');check(status==401,'Deactivated account immediately loses API access')
            check(sql("SELECT COUNT(*) FROM abc_test.jobs WHERE plate='3AB1234'")=='0','Failed reservation transaction leaves no job')
            web_log.flush();web_log.seek(0);logs=web_log.read()
            check(not any(x in logs for x in ['PHP Warning','PHP Fatal error','PHP Parse error']),'No PHP warnings or fatal errors in tested flows')
            print(json.dumps({'passed':len(checks),'checks':checks},ensure_ascii=False,indent=2),flush=True)
        finally:
            if sys.exc_info()[0] is not None and 'web_log' in locals():
                web_log.flush();web_log.seek(0);print(web_log.read()[-6000:],flush=True)
            if webproc is not None:
                with contextlib.suppress(ProcessLookupError):os.killpg(webproc.pid,signal.SIGTERM)
                with contextlib.suppress(subprocess.TimeoutExpired):webproc.wait(timeout=10)
            if dbproc is not None:
                dbproc.terminate()
                with contextlib.suppress(subprocess.TimeoutExpired):dbproc.wait(timeout=10)

if __name__=='__main__':run()
