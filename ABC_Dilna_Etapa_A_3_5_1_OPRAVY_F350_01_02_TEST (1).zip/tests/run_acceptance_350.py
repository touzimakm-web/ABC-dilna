"""Run and collect actual 3.5 acceptance suites. Never uses production configuration."""
from pathlib import Path
import argparse,json,os,subprocess,sys
ROOT=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser();parser.add_argument('--suite',action='append',choices=['catalog','review331','phase','core','a12','fronta','saas','security']);parser.add_argument('--wedos',action='store_true');parser.add_argument('--no-browser',action='store_true');args=parser.parse_args()
env=os.environ.copy();env['ABC_TEST_BROWSER']='0' if args.no_browser else '1'
if args.wedos:env['ABC_TEST_WEDOS_REWRITE']='1'
suffix='-wedos' if env.get('ABC_TEST_WEDOS_REWRITE')=='1' else '';out=ROOT/'tests/evidence/350';out.mkdir(parents=True,exist_ok=True)
suites={
 'catalog':('catalog_documents_integration.py','tests/evidence/350/results'+suffix+'.json'),
 'review331':('review_331_integration.py','tests/evidence/340/regression331/results'+suffix+'.json'),
 'phase':('phase_a_integration.py','tests/evidence/a6/results'+suffix+'.json'),
 'core':('integration.py','tests/evidence/results'+suffix+'.json'),
 'a12':('a12_integration.py','tests/evidence/a12/results'+suffix+'.json'),
 'fronta':('operations_v2_integration.py','tests/evidence/340/results'+suffix+'.json'),
 'saas':('saas_integration.py','tests/evidence/350/saas-results'+suffix+'.json'),
 'security':('security_and_estimates.py','tests/evidence/security-estimates.json')}
for name in args.suite or suites:
 file,source=suites[name];log=out/('run-'+name+suffix+'.log');print('RUN',name,flush=True)
 with log.open('w') as f:r=subprocess.run([sys.executable,str(ROOT/'tests'/file)],cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
 if r.returncode:print(log.read_text()[-8000:]);raise SystemExit(r.returncode)
 data=json.loads((ROOT/source).read_text());data['tested_release']='3.5.0';dest=out/('collected-'+name+suffix+'.json');dest.write_text(json.dumps(data,ensure_ascii=False,indent=2));print('PASS',name,data['passed'],flush=True)
