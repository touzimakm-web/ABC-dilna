<?php
declare(strict_types=1);
// Reprodukuje rozdíl veřejné URL a interního SCRIPT_NAME na WEDOSu.
$_SERVER['SCRIPT_NAME']='/domains/dilna.abcautosluzby.cz/nova/setup.php';
$_SERVER['REQUEST_URI']='/nova/setup.php';
require dirname(__DIR__).'/app/bootstrap.php';
$cases=[
    ['/','/'],
    ['/index.php','/'],
    ['/index.php?next=/nova/setup.php','/'],
    ['/nova/','/nova/'],
    ['/nova/setup.php','/nova/'],
    ['/nova/api.php?action=add_payment','/nova/'],
    ['/servis/nova/index.php?next=/office.php','/servis/nova/'],
    ['https://dilna.abcautosluzby.cz/nova/index.php','/nova/'],
    ['','/'],
    ["/nova/\r\ninvalid.php",'/'],
    ['/nova;unsafe/index.php','/'],
    ['/nova\\unsafe/index.php','/'],
];
foreach($cases as [$input,$expected]){
    $actual=abc_cookie_path($input);
    if($actual!==$expected){fwrite(STDERR,'Cookie scope regression: '.json_encode($input).' => '.json_encode($actual).PHP_EOL);exit(1);}
}
if(session_get_cookie_params()['path']!=='/nova/'){
    fwrite(STDERR,'Bootstrap uses an internal path for the cookie.'.PHP_EOL);exit(1);
}
echo json_encode(['passed'=>count($cases)+1,'wedos_cookie_path'=>session_get_cookie_params()['path']]).PHP_EOL;
