"""Mobile F350 acceptance: real browser, forms, revisions and persistent DB rows."""
import re,secrets
from playwright.sync_api import sync_playwright,expect
from runtime import ROOT,Client

def run_browser(r,check,ctx):
    out=ROOT/('tests/evidence/351/browser-wedos' if r.prefix else 'tests/evidence/351/browser');out.mkdir(parents=True,exist_ok=True)
    call,info=ctx['call'],ctx['info'];rate=ctx['catalog']('Mobilní práce / F350',price=950);part=ctx['catalog']('Mobilní filtr bez ceny','part','ks','')
    ctx['bind']('oil-change',rate);ctx['bind']('oil-filter',part);ctx['bind']('brakes-front-pads',part,1)
    password=secrets.token_hex(12)
    assert r.owner.form('save_user',name='Mechanik F350',email='mechanik@351.test',password=password,permissions=['create_jobs','edit_jobs','edit_lines','change_status','price_jobs','issue_invoices','collect_payments','view_documents','print_documents'],rights_version=2)[0]==200
    w=Client(r.url);assert w.login('mechanik@351.test',password)[0]==200
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
        mobile=browser.new_context(viewport={'width':412,'height':820},is_mobile=True,has_touch=True,locale='cs-CZ');phone=mobile.new_page();errors=[]
        phone.on('pageerror',lambda e:errors.append(str(e)));phone.on('dialog',lambda d:d.accept())
        def goto(path,page=phone):page.goto(r.url+'/'+path);page.wait_for_load_state('networkidle')
        def login(page=phone):
            goto('index.php',page);page.get_by_label('E-mail',exact=True).fill('mechanik@351.test');page.get_by_label('Heslo',exact=True).fill(password);page.get_by_role('button',name=re.compile('^Přihlásit se')).click();page.wait_for_load_state('networkidle')
        def saved_job():phone.wait_for_url(re.compile(r'mechanic.php\?saved=\d+'));return int(phone.url.rsplit('=',1)[1])
        login();goto('mechanic_work.php');phone.locator('#find').fill('MOBILE351');phone.locator('[data-service="Oleje a filtry"]').click();phone.locator('[data-manual-code="oil-change"]').click()
        check(phone.locator('[data-manual-quantity="oil-change:0"]').input_value()=='','Browser F350-01 A: selecting hourly service leaves hours blank on mobile')
        phone.locator('[data-action="create"]').click();j=saved_job();goto('mechanic_work.php?job='+str(j));t=next(t for t in info(j)['tasks'] if t['entry_type']=='work');tid=t['id'];row=phone.locator('[data-line-id="'+str(tid)+'"]')
        expect(row).to_contain_text('Hodiny doplnit');expect(phone.locator('#checkout')).to_contain_text('Cena neúplná')
        check('950' in row.inner_text() and info(j)['tasks'][-1]['quantity'] is None,'Browser F350-01 A: actual saved red M02 row shows rate and missing hours, not zero amount')
        phone.screenshot(path=str(out/'01-hodiny-doplnit.png'),full_page=True)
        goto('mechanic.php');goto('mechanic_work.php?job='+str(j));phone.reload();phone.wait_for_load_state('networkidle');row=phone.locator('[data-line-id="'+str(tid)+'"]');expect(row).to_contain_text('Hodiny doplnit');row.locator('[data-edit-line]').click()
        check(row.locator('[data-line-field="quantity"]').input_value()=='','Browser F350-01 D: navigation and reload restore empty hours from actual DB')
        # Another real logged-in editor changes the same row while mechanic types hours.
        row.locator('[data-line-field="quantity"]').fill('1.5');latest=next(t for t in info(j)['tasks'] if t['id']==tid)
        call('mechanic_flow_api.php','update_line',{'id':j,'task_id':tid,'revision':latest['revision'],'description':'Kolega upravil popis','quantity':'','unit':'hod','unit_price':950})
        row.locator('[data-save-line]').click();expect(phone.locator('#work-notice')).to_contain_text('mezitím')
        check(row.locator('[data-line-field="quantity"]').input_value()=='1.5','Browser F350-01: concurrent edit conflict preserves mechanic typed hours')
        phone.reload();phone.wait_for_load_state('networkidle');row=phone.locator('[data-line-id="'+str(tid)+'"]');expect(row.locator('[data-rebase-line]')).to_be_visible();check(row.locator('[data-line-field="quantity"]').input_value()=='1.5','Browser F350-01: unsaved hours and conflict comparison survive page reload')
        row.locator('[data-rebase-line]').click();row.locator('[data-save-line]').click();expect(phone.locator('#work-notice')).to_contain_text('uložena')
        latest=next(t for t in info(j)['tasks'] if t['id']==tid)
        check(latest['id']==tid and float(latest['quantity'])==1.5 and info(j)['totals']['estimated_total']==1425 and latest['price_origin']=='catalog','Browser F350-01 C: explicit conflict resolution saves same row at 1.5 x 950 = 1425')
        phone.screenshot(path=str(out/'02-hodiny-doplneny.png'),full_page=True)
        for width in [360,412]:
            phone.set_viewport_size({'width':width,'height':820});check(phone.evaluate('document.documentElement.scrollWidth<=innerWidth'),'Browser mobile M02 has no horizontal overflow at '+str(width)+' px')
        row.locator('[data-line-done]').click();expect(row).to_have_class(re.compile('m02-done'))
        phone.locator('[data-action="finish"]').click();expect(phone.locator('[data-checkout="invoice"]')).to_be_visible();phone.locator('[data-checkout="invoice"]').click();phone.locator('#invoice-name').fill('Mobilní zákazník');phone.locator('#invoice-address').fill('Testovací adresa');phone.locator('[data-action="invoice"]').click();expect(phone.locator('a[href^="office_document.php?invoice="]')).to_be_visible()
        billed=info(j);check(billed['invoice'] is not None and billed['totals']['total']==1425 and billed['totals']['paid']==0,'Browser F350-01 E: complete mobile workflow issues actual unpaid 1425 CZK invoice')
        # Existing job: no hours required when choosing a planned task.
        existing=call('mechanic_flow_api.php','create',{'plate':'BEXIST351','services':['Brzdy']},c=w)['id'];goto('mechanic_work.php?job='+str(existing));phone.locator('#manual-plan summary').click();phone.locator('[data-manual-category="Oleje a filtry"]').click();phone.locator('[data-manual-code="oil-change"]').click();phone.locator('[data-action="manual-confirm"]').click();expect(phone.locator('#work-notice')).to_contain_text('uložený')
        check(next(t for t in info(existing)['tasks'] if t['entry_type']=='work')['quantity'] is None,'Browser F350-01 B: existing card accepts selected hourly work without hours')
        et=next(t for t in info(existing)['tasks'] if t['entry_type']=='work');phone.locator('[data-line-done="'+str(et['id'])+'"]').click();phone.locator('[data-action="finish"]').click();expect(phone.locator('#checkout')).to_contain_text('Hodiny doplnit')
        check(phone.locator('[data-checkout]').count()==0 and phone.locator('[data-action="close"]').count()==0,'Browser F350-01 E: unknown hours never offer payment, invoice or zero-price closure')
        # Active unpriced remains clickable; old draft becomes invalid during concurrent deactivation.
        goto('mechanic_work.php');phone.locator('#find').fill('DRAFT351');phone.locator('[data-service="Oleje a filtry"]').click();phone.locator('#car-details summary').click();phone.locator('[data-field="customer_name"]').fill('Rozepsaný zákazník');phone.locator('[data-field="customer_phone"]').fill('777123456');phone.locator('[data-field="requested"]').fill('Zachovat celou poznámku')
        button=phone.locator('[data-manual-code="oil-filter"]');check(button.is_enabled(),'Browser F350-02 A: active catalog item with unknown price stays selectable');button.click();expect(phone.locator('.manual-preview')).to_contain_text('Nenaceněno');phone.locator('[data-manual-code="oil-change"]').click();phone.locator('[data-manual-quantity="oil-change:0"]').fill('2.25')
        count=r.sql('SELECT COUNT(*) FROM abc_test.jobs');ctx['edit'](part,active=0);phone.locator('[data-action="create"]').click();expect(phone.locator('#work-notice')).to_contain_text('není dostupná')
        check(r.sql('SELECT COUNT(*) FROM abc_test.jobs')==count and phone.locator('#find').input_value()=='DRAFT351' and phone.locator('[data-field="requested"]').input_value()=='Zachovat celou poznámku','Browser F350-02 C: stale draft fails atomically and keeps plate and notes')
        phone.reload();phone.wait_for_load_state('networkidle');check(phone.locator('[data-manual-quantity="oil-change:0"]').input_value()=='2.25' and phone.locator('[data-field="customer_phone"]').input_value()=='777123456' and phone.locator('[data-manual-code="oil-filter"]').get_attribute('aria-pressed')=='true','Browser F350-02 C: reload preserves selected inactive part, explicit hours, customer and contact')
        phone.locator('[data-action="manual-refresh"]').click();expect(phone.locator('.manual-preview').filter(has_text='Mobilní filtr')).to_contain_text('neaktivní')
        check(phone.locator('[data-manual-quantity="oil-change:0"]').input_value()=='2.25','Browser F350-02 C: explicit template refresh exposes inactive selection without dropping other edits')
        phone.screenshot(path=str(out/'03-stary-vyber-zachovan.png'),full_page=True)
        # Independent new browser tab has no stored draft and sees disabled cards from first render.
        freshctx=browser.new_context(viewport={'width':360,'height':800},is_mobile=True,has_touch=True,locale='cs-CZ');fresh=freshctx.new_page();login(fresh);goto('mechanic_work.php',fresh);fresh.locator('[data-service="Oleje a filtry"]').click();inactive=fresh.locator('[data-manual-code="oil-filter"]');expect(inactive).to_be_disabled();expect(inactive).to_contain_text('Neaktivní položka ceníku')
        check('znovu propojit' in fresh.locator('#manual-plan').inner_text() and fresh.locator('[data-manual-code="air-filter"]').is_enabled(),'Browser F350-02 B: fresh inactive selection is disabled with remedy while ordinary unpriced service stays available')
        fresh.locator('[data-manual-category="Brzdy"]').click();expect(fresh.locator('[data-manual-code="brakes-front-pads"]')).to_be_disabled();check(fresh.locator('[data-manual-code="brakes-front-discs"]').is_enabled(),'Browser F350-02 B: one inactive bound row disables the entire composite card, other repairs stay usable')
        check(fresh.evaluate('document.documentElement.scrollWidth<=innerWidth'),'Browser F350-02: inactive selection and its explanation fit 360 px without horizontal overflow')
        fresh.screenshot(path=str(out/'04-neaktivni-karta.png'),full_page=True);freshctx.close()
        phone.locator('[data-manual-code="oil-filter"]').click();phone.locator('[data-action="create"]').click();clean=saved_job();tasks=[t for t in info(clean)['tasks'] if t['entry_type']=='work']
        check(len(tasks)==1 and float(tasks[0]['quantity'])==2.25 and info(clean)['job']['customer_phone']=='777123456','Browser F350-02 B/C: explicit removal of unavailable choice saves the rest of intake unchanged')
        check(not errors,'Browser F350: no uncaught JavaScript errors during both repaired workflows');browser.close()
