"""Actual M02 card in mobile Chromium; real owner/worker concurrent edits and lost reply."""
import re,json,secrets
from pathlib import Path
from runtime import ROOT
from playwright.sync_api import sync_playwright,expect

def run_browser(r,check):
 evidence=ROOT/('tests/evidence/a12/wedos' if r.prefix else 'tests/evidence/a12/browser');evidence.mkdir(parents=True,exist_ok=True)
 o=r.owner;pw=secrets.token_hex(12);o.form('save_user',name='Kozel',email='a12browser@example.test',password=pw,permissions=['price_jobs','collect_payments','issue_invoices','print_receipts'])
 with sync_playwright() as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage']);phone=browser.new_context(viewport={'width':360,'height':800},is_mobile=True,has_touch=True,locale='cs-CZ',timezone_id='Europe/Prague');desk=browser.new_context(viewport={'width':1440,'height':1000},locale='cs-CZ');page=phone.new_page();office=desk.new_page();errors=[]
  for pg in [page,office]:pg.on('pageerror',lambda e:errors.append(str(e)));pg.on('dialog',lambda d:d.accept())
  def login(pg,email,password):
   pg.goto(r.url+'/index.php');pg.get_by_label('E-mail',exact=True).fill(email);pg.get_by_label('Heslo',exact=True).fill(password);pg.get_by_role('button',name=re.compile('^Přihlásit se')).click();pg.wait_for_url(re.compile(r'(mechanic|office)\.php'));pg.wait_for_load_state('networkidle')
  def act(selector,pg=page):pg.locator(selector).click();pg.wait_for_load_state('networkidle')
  login(page,'a12browser@example.test',pw);login(office,'owner@example.test',r.ownerpass)
  page.get_by_role('link',name='RYCHLÁ ZAKÁZKA',exact=True).click();page.wait_for_load_state('networkidle');page.locator('#find').fill('8AA1212')
  for s in ['Brzdy','Oleje a filtry','Pneuservis']:page.get_by_role('button',name=s,exact=True).click()
  page.get_by_role('button',name='ULOŽIT RYCHLOU ZAKÁZKU',exact=True).click();page.wait_for_url(re.compile('mechanic.php\\?saved=\\d+'));page.wait_for_load_state('networkidle');jid=int(page.url.rsplit('=',1)[1])
  check(page.locator('.garage-today').inner_text().find('8AA1212')>=0,'Browser: unscheduled intake is in today work list')
  check(r.sql('SELECT COUNT(*) FROM abc_test.office_appointments WHERE job_id='+str(jid))=='0','Browser: today work list creates no invented calendar slot')
  page.goto(r.url+'/mechanic_work.php?job='+str(jid));page.wait_for_load_state('networkidle')
  def add(desc,kind,qty,unit,price):
   act('[data-action="entry"]');act('[data-kind="'+kind+'"]');page.locator('#entry-text').fill(desc);page.locator('#entry-quantity').fill(qty);page.locator('#entry-unit').select_option(unit);page.locator('#entry-price').fill(price);act('[data-action="add"]');expect(page.locator('.m02-line').filter(has_text=desc)).to_be_visible();return int(page.locator('.m02-line').filter(has_text=desc).get_attribute('data-line-id'))
  labor=add('Vymena oleje','labor','1','hod','500');oil=add('Olej 10W40','part','5','l','100');filtr=add('Olejovy filtr','part','1','ks','150');unused=add('Nepouzity sprej','part','2','ks','200')
  check(page.locator('.m02-labor').count()==1 and page.locator('.m02-part').count()==3,'Browser: approved red work and blue material rows retained')
  check(page.locator('[data-material]:checked').count()==0,'Browser: no material is preselected as actually used')
  act('[data-edit-line="'+str(oil)+'"]');card=page.locator('[data-line-id="'+str(oil)+'"]');card.locator('[data-line-field="quantity"]').fill('5,5');card.locator('[data-save-line]').click();expect(page.locator('#work-notice')).to_have_text('Položka uložena.')
  check(r.sql('SELECT quantity FROM abc_test.abc_quick_tasks WHERE id='+str(oil))=='5.500','Browser: Czech decimal comma saved as real fractional liters')
  # Draft survives switching rows and refreshing the actual page.
  act('[data-edit-line="'+str(oil)+'"]');page.locator('[data-line-field="quantity"]').fill('8');act('[data-edit-line="'+str(labor)+'"]');act('[data-close-line="'+str(labor)+'"]');act('[data-edit-line="'+str(oil)+'"]');check(page.locator('[data-line-field="quantity"]').input_value()=='8','Browser: switching row editors preserves unsaved quantity')
  page.reload();page.wait_for_load_state('networkidle');check(page.locator('[data-line-field="quantity"]').input_value()=='8','Browser: unsaved card draft survives refresh')
  # An independent desktop user changes the same real row.
  office.goto(r.url+'/mechanic_work.php?job='+str(jid));office.wait_for_load_state('networkidle');act('[data-edit-line="'+str(oil)+'"]',office);office.locator('[data-line-field="quantity"]').fill('6');office.locator('[data-line-field="note"]').fill('Poznamka kancelare');act('[data-save-line="'+str(oil)+'"]',office)
  act('[data-save-line="'+str(oil)+'"]');expect(page.locator('.m02-conflict')).to_be_visible();check(page.locator('[data-line-field="quantity"]').input_value()=='8' and r.sql('SELECT quantity FROM abc_test.abc_quick_tasks WHERE id='+str(oil))=='6.000','Browser: conflict keeps own draft and does not overwrite office change')
  page.screenshot(path=str(evidence/'konflikt-360.png'),full_page=True)
  act('[data-rebase-line="'+str(oil)+'"]');check(page.locator('[data-line-field="quantity"]').input_value()=='8' and page.locator('[data-line-field="note"]').input_value()=='Poznamka kancelare','Browser: explicit conflict merge keeps own changed field and unrelated office note')
  act('[data-save-line="'+str(oil)+'"]');expect(page.locator('#work-notice')).to_have_text('Položka uložena.')
  # Drop the response only after the server really committed the update.
  act('[data-edit-line="'+str(oil)+'"]');page.locator('[data-line-field="quantity"]').fill('5');before=int(r.sql("SELECT COUNT(*) FROM abc_test.events WHERE job_id="+str(jid)+" AND action='flow_line_update'"));captured=[]
  def drop_reply(route):
   payload=route.request.post_data_json
   if route.request.method=='POST' and payload.get('task_id')==oil and not captured:
    captured.append(payload);response=route.fetch();assert response.status==200;route.abort('failed')
   else:route.continue_()
  page.route('**/mechanic_flow_api.php?action=update_line',drop_reply);act('[data-save-line="'+str(oil)+'"]');expect(page.locator('#work-notice')).to_contain_text('Spojení se přerušilo');check(page.locator('[data-line-field="quantity"]').input_value()=='5','Browser: dropped save response retains typed row data')
  check(r.sql('SELECT quantity FROM abc_test.abc_quick_tasks WHERE id='+str(oil))=='5.000','Browser: dropped reply scenario really committed on server before disconnect')
  page.unroute('**/mechanic_flow_api.php?action=update_line',drop_reply);page.reload();page.wait_for_load_state('networkidle');expect(page.locator('[data-save-line="'+str(oil)+'"]')).to_have_text('Ověřit uložení');act('[data-save-line="'+str(oil)+'"]');expect(page.locator('#work-notice')).to_have_text('Položka uložena.')
  check(int(r.sql("SELECT COUNT(*) FROM abc_test.events WHERE job_id="+str(jid)+" AND action='flow_line_update'"))==before+1,'Browser: retry after lost response reuses operation key and creates one actual update')
  # Clearing and restoring a price works through the exact inline editor.
  act('[data-edit-line="'+str(oil)+'"]');page.locator('[data-line-field="unit_price"]').fill('');act('[data-save-line="'+str(oil)+'"]');expect(page.locator('[data-line-id="'+str(oil)+'"]')).to_contain_text('Nenaceněno');check(r.sql('SELECT unit_price FROM abc_test.items i JOIN abc_test.abc_quick_tasks t ON t.item_id=i.id WHERE t.id='+str(oil))=='NULL','Browser: clearing sale price stores unknown, not false zero')
  act('[data-edit-line="'+str(oil)+'"]');page.locator('[data-line-field="unit_price"]').fill('100');act('[data-save-line="'+str(oil)+'"]')
  # Confirm only actually used material together. The unused spray remains planned.
  page.locator('[data-material="'+str(oil)+'"]').check();page.locator('[data-material="'+str(filtr)+'"]').check();act('[data-action="materials"]')
  check(r.sql('SELECT status FROM abc_test.abc_quick_tasks WHERE id='+str(unused))=='planned' and r.sql('SELECT status FROM abc_test.abc_quick_tasks WHERE id='+str(oil))=='done','Browser: bulk confirms selected actual material and leaves unused item planned')
  act('[data-line-done="'+str(labor)+'"]');act('[data-action="finish"]');check(r.sql('SELECT status FROM abc_test.jobs WHERE id='+str(jid))=='done','Browser: repair can finish with selected used material')
  act('[data-action="parts"]');check(r.sql('SELECT status FROM abc_test.jobs WHERE id='+str(jid))=='parts','Browser: Hotovo visibly reopens to waiting for parts');act('[data-action="start"]');act('[data-action="finish"]')
  extra=add('Dalsi kontrola po telefonatu','labor','1','hod','100');check(r.sql('SELECT status FROM abc_test.jobs WHERE id='+str(jid))=='work','Browser: new unfinished task visibly reopens same completed repair')
  act('[data-line-done="'+str(extra)+'"]');act('[data-action="finish"]')
  for width in [320,360,412]:page.set_viewport_size({'width':width,'height':850});check(page.evaluate('document.documentElement.scrollWidth<=innerWidth'),'Browser: card fits '+str(width)+'px without horizontal overflow')
  page.set_viewport_size({'width':360,'height':850});page.screenshot(path=str(evidence/'pracovni-karta-360.png'),full_page=True)
  act('[data-checkout="invoice"]');page.locator('#invoice-name').fill('Puvodni odberatel');page.locator('#invoice-address').fill('Puvodni adresa 1');act('[data-action="invoice"]')
  inv=int(r.sql('SELECT id FROM abc_test.office_invoices WHERE job_id='+str(jid)));check(r.sql('SELECT COUNT(*) FROM abc_test.payments WHERE job_id='+str(jid))=='0','Browser: issuing actual document does not invent payment')
  doc=desk.new_page();doc.goto(r.url+'/office_document.php?invoice='+str(inv));before_html=doc.content();doc.pdf(path=str(evidence/'faktura.pdf'),format='A4');check('Nepouzity sprej' not in before_html and '1 250,00 Kč' in before_html,'Browser: immutable invoice excludes unused planned item and shows correct total')
  # Even after issue, live vehicle/customer remain editable inside the same card.
  page.locator('#live-identity summary').click();page.locator('[data-identity-field="vin"]').fill('WVWZZZ1JZXW000002');page.locator('[data-identity-field="mileage"]').fill('234567');page.locator('[data-identity-field="phone"]').fill('700000999');act('[data-action="identity"]');expect(page.locator('#work-notice')).to_contain_text('Živá evidence uložena')
  doc.reload();check(doc.content()==before_html,'Browser: live VIN phone and mileage changes cannot rewrite issued invoice')
  check(page.locator('[data-edit-line]').count()==0 and page.locator('#live-identity').count()==1,'Browser: issued financial rows lock while live identity stays available')
  act('[data-checkout="cash"]');page.locator('#payment-amount').fill('100');act('[data-action="pay"]');check(r.sql('SELECT SUM(amount) FROM abc_test.payments WHERE job_id='+str(jid))=='100.00','Browser: partial actual cash receipt persists correctly')
  page.screenshot(path=str(evidence/'doklad-a-ziva-evidence-360.png'),full_page=True)
  check(not errors,'Browser: no uncaught JavaScript errors during M02 edits conflicts or lost replies');browser.close()
