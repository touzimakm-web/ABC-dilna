"""Real HTTP multipart / binary helpers; fixture is an actual single-page PDF."""
import secrets,json,urllib.request,urllib.error,base64,hashlib

def pdf(text='SIGNED TEST'):
 objects=[b'<< /Type /Catalog /Pages 2 0 R >>',b'<< /Type /Pages /Kids [3 0 R] /Count 1 >>',b'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>',b'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>']
 stream=('BT /F1 16 Tf 50 790 Td ('+text.replace('(','').replace(')','')+') Tj ET').encode('ascii');objects.append(b'<< /Length '+str(len(stream)).encode()+b' >>\nstream\n'+stream+b'\nendstream');raw=b'%PDF-1.4\n';offsets=[0]
 for i,obj in enumerate(objects,1):offsets.append(len(raw));raw+=str(i).encode()+b' 0 obj\n'+obj+b'\nendobj\n'
 start=len(raw);raw+=b'xref\n0 6\n0000000000 65535 f \n'+b''.join(('%010d 00000 n \n'%n).encode() for n in offsets[1:])+b'trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n'+str(start).encode()+b'\n%%EOF\n';return raw

def binary(client,path,body=None,headers=None):
 try:
  with client.opener.open(urllib.request.Request(client.url+'/'+path,data=body,headers=headers or {}),timeout=30) as response:return response.status,response.read(),dict(response.headers)
 except urllib.error.HTTPError as response:return response.code,response.read(),dict(response.headers)

def upload(client,action,fields,files=None,csrf=True):
 boundary='abc350'+secrets.token_hex(16);chunks=[]
 for name,value in fields.items():chunks.append(('--'+boundary+'\r\nContent-Disposition: form-data; name="'+name+'"\r\n\r\n'+str(value)+'\r\n').encode())
 for name,(filename,data,mime) in (files or {}).items():chunks.append(('--'+boundary+'\r\nContent-Disposition: form-data; name="'+name+'"; filename="'+filename+'"\r\nContent-Type: '+mime+'\r\n\r\n').encode()+data+b'\r\n')
 body=b''.join(chunks)+('--'+boundary+'--\r\n').encode();headers={'Content-Type':'multipart/form-data; boundary='+boundary}
 if csrf:headers['X-CSRF-Token']=client.csrf
 s,raw,h=binary(client,'documents_api.php?action='+action,body,headers);return s,json.loads(raw),h

def run_tenant_isolation(r,a,b,check):
 """Two actual SaaS DB connections with deliberately identical catalog/document IDs."""
 created={};blobs={}
 for label,client,rate in [('alfa',a,950),('beta',b,1250)]:
  status,cat=client.api('catalog_api.php','save',{'description':'Výměna oleje','category':'Oleje a filtry','kind':'labor','unit':'hod','unit_price':rate,'active':1,'request_key':secrets.token_hex(20)});assert status==200,cat;cid=cat['id']
  settings=client.api('phase_a_api.php','settings')[1]['settings'];status,res=client.api('catalog_api.php','bind_template',{'revision':settings['revision'],'template_code':'oil-change','row_index':0,'catalog_id':cid,'request_key':secrets.token_hex(20)});assert status==200,res
  settings=client.api('phase_a_api.php','settings')[1]['settings'];status,job=client.api('mechanic_flow_api.php','create',{'plate':'PRICED'+label.upper(),'services':['Oleje a filtry'],'manual_plan':{'revision':settings['revision'],'codes':['oil-change'],'quantities':{'oil-change':{'0':'1.5'}},'catalog_revisions':{str(cid):1}},'request_key':secrets.token_hex(20)});assert status==200,job
  created[label]=(cid,job['id']);data=pdf('SIGNED '+label.upper());status,doc,_=upload(client,'save',{'job_id':job['id'],'title':'Plná moc '+label,'category':'attachment','active':1,'request_key':secrets.token_hex(20)},{'pdf':(label+'.pdf',data,'application/pdf')});assert status==200,doc;blobs[label]=(doc['id'],data)
 check(created['alfa'][0]==created['beta'][0] and r.sql('SELECT unit_price FROM saas_alfa.abc_quick_catalog WHERE id='+str(created['alfa'][0]))=='950.00' and r.sql('SELECT unit_price FROM saas_beta.abc_quick_catalog WHERE id='+str(created['beta'][0]))=='1250.00','350-01: same clicked oil card and catalog ID use independent real rates in two garages')
 check(a.api('mechanic_flow_api.php','info',id=created['alfa'][1])[1]['totals']['estimated_total']==1425 and b.api('mechanic_flow_api.php','info',id=created['beta'][1])[1]['totals']['estimated_total']==1875,'350-01: explicit 1.5 hours calculate only each authenticated tenant own price')
 check(blobs['alfa'][0]==blobs['beta'][0] and binary(a,'document_file.php?id='+str(blobs['alfa'][0])+'&tenant_id=2')[1]==blobs['alfa'][1] and binary(b,'document_file.php?id='+str(blobs['alfa'][0]))[1]==blobs['beta'][1],'350-08: same document ID and forged tenant_id never return another garage signed PDF')
 check('Dodavatel není plátcem DPH.' in a.request('catalog_print.php')[1] and 'Konečné ceny včetně DPH 21 %.' in b.request('catalog_print.php')[1],'350-06: generated price list follows each tenant own verified non-VAT or VAT 21 percent setting')
 export=a.request('tenant_export.php')[1];payload=json.loads(export) if isinstance(export,str) else export
 documents=payload['tables']['abc_document_versions'];check(all('pdf_bytes_base64' in row and 'pdf_bytes' not in row and base64.b64decode(row['pdf_bytes_base64'])==blobs['alfa'][1] and hashlib.sha256(base64.b64decode(row['pdf_bytes_base64'])).hexdigest()==row['sha256'] for row in documents),'350-backup: authenticated garage export includes exact binary PDF versions as base64, not broken raw JSON')
