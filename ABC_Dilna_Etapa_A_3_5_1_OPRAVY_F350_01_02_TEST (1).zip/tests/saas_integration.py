"""Real separated MariaDB databases, HTTP sessions and Chromium for SaaS 3.1."""
from runtime import Runtime,Client,ROOT,PHP,INI,port
import os,secrets,subprocess,time,re,json,urllib.error,concurrent.futures
checks=[]
def check(v,label):
 if not v:raise AssertionError(label)
 checks.append(label);print('OK '+label,flush=True)
def key():return secrets.token_hex(20)
def post(c,action,**fields):return c.request('platform.php',{'csrf':c.csrf,'action':action,**fields})
def browser(r,url,passwords,check):
 from playwright.sync_api import sync_playwright,expect
 evidence=ROOT/('tests/evidence/saas-wedos' if r.prefix else 'tests/evidence/saas');evidence.mkdir(parents=True,exist_ok=True)
 with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage']);errors=[]
  a=b.new_context(viewport={'width':360,'height':800},is_mobile=True,has_touch=True,locale='cs-CZ');z=b.new_context(viewport={'width':1440,'height':1000},locale='cs-CZ');op=b.new_context(viewport={'width':1440,'height':1000})
  def login(ctx,slug,pw,email="same@example.test"):
   pg=ctx.new_page();pg.on('pageerror',lambda e:errors.append(str(e)));pg.goto(url+'/index.php');pg.get_by_label('Kód vašeho servisu').fill(slug);pg.get_by_role('button',name='Pokračovat k přihlášení').click();pg.get_by_label('E-mail',exact=True).fill(email);pg.get_by_label('Heslo',exact=True).fill(pw);pg.get_by_role('button',name=re.compile('^Přihlásit se')).click();pg.wait_for_url(re.compile(r'(office|mechanic)\.php'));pg.wait_for_load_state('networkidle');return pg
  pa=login(a,'servis-alfa',passwords['alfa'],'mechanic@example.test');pb=login(z,'servis-beta',passwords['beta'])
  check('Alfa Autoservis' in pa.content() and 'Beta Autoservis' not in pa.content(),'Browser: service A company stays separate from service B')
  check('Beta Autoservis' in pb.content() and 'Alfa Autoservis' not in pb.content(),'Browser: independent service B login and company')
  pa.goto(url+'/mechanic.php');pa.wait_for_load_state('networkidle');check(pa.locator('.garage-menu a').count()==4,'Browser SaaS: mobile mechanic retains four main actions');check(pa.evaluate('document.documentElement.scrollWidth<=innerWidth'),'Browser SaaS: mechanic home fits 360px Samsung')
  pa.screenshot(path=str(evidence/'mechanik-alfa-360.png'),full_page=True)
  pa.get_by_role('link',name='RYCHLÁ ZAKÁZKA',exact=True).click();pa.wait_for_load_state('networkidle');pa.locator('#find').fill('7XY7000')
  for name in ['Pneuservis','Oleje a filtry','Brzdy']:pa.get_by_role('button',name=name,exact=True).click()
  pa.get_by_role('button',name='ULOŽIT RYCHLOU ZAKÁZKU',exact=True).click();pa.wait_for_url(re.compile('mechanic.php\\?saved=\\d+'));pa.wait_for_load_state('networkidle')
  check(r.sql("SELECT COUNT(*) FROM saas_alfa.jobs WHERE plate='7XY7000'")=='1' and r.sql("SELECT COUNT(*) FROM saas_beta.jobs WHERE plate='7XY7000'")=='0','Browser SaaS: mobile intake writes only to selected service')
  pa.reload();pa.wait_for_load_state('networkidle');check(pa.locator('.garage-menu').count()==1,'Browser SaaS: tenant login survives refresh')
  pb.goto(url+'/office.php?view=customers');pb.wait_for_load_state('networkidle');check('Beta Secret' in pb.content() and 'Alfa Secret' not in pb.content(),'Browser: reception does not disclose the other service customer')
  pb.screenshot(path=str(evidence/'recepce-beta.png'),full_page=True)
  pb.goto(url+'/office_document.php?invoice=1');pb.pdf(path=str(evidence/'faktura-platce.pdf'),format='A4');check('DPH 21 %' in pb.content(),'Browser: VAT invoice is printable as actual PDF')
  # Draft isolation across service switch in the very same tab and browser storage.
  pa.goto(url+'/mechanic_work.php');pa.wait_for_load_state('networkidle');pa.locator('#find').fill('ALFA DRAFT');pa.locator('[data-service="Brzdy"]').click();oldscope=pa.evaluate('window.ABC_MECH.scope');pa.get_by_role('button',name='Odhlásit',exact=True).click();pa.wait_for_url(re.compile(r'index\.php'));pa.goto(url+'/index.php?servis=servis-beta');pa.get_by_label('E-mail',exact=True).fill('mechanic@example.test');pa.get_by_label('Heslo',exact=True).fill(passwords['beta']);pa.get_by_role('button',name=re.compile('^Přihlásit se')).click();pa.wait_for_url(re.compile(r'(office|mechanic)\.php'));pa.wait_for_load_state('networkidle');pa.goto(url+'/mechanic_work.php');pa.wait_for_load_state('networkidle')
  if not pa.locator('#find').count():print('Draft switch page:',pa.url,pa.locator('body').inner_text()[:1200],errors,flush=True)
  check(pa.locator('#find').input_value(timeout=5000)=='','Browser: old service draft does not appear in another service')
  blocked=pa.evaluate("async scope=>{const r=await fetch('mechanic_flow_api.php?action=info&id=1',{headers:{'X-ABC-Scope':scope}});return r.status}",oldscope);check(blocked==409,'Browser: stale tab service scope rejected by server')
  operator=op.new_page();operator.goto(url+'/platform.php');operator.get_by_label('E-mail',exact=True).fill('operator@example.test');operator.get_by_label('Heslo',exact=True).fill(passwords['operator']);operator.get_by_role('button',name='Přihlásit provozovatele').click();operator.wait_for_load_state('networkidle');check('Klientské servisy' in operator.content() and 'servis-alfa' in operator.content(),'Browser: platform operator manages both services');operator.screenshot(path=str(evidence/'sprava-platformy.png'),full_page=True)
  operator.goto(url+'/office.php');operator.wait_for_load_state('networkidle');check('Váš pracovní prostor' in operator.content(),'Browser: operator session alone cannot access garage reception')
  check(not errors,'Browser SaaS: no JavaScript errors');b.close()
def main():
 with Runtime() as r:
  pw={x:secrets.token_hex(16) for x in ['platform','alfa','beta','operator']};master=secrets.token_hex(32);setup=key()+key()
  for name in ['platform','alfa','beta']:
   r.sql(f"CREATE DATABASE saas_{name} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;CREATE USER 'saas_{name}'@'127.0.0.1' IDENTIFIED BY '{pw[name]}';GRANT ALL ON saas_{name}.* TO 'saas_{name}'@'127.0.0.1';")
  env=r.env.copy();env.update({'ABC_SAAS_ENABLED':'1','ABC_PLATFORM_DB_HOST':'127.0.0.1','ABC_PLATFORM_DB_PORT':str(r.dbport),'ABC_PLATFORM_DB_NAME':'saas_platform','ABC_PLATFORM_DB_USER':'saas_platform','ABC_PLATFORM_DB_PASSWORD':pw['platform'],'ABC_PLATFORM_SECRET':master,'ABC_PLATFORM_SETUP_TOKEN':setup})
  webport=port();cmd=[PHP]+(['-c',INI] if INI else [])+['-d','session.save_path='+str(r.tmp/'sessions'),'-S',f'127.0.0.1:{webport}','-t',str(ROOT),str(ROOT/'tests/router.php')]
  r.processes.append(subprocess.Popen(cmd,env=env,stdout=r.weblog,stderr=subprocess.STDOUT,start_new_session=True));url=f'http://127.0.0.1:{webport}'+r.prefix
  operator=Client(url)
  for _ in range(100):
   try:operator.request('platform_setup.php');break
   except (urllib.error.URLError,ConnectionError):time.sleep(.1)
  status,body=operator.request('platform_setup.php',{'csrf':operator.csrf,'setup_token':setup,'name':'Operator','email':'operator@example.test','password':pw['operator']});check(status==200 and 'Přihlásit provozovatele' in body,'Platform installs into a separate empty registry database')
  check(post(operator,'login',email='operator@example.test',password=pw['operator'])[0]==200,'Operator authenticates with separate platform session')
  check(operator.request('platform_setup.php')[0]==409,'Platform installer refuses overwrite')
  anonymous=Client(url);anonymous.request('index.php');check(not any(k.lower()=='set-cookie' for k in anonymous.last_headers),'Public service chooser cannot overwrite a later authenticated cookie')
  check('Váš pracovní prostor' in operator.request('office.php')[1],'Operator cannot use platform session as garage owner')
  check(operator.request('platform.php',{'action':'plan','name':'bad','monthly_price':1})[0]==403,'Operator mutations require CSRF')
  check(post(operator,'plan',name='Měsíční tarif test',monthly_price='900')[0]==200,'Operator creates a real configured monthly tariff')
  owners={}
  for name in ['alfa','beta']:
   status,body=post(operator,'tenant',name=name.title()+' Autoservis',slug='servis-'+name,db_host='127.0.0.1',db_port=r.dbport,db_name='saas_'+name,db_user='saas_'+name,db_password=pw[name],plan_id=1)
   check(status==200 and 'new-setup-token' in body,'Operator provisions '+name+' without shared customer database')
   token=re.search(r'id="new-setup-token">([a-f0-9]+)',body)[1];client=Client(url);check(client.request('index.php?servis=servis-'+name)[0]==503,'Unfinished service cannot access business routes')
   client.request('setup.php?servis=servis-'+name);status,body=client.request('setup.php',{'csrf':client.csrf,'setup_token':token,'name':'Majitel '+name,'email':'same@example.test','password':pw[name]});check(status==200 and 'Přihlásit se' in body,'Garage owner creates their own account '+name)
   check(client.login('same@example.test',pw[name])[0]==200,'Same login address works independently for '+name)
   check(client.request('company.php')[0]==200,'Garage has its own editable company profile')
   check(client.form('save_user',name='Mechanik '+name,email='mechanic@example.test',password=pw[name],permissions=['price_jobs','collect_payments','issue_invoices','print_receipts'])[0]==200,'Own mechanic account created '+name)
   status,body=client.request('company.php',{'csrf':client.csrf,'company_name':name.title()+' Autoservis','company_address':'Testovací 1, Praha','company_ico':'12345678','company_dic':'CZ12345678' if name=='beta' else '','company_vat':'1' if name=='beta' else '','company_phone':'700000000','company_email':'office@example.test','company_bank_account':'123456789/0100'})
   check(status==200,'Company profile saved '+name)
   check(client.form('save_customer',name=name.title()+' Secret',address='Test 2',ico='',phone='',email='',note='',dic='')[0]==200,'Private customer saved '+name)
   client.form('save_vehicle',customer_id=1,plate='1AB1234',vin='',brand=name.title(),model='Auto',mileage='1')
   client.form('save_catalog',description='Výměna oleje',category='Oleje a filtry',kind='labor',unit_price='1210' if name=='beta' else '500',unit_cost='0',active='1')
   status,job=client.safe_api('mechanic_flow_api.php','create',{'vehicle_id':1,'services':['Brzdy','Oleje a filtry','Pneuservis'],'request_key':key()});check(status==200 and job['id']==1,'Same job ID remains isolated in '+name)
   status,item=client.safe_api('mechanic_flow_api.php','add',{'id':1,'description':'Výměna oleje','category':'Oleje a filtry','kind':'labor','catalog_id':1,'quantity':'1','request_key':key()});check(status==200,'Garage catalog price used '+name)
   client.safe_api('mechanic_api.php','quick_task_status',{'id':1,'task_id':item['task_id'],'status':'done'});client.safe_api('api.php','set_status',{'id':1,'status':'done'})
   if name=='beta':check(client.safe_api('api.php','add_payment',{'id':1,'amount':'100','method':'cash','request_key':key()})[0]==409,'VAT payer must issue tax invoice before recording customer payment')
   inv={'job_id':1,'customer_name':name.title()+' Secret','customer_address':'Test 2','customer_ico':'','customer_dic':'CZ12345678','due_days':14,'request_key':key()};status,result=client.safe_api('office_api.php','issue_invoice',inv);check(status==200,'Own invoice issued '+name+': '+str(result));owners[name]=client
  a=owners['alfa'];b=owners['beta']
  mechanic=Client(url);mechanic.request('index.php?servis=servis-alfa');mechanic.login('mechanic@example.test',pw['alfa']);check(mechanic.request('company.php')[0]==403 and mechanic.request('tenant_export.php')[0]==403 and mechanic.request('subscription.php')[0]==403,'Mechanic cannot change company, export all data or view subscription admin')
  check(mechanic.safe_api('mechanic_flow_api.php','info',id=1)[0]==403,'Mechanic cannot read owner-assigned job within service either')
  check('Klientské servisy' not in a.request('platform.php')[1],'Garage owner is not a platform operator')
  a.request('office.php') # Restore the garage CSRF after separately visiting platform login.
  forged=a.safe_api('mechanic_flow_api.php','create',{'plate':'FORGE123','services':['Brzdy'],'tenant_id':2,'request_key':key()});check(forged[0]==200 and r.sql("SELECT COUNT(*) FROM saas_beta.jobs WHERE plate='FORGE123'")=='0','Forged tenant_id in POST cannot choose another service database')
  # V2 physical presence/preparation use the authenticated tenant DB, including forged tenant_id.
  physical={}
  for name,client in [('alfa',a),('beta',b)]:
   st,res=client.api('phase_a_api.php','resource',{'name':name+' místo','kind':'lift','capacity':1,'request_key':key()});assert st==200,res
   st,res=client.api('mechanic_flow_api.php','create',{'plate':'OPS'+name.upper(),'services':['Brzdy'],'request_key':key()});assert st==200,res;jid=res['id']
   oi=client.api('operations_api.php','info',id=jid)[1]['operations'];st,res=client.api('operations_api.php','take_inside',{'id':jid,'revision':oi['revision'],'resource_id':1,'tenant_id':2,'request_key':key()});assert st==200,res;physical[name]=jid
  check(r.sql("SELECT COUNT(*) FROM saas_alfa.abc_job_presence WHERE ended_at IS NULL")=='1' and r.sql("SELECT COUNT(*) FROM saas_beta.abc_job_presence WHERE ended_at IS NULL")=='1','V2 independent garages can occupy resource ID 1 simultaneously without shared capacity')
  check(r.sql("SELECT plate FROM saas_alfa.jobs WHERE id="+str(physical['alfa']))=='OPSALFA' and r.sql("SELECT COUNT(*) FROM saas_beta.jobs WHERE plate='OPSALFA'")=='0','V2 forged tenant_id cannot move another garage car or choose its presence DB')
  check(all(x['plate']!='OPSBETA' for x in a.api('operations_api.php','queue')[1]['jobs']) and all(x['plate']!='OPSALFA' for x in b.api('api.php','list_jobs')[1]['jobs']),'V2 queue/readiness/physical job lists remain tenant scoped')
  check(a.safe_api('mechanic_api.php','quick_lookup',q='Beta')[1]['customers']==[],'Service A autocomplete cannot see service B customer')
  check(b.safe_api('mechanic_api.php','quick_lookup',q='Alfa')[1]['customers']==[],'Service B autocomplete cannot see service A customer')
  check(a.safe_api('mechanic_flow_api.php','info',id=1)[1]['totals']['total']==500 and b.safe_api('mechanic_flow_api.php','info',id=1)[1]['totals']['total']==1210,'Same item and job IDs use separate prices and totals')
  check(a.request('api.php?action=list_jobs&servis=servis-beta')[0]==400,'Business API rejects service switching via query')
  check(a.request('index.php?servis=servis-beta')[0]==409,'Authenticated service cannot silently switch to another')
  check('Alfa Secret' in a.request('office_document.php?invoice=1')[1] and 'Beta Secret' not in a.request('office_document.php?invoice=1')[1],'Invoice number 1 resolves only within authenticated service')
  invoicea=a.request('office_document.php?invoice=1')[1];invoiceb=b.request('office_document.php?invoice=1')[1]
  check('Dodavatel není plátcem DPH.' in invoicea and 'DPH 21 %' not in invoicea,'Non-VAT garage keeps non-VAT invoice')
  check('DPH 21 %' in invoiceb and '210,00 Kč' in invoiceb and '1 000,00 Kč' in invoiceb,'VAT garage invoice correctly separates 1000 base and 210 tax from 1210 gross')
  profile=json.loads(r.sql('SELECT settings_json FROM saas_beta.company_settings'));profile['company_name']='Changed Beta';r.sql("UPDATE saas_beta.company_settings SET settings_json='"+json.dumps(profile)+"' WHERE id=1")
  check('Beta Autoservis' in b.request('office_document.php?invoice=1')[1] and 'Changed Beta' not in b.request('office_document.php?invoice=1')[1],'Issued invoice preserves company and tax snapshots')
  profile['company_name']='Beta Autoservis';r.sql("UPDATE saas_beta.company_settings SET settings_json='"+json.dumps(profile)+"' WHERE id=1")
  check(r.sql('SELECT COUNT(*) FROM saas_alfa.payments;SELECT COUNT(*) FROM saas_beta.payments;')=='0\n0','Invoices do not create cash or paid balances in either garage')
  status,payment=b.safe_api('api.php','add_payment',{'id':1,'amount':'100','method':'cash','request_key':key()});check(status==200 and 'Dodavatel není plátcem DPH.' not in b.request('mechanic_receipt.php?payment='+str(payment['payment_id']))[1],'VAT receipt references actual payment without false non-VAT text')
  export=a.request('tenant_export.php')[1];encoded=json.dumps(export);check('Alfa Secret' in encoded and 'Beta Secret' not in encoded and 'password_hash' not in encoded and 'credentials' not in encoded,'Owner export contains only own business data and excludes credentials')
  from catalog_documents_helpers import run_tenant_isolation
  run_tenant_isolation(r,a,b,check)
  # Separate database grants are enforced below the application too.
  code="$p=new PDO('mysql:host=127.0.0.1;port='+getenv('ABC_DB_PORT')+';dbname=saas_alfa','saas_alfa',getenv('TEST_A'));try{$p->query('SELECT * FROM saas_beta.jobs');exit(1);}catch(PDOException $e){echo 'denied';}"
  code=code.replace("'mysql:host=127.0.0.1;port='+getenv('ABC_DB_PORT')+';dbname=saas_alfa'","'mysql:host=127.0.0.1;port='.getenv('ABC_DB_PORT').';dbname=saas_alfa'")
  run=subprocess.run([PHP]+(['-c',INI] if INI else [])+['-r',code],env={**env,'TEST_A':pw['alfa']},capture_output=True,text=True);check(run.returncode==0 and run.stdout=='denied','Database A account itself has no SELECT rights on database B')
  credentials=r.sql('SELECT credentials FROM saas_platform.saas_tenants WHERE id=1');check(pw['alfa'] not in credentials and 'db_password' not in credentials,'Tenant database password is encrypted at rest in registry')
  code="require 'app/bootstrap.php';$sealed=seal_tenant(['probe'=>'value'],'identity-a');try{open_tenant($sealed,'identity-b');exit(1);}catch(RuntimeException $e){echo 'denied';}"
  run=subprocess.run([PHP]+(['-c',INI] if INI else [])+['-d','session.save_path='+str(r.tmp/'sessions'),'-r',code],cwd=ROOT,env={**r.env,'ABC_SAAS_ENABLED':'0','ABC_PLATFORM_SECRET':master},capture_output=True,text=True);check(run.returncode==0 and run.stdout=='denied','Encrypted credentials cannot be reused under a different tenant identity')
  check(post(operator,'tenant',name='Duplicate',slug='duplicate',db_host='127.0.0.1',db_port=r.dbport,db_name='saas_alfa',db_user='saas_alfa',db_password=pw['alfa'],attach_copy='1',copy_confirmed='1')[0]==409,'An already bound database cannot be attached to a different service')
  # Real manual billing with partial and replayed payments.
  original=r.sql('SELECT access_until FROM saas_platform.saas_tenants WHERE id=1');check(post(operator,'bill',id=1,request_key=key(),external_invoice='IDOKLAD-TEST-1')[0]==200,'Subscription charge records an external invoice reference')
  check(r.sql('SELECT access_until FROM saas_platform.saas_tenants WHERE id=1')==original,'Creating subscription charge does not invent a payment or extend access')
  pk=key();check(post(operator,'subscription_payment',id=1,bill_id=1,amount='300',reference='BANK-1',confirmed='1',request_key=pk)[0]==200,'Actual partial subscription payment can be confirmed')
  check(post(operator,'subscription_payment',id=1,bill_id=1,amount='300',reference='BANK-1',confirmed='1',request_key=pk)[0]==200 and r.sql('SELECT COUNT(*) FROM saas_platform.saas_payments')=='1','Repeated subscription confirmation never duplicates payment')
  check(r.sql('SELECT access_until FROM saas_platform.saas_tenants WHERE id=1')==original,'Partial subscription payment does not extend whole month')
  check(post(operator,'subscription_payment',id=1,bill_id=1,amount='601',reference='BANK-X',confirmed='1',request_key=key())[0]==409,'Subscription overpayment is rejected and rolled back')
  check(post(operator,'subscription_payment',id=1,bill_id=1,amount='600',reference='BANK-2',confirmed='1',request_key=key())[0]==200,'Final subscription balance accepted')
  check(r.sql('SELECT access_until FROM saas_platform.saas_tenants WHERE id=1')==r.sql('SELECT period_end FROM saas_platform.saas_bills WHERE id=1'),'Only full actual payment extends access through paid period')
  check(r.sql('SELECT COUNT(*) FROM saas_alfa.payments')=='0','Subscription receipts do not become garage customer payments')
  check('IDOKLAD-TEST-1' in a.request('subscription.php')[1] and 'IDOKLAD-TEST-1' not in b.request('subscription.php')[1],'Client subscription ledger is scoped to own service')
  until=r.sql('SELECT access_until FROM saas_platform.saas_tenants WHERE id=1');check(post(operator,'state',id=1,state='suspended',access_until=until,reason='Test suspension')[0]==200,'Operator can suspend a service with audited reason')
  check(a.safe_api('mechanic_flow_api.php','create',{'plate':'BLOCKED','services':['Brzdy'],'request_key':key()})[0]==402,'Suspended garage cannot write business data')
  check(a.safe_api('mechanic_flow_api.php','info',id=1)[0]==200 and a.request('tenant_export.php')[0]==200 and a.request('office_document.php?invoice=1')[0]==200,'Suspension preserves reading, invoice printing and data export')
  check(b.safe_api('mechanic_flow_api.php','create',{'plate':'BETA002','services':['Brzdy'],'request_key':key()})[0]==200,'Suspending service A does not block service B')
  post(operator,'state',id=1,state='active',access_until='2020-01-01',reason='Expiry test');a.login('same@example.test',pw['alfa']);check(a.safe_api('mechanic_flow_api.php','add',{'id':1})[0]==402,'Expired subscription remains read-only after login')
  post(operator,'state',id=1,state='active',access_until=until,reason='Restore tests')
  # Attach an explicit copy of the existing project, keeping IDs and users.
  r.sql("INSERT INTO abc_test.crm_customers(id,name) VALUES(33,'Legacy kept');")
  check(post(operator,'tenant',name='Kopie 3.0',slug='legacy-copy',db_host='127.0.0.1',db_port=r.dbport,db_name='abc_test',db_user='abc_test',db_password=r.password,attach_copy='1',copy_confirmed='1',plan_id=1)[0]==200,'Known copied 3.0 database can be onboarded with additive migration')
  check(r.sql("SELECT id,name FROM abc_test.crm_customers WHERE id=33")=='33\tLegacy kept','Onboarding preserves original customer ID and data')
  archive=Client(url);archive.request('index.php?servis=legacy-copy');check(archive.login('owner@example.test',r.ownerpass)[0]==200,'Onboarding preserves existing owner credentials')
  public=Client(url);public.request('saas_register.php');status,body=public.request('saas_register.php',{'csrf':public.csrf,'name':'Interested garage','email':'request@example.test','phone':'','request_key':secrets.token_hex(16)});check(status==200 and r.sql('SELECT COUNT(*) FROM saas_platform.saas_requests')=='1','Public access request is actually stored for operator')
  if os.environ.get('ABC_TEST_BROWSER')=='1':browser(r,url,pw,check)
  r.weblog.flush();logs=(r.tmp/'php.log').read_text();check(not any(x in logs for x in ['PHP Warning','PHP Fatal error','PHP Parse error']),'No PHP warnings or fatal errors during SaaS flow')
 report={'version':'3.5.0-saas-regression','passed':len(checks),'checks':checks,'browser':os.environ.get('ABC_TEST_BROWSER')=='1','wedos_rewrite':bool(os.environ.get('ABC_TEST_WEDOS_REWRITE'))}
 dest=ROOT/'tests/evidence/350';dest.mkdir(parents=True,exist_ok=True);(dest/('saas-results-wedos.json' if report['wedos_rewrite'] else 'saas-results.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({'passed':len(checks)}))
if __name__=='__main__':main()
