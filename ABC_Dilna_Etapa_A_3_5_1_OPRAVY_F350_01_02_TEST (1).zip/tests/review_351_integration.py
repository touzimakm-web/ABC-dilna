"""F350-01/02: real HTTP/PHP/MariaDB and optional Chromium, never production."""
import json,os,secrets,subprocess,tempfile,zipfile
from pathlib import Path
import runtime
from runtime import Runtime,Client,ROOT,PHP,INI

checks=[]
def key():return secrets.token_hex(20)
def check(ok,label):
    if not ok:raise AssertionError(label)
    checks.append(label);print('OK '+label,flush=True)

def migration(method):
    current=runtime.ROOT
    with tempfile.TemporaryDirectory(prefix='abc351-old-') as folder:
        with zipfile.ZipFile(ROOT/'tests/fixtures/350_source.zip') as z:z.extractall(folder)
        runtime.ROOT=Path(folder)
        try:
            with Runtime() as r:
                o=r.owner
                st,j=o.api('mechanic_flow_api.php','create',{'plate':'HISTORY351','services':['Brzdy'],'request_key':key()});assert st==200,j
                j=j['id'];st,d=o.safe_api('mechanic_flow_api.php','add',{'id':j,'kind':'labor','description':'Historická práce','quantity':2,'unit':'úkon','unit_price':300});assert st==200,d
                o.safe_api('mechanic_api.php','quick_task_status',{'id':j,'task_id':d['task_id'],'status':'done'});o.safe_api('api.php','set_status',{'id':j,'status':'done'})
                st,d=o.safe_api('office_api.php','issue_invoice',{'job_id':j,'customer_name':'Historický zákazník','customer_address':'Test','due_days':14});assert st==200,d
                tables=['jobs','abc_quick_tasks','items','abc_price_history','office_invoices','payments','crm_customers','crm_vehicles','users','office_appointments','abc_quick_catalog','abc_workshop_settings','abc_catalog_history','abc_documents']
                before={t:r.sql('SELECT * FROM abc_test.'+t+' ORDER BY 1') for t in tables}
                if method=='manual_sql':r.sql('USE abc_test;\n'+(ROOT/'sql/upgrade_351_f350.sql').read_text())
                script=r.tmp/'migrate351.php';script.write_text('<?php require '+repr(str(current/'app/bootstrap.php'))+';require '+repr(str(current/'app/migrations.php'))+';abc_migrate_a12(db());')
                for _ in range(2):
                    cmd=[PHP]+(['-c',INI] if INI else [])+['-d','session.save_path='+str(r.tmp/'sessions'),str(script)]
                    p=subprocess.run(cmd,env=r.env,capture_output=True,text=True);assert p.returncode==0 and not p.stdout,p.stderr+p.stdout
                check(all(r.sql('SELECT * FROM abc_test.'+t+' ORDER BY 1')==before[t] for t in tables),method+': migration from actual 3.5.0 twice preserves all tested business rows, invoice JSON, prices, IDs, permissions and bindings')
                check(all(r.sql("SELECT IS_NULLABLE FROM information_schema.COLUMNS WHERE TABLE_SCHEMA='abc_test' AND TABLE_NAME='"+t+"' AND COLUMN_NAME='quantity'")=='YES' for t in ['abc_quick_tasks','items','abc_price_history']),method+': migration permits SQL NULL quantity only in the three required tables')
                check(r.sql("SELECT COUNT(*) FROM abc_test.schema_meta WHERE version='3.5.1-f350'")=='1',method+': migration marker is written once after completed schema changes')
        finally:runtime.ROOT=current

def main():
    for method in ['php','manual_sql']:migration(method)
    with Runtime() as r:
        o=r.owner
        def call(file,action,p=None,c=o,status=200,**params):
            if p is not None:p={'request_key':key(),**p}
            st,d=c.api(file,action,p,**params);assert st==status,(file,action,st,d);return d
        def info(j,c=o):return call('mechanic_flow_api.php','info',c=c,id=j)
        def line(j):return next(t for t in info(j)['tasks'] if t['entry_type']=='work')
        def create(plate,**kw):return call('mechanic_flow_api.php','create',{'plate':plate,'services':['Oleje a filtry'],**kw})['id']
        def catalog(name,kind='labor',unit='hod',price=950):return call('catalog_api.php','save',{'description':name,'category':'Oleje a filtry','kind':kind,'unit':unit,'unit_price':price,'unit_cost':125,'active':1})['id']
        def crow(cid):return next(c for c in call('catalog_api.php','list')['items'] if c['id']==cid)
        def edit(cid,**kw):return call('catalog_api.php','save',{**crow(cid),**kw})
        def settings():return call('phase_a_api.php','settings')['settings']
        def bind(code,cid,index=0):call('catalog_api.php','bind_template',{'revision':settings()['revision'],'template_code':code,'row_index':index,'catalog_id':cid})
        def selection(codes,quantities=None):
            s=settings();return {'revision':s['revision'],'codes':codes,'quantities':quantities or {},'catalog_revisions':{str(row['catalog_id']):row['catalog_revision'] for t in s['service_templates'] if t['code'] in codes for row in t['rows'] if row.get('catalog_id')}}
        hourly=catalog('Výměna oleje / F350-01');part=catalog('Filtr bez ceny / F350-02','part','ks','');bind('oil-change',hourly);bind('oil-filter',part)
        plan=selection(['oil-change']);j=create('NULL351',manual_plan=plan);t=line(j);tid=t['id'];item=t['item_id'];snapshot=t['catalog_snapshot']
        check(t['quantity'] is None and float(t['unit_price'])==950 and t['unit']=='hod' and t['status']=='planned','F350-01 A: quick intake stores hourly work with unknown hours and known 950 CZK rate')
        check(r.sql('SELECT quantity IS NULL FROM abc_test.items WHERE id='+str(item))=='1' and r.sql('SELECT quantity IS NULL FROM abc_test.abc_price_history WHERE task_id='+str(tid))=='1','F350-01 A: task, financial row and initial history store actual NULL, no invented 0/1')
        check(info(j)['totals']['missing_quantity_count']==1 and info(j)['totals']['price_complete'] is False,'F350-01 A: API explicitly reports incomplete pricing even though hourly rate is known')
        check(r.sql('SELECT COUNT(*) FROM abc_test.office_appointments WHERE job_id='+str(j))=='0','F350-01 A: no arrival time invents neither appointment nor lift occupation')
        existing=create('EXIST351');call('phase_a_api.php','manual_plan',{'id':existing,'revision':info(existing)['job']['revision'],'selection':plan});check(line(existing)['quantity'] is None,'F350-01 B: same unknown-hours plan can be added to an existing job')
        call('mechanic_flow_api.php','update_line',{'id':j,'task_id':tid,'revision':t['revision'],'description':'Poznámka bez hodin','quantity':'','unit':'hod','unit_price':950})
        check(line(j)['quantity'] is None and line(j)['id']==tid,'F350-01 D: ordinary row edit leaves unknown hours empty on the same task')
        other=Client(r.url);other.login('owner@example.test',r.ownerpass)
        check(next(x for x in info(j,c=other)['tasks'] if x['id']==tid)['quantity'] is None,'F350-01 D: fresh login and HTTP reload recover NULL hours from the database')
        t=line(j);call('mechanic_api.php','quick_task_status',{'id':j,'task_id':tid,'revision':t['revision'],'status':'done'});call('api.php','set_status',{'id':j,'revision':info(j)['job']['revision'],'status':'done'})
        for action,file,p in [('issue_invoice','office_api.php',{'job_id':j,'customer_name':'Test','customer_address':'Test'}),('add_payment','api.php',{'id':j,'amount':100,'method':'cash'}),('set_status','api.php',{'id':j,'status':'closed'})]:
            d=call(file,action,{**p,'revision':info(j)['job']['revision']},status=409);check(d.get('code')=='quantity_required','F350-01 E: '+action+' rejects missing hours server-side instead of billing zero')
        check(r.sql('SELECT COUNT(*) FROM abc_test.office_invoices WHERE job_id='+str(j))=='0' and r.sql('SELECT COUNT(*) FROM abc_test.payments WHERE job_id='+str(j))=='0','F350-01 E: failed billing creates neither invoice, payment nor fiscal number')
        einfo=call('mechanic_estimate_api.php','info',id=j);et=einfo['tasks'][0]
        call('mechanic_estimate_api.php','save',{'id':j,'job_revision':einfo['job']['revision'],'lines':[{'task_id':et['id'],'revision':et['revision'],'min_price':950,'max_price':950}]},status=409)
        check(r.sql('SELECT COUNT(*) FROM abc_test.abc_job_estimates WHERE job_id='+str(j))=='0','F350-01 E: incomplete hours cannot be confirmed as a misleading zero estimate')
        check('Hodiny doplnit' in o.request('job_sheet.php?job='+str(j))[1],'F350-01 D: customer work sheet labels missing hours instead of printing zero quantity')
        office=o.request('office.php?view=jobs&job='+str(j))[1]
        check('Cena neúplná' in office and 'Uzavřít zakázku' not in office,'F350-01 E: office also reports incomplete pricing instead of offering zero-price closure')
        old=line(j);call('mechanic_flow_api.php','update_line',{'id':j,'task_id':tid,'revision':old['revision'],'description':old['description'],'quantity':'1,5','unit':'hod','unit_price':950})
        filled=line(j);check(filled['id']==tid and filled['item_id']==item and float(filled['quantity'])==1.5 and info(j)['totals']['total']==1425,'F350-01 C: entering 1.5 hours updates same task/item to 1425 CZK, no duplicate line')
        check(filled['catalog_snapshot']==snapshot and filled['catalog_revision']==1 and filled['price_origin']=='catalog' and r.sql('SELECT quantity FROM abc_test.abc_price_history WHERE task_id='+str(tid)+' ORDER BY id DESC LIMIT 1')=='1.500','F350-01 C: source revision/snapshot survive quantity edit; history records actual later hours')
        call('mechanic_flow_api.php','update_line',{'id':j,'task_id':tid,'revision':old['revision'],'description':old['description'],'quantity':2,'unit':'hod'},status=409)
        check(float(line(j)['quantity'])==1.5,'F350-01 C: simultaneous stale edit cannot overwrite saved hours')
        inv=call('office_api.php','issue_invoice',{'job_id':j,'revision':info(j)['job']['revision'],'customer_name':'Test','customer_address':'Test','due_days':14})['invoice_id'];invoice_before=r.sql('SELECT * FROM abc_test.office_invoices WHERE id='+str(inv))
        check(info(j)['totals']['total']==1425 and info(j)['totals']['paid']==0,'F350-01 E: after completing quantity, invoice is 1425 CZK and stays unpaid')
        call('mechanic_flow_api.php','update_line',{'id':j,'task_id':tid,'revision':line(j)['revision'],'description':'Změna po faktuře','quantity':2,'unit':'hod'},status=409)
        # Unbound and active unpriced parts remain valid; only inactive bindings are unavailable.
        partjob=create('ACTIVE351',manual_plan=selection(['oil-filter']));pt=line(partjob);check(pt['catalog_id']==part and pt['unit_price'] is None,'F350-02 A: active unpriced catalog part is selectable and stored as genuinely unpriced')
        call('mechanic_flow_api.php','price',{'id':partjob,'task_id':pt['id'],'revision':pt['revision'],'unit_price':120})
        call('mechanic_flow_api.php','confirm_materials',{'id':partjob,'revision':info(partjob)['job']['revision'],'rows':[{'id':pt['id'],'revision':line(partjob)['revision']}]})
        call('api.php','set_status',{'id':partjob,'revision':info(partjob)['job']['revision'],'status':'done'})
        pinv=call('office_api.php','issue_invoice',{'job_id':partjob,'revision':info(partjob)['job']['revision'],'customer_name':'Původní filtr','customer_address':'Test'})['invoice_id'];part_invoice=r.sql('SELECT * FROM abc_test.office_invoices WHERE id='+str(pinv))
        part_before=r.sql('SELECT * FROM abc_test.abc_quick_tasks WHERE id='+str(pt['id']));history_before=r.sql('SELECT * FROM abc_test.abc_price_history WHERE task_id='+str(pt['id']))
        stale=selection(['oil-change','oil-filter']);edit(part,active=0)
        decorated=next(t for t in settings()['service_templates'] if t['code']=='oil-filter')['rows'][0]
        check(decorated['catalog_id']==part and decorated['catalog_available'] is False and decorated['catalog_price'] is None,'F350-02 B: inactive binding remains auditable and is distinct from active unknown price')
        count=r.sql('SELECT COUNT(*) FROM abc_test.jobs');call('mechanic_flow_api.php','create',{'plate':'STALE351','services':['Brzdy'],'manual_plan':stale},status=409)
        check(r.sql('SELECT COUNT(*) FROM abc_test.jobs')==count,'F350-02 C: stale intake rejects inactive item atomically; no partial job or silent omission')
        target=create('TARGET351');call('phase_a_api.php','manual_plan',{'id':target,'revision':info(target)['job']['revision'],'selection':stale},status=409)
        check(not [t for t in info(target)['tasks'] if t['entry_type']=='work'],'F350-02 C: stale composite plan rolls back all rows, including earlier valid labor')
        check(r.sql('SELECT * FROM abc_test.abc_quick_tasks WHERE id='+str(pt['id']))==part_before and r.sql('SELECT * FROM abc_test.abc_price_history WHERE task_id='+str(pt['id']))==history_before,'F350-02 D: deactivating catalog does not mutate existing task, price, status or price history')
        check(r.sql('SELECT * FROM abc_test.office_invoices WHERE id='+str(pinv))==part_invoice and info(partjob)['totals']['total']==120,'F350-02 D: invoice containing the later deactivated part preserves exact original snapshot and amount')
        edit(hourly,unit_price=1100);check(r.sql('SELECT * FROM abc_test.office_invoices WHERE id='+str(inv))==invoice_before and info(j)['totals']['total']==1425,'F350-02 D: later catalog changes leave issued invoice bytes and original job amount immutable')
        # Direct M02 entries also support unknown hourly quantity; normal parts still require quantity.
        direct=create('DIRECT351');d=call('mechanic_flow_api.php','add',{'id':direct,'kind':'labor','description':'Přímá hodinová práce','unit':'hod','quantity':'','unit_price':950})['line'];check(d['quantity'] is None,'F350-01: manual M02 hourly row supports the same unknown quantity contract')
        call('mechanic_flow_api.php','add',{'id':direct,'kind':'part','description':'Díl musí mít množství','unit':'ks','quantity':'','unit_price':20},status=400)
        check(len([t for t in info(direct)['tasks'] if t['entry_type']=='work'])==1,'F350-01: quantity validation for ordinary parts is not weakened')
        guarded=[]
        for table in ['abc_quick_tasks','items']:
            try:r.sql('UPDATE abc_test.'+table+" SET quantity=NULL,unit='ks',kind='part' WHERE id="+str(d['id'] if table=='abc_quick_tasks' else d['item_id']))
            except RuntimeError as error:guarded.append('CONSTRAINT' in str(error))
            else:guarded.append(False)
        check(all(guarded),'F350-01: actual DB CHECK constraints reject NULL quantity for ordinary parts even outside API')
        # A priced companion must not hide incomplete hourly billing; reprice/cancel preserve NULL history.
        et=line(existing);call('mechanic_flow_api.php','price',{'id':existing,'task_id':et['id'],'revision':et['revision'],'unit_price':975})
        check(line(existing)['quantity'] is None,'F350-01: changing the hourly rate alone never turns unknown quantity into zero')
        preview=call('catalog_api.php','price_preview',job_id=existing,task_id=et['id'])
        call('catalog_api.php','reprice',{'id':existing,'task_id':et['id'],'revision':preview['line']['revision'],'job_revision':preview['job_revision'],'catalog_revision':preview['catalog']['revision'],'confirmed':True})
        check(line(existing)['quantity'] is None and r.sql('SELECT quantity IS NULL FROM abc_test.abc_price_history WHERE task_id='+str(et['id'])+' ORDER BY id DESC LIMIT 1')=='1','F350-01: explicit catalog reprice keeps unknown hours and NULL audit quantity')
        for value in ['0','-1','1.0001']:
            call('mechanic_flow_api.php','update_line',{'id':existing,'task_id':et['id'],'revision':line(existing)['revision'],'description':'Validace hodin','quantity':value,'unit':'hod'},status=400)
        check(line(existing)['quantity'] is None,'F350-01: zero, negative and excess precision hours are rejected without changing the line')
        companion=call('mechanic_flow_api.php','add',{'id':existing,'kind':'labor','description':'Známý úkon','unit':'úkon','quantity':1,'unit_price':100})['line']
        for task in [line(existing),companion]:call('mechanic_api.php','quick_task_status',{'id':existing,'task_id':task['id'],'revision':task['revision'],'status':'done'})
        call('api.php','set_status',{'id':existing,'revision':info(existing)['job']['revision'],'status':'done'})
        call('office_api.php','issue_invoice',{'job_id':existing,'revision':info(existing)['job']['revision'],'customer_name':'Test','customer_address':'Test'},status=409)
        call('api.php','add_payment',{'id':existing,'amount':50,'method':'cash'},status=409)
        check(info(existing)['totals']['total']==100 and info(existing)['totals']['paid']==0,'F350-01 E: positive known subtotal cannot bypass missing hours, even for partial payment')
        et=line(existing);call('mechanic_flow_api.php','cancel_line',{'id':existing,'task_id':et['id'],'revision':et['revision']})
        check(info(existing)['totals']['missing_quantity_count']==0 and r.sql('SELECT quantity IS NULL FROM abc_test.abc_price_history WHERE task_id='+str(et['id'])+' ORDER BY id DESC LIMIT 1')=='1','F350-01: explicitly cancelled unknown work stops blocking billing and preserves NULL audit quantity')
        if os.environ.get('ABC_TEST_BROWSER')=='1':
            from review_351_browser import run_browser
            run_browser(r,check,{'hourly':hourly,'part':part,'catalog':catalog,'bind':bind,'edit':edit,'settings':settings,'create':create,'info':info,'call':call})
        r.weblog.flush();log=(r.tmp/'php.log').read_text();check(not any(x in log for x in ['PHP Warning','PHP Fatal','PHP Parse','PHP Deprecated','Uncaught','ABC Dílna:','ABC estimate api:','ABC mechanic_flow_api:']),'No PHP runtime warnings or unhandled application/database errors during F350 tests')
    suffix='-wedos' if os.environ.get('ABC_TEST_WEDOS_REWRITE')=='1' else '';out=ROOT/'tests/evidence/351';out.mkdir(parents=True,exist_ok=True)
    (out/('results'+suffix+'.json')).write_text(json.dumps({'release':'3.5.1','database':'real MariaDB','browser':os.environ.get('ABC_TEST_BROWSER')=='1','passed':len(checks),'checks':checks},ensure_ascii=False,indent=2))
    print('PASS',len(checks),flush=True)

if __name__=='__main__':main()
