"""Catalog + documents acceptance against actual MariaDB, PHP, binary HTTP and Chromium."""
from runtime import Runtime,Client,ROOT,PHP,INI
import runtime,json,secrets,hashlib,os,subprocess,tempfile,zipfile
from pathlib import Path
from catalog_documents_helpers import pdf,upload,binary
checks=[]
def key():return secrets.token_hex(20)
def check(ok,label):
 if not ok:raise AssertionError(label)
 checks.append(label);print('OK '+label,flush=True)

def migration():
 old=runtime.ROOT
 with tempfile.TemporaryDirectory(prefix='abc350-340-') as folder:
  with zipfile.ZipFile(ROOT/'tests/fixtures/340_source.zip') as z:z.extractall(folder)
  runtime.ROOT=Path(folder)
  try:
   with Runtime() as r:
    o=r.owner;st,j=o.api('mechanic_flow_api.php','create',{'plate':'OLD350','services':['Brzdy'],'request_key':key()});assert st==200,j;j=j['id']
    assert o.form('save_catalog',description='Stará sazba za kolo',category='Pneuservis',kind='labor',unit='úkon',unit_price=220,unit_cost=72,active=1)[0]==200
    t=o.safe_api('mechanic_flow_api.php','add',{'id':j,'kind':'labor','description':'Stará skutečná práce','quantity':1,'unit':'úkon','unit_price':220,'request_key':key()})[1]['task_id'];o.safe_api('mechanic_api.php','quick_task_status',{'id':j,'task_id':t,'status':'done'});o.safe_api('api.php','set_status',{'id':j,'status':'done'});assert o.safe_api('office_api.php','issue_invoice',{'job_id':j,'customer_name':'Původní zákazník','customer_address':'Původní','due_days':14})[0]==200
    tables=['jobs','items','abc_quick_tasks','abc_quick_catalog','office_invoices','payments','office_appointments'];columns={t:','.join(row.split('\t')[0] for row in r.sql('SHOW COLUMNS FROM abc_test.'+t).splitlines()) for t in tables};before={t:r.sql('SELECT '+columns[t]+' FROM abc_test.'+t) for t in tables}
    script=r.tmp/'migrate350.php';script.write_text("<?php require "+repr(str(old/'app/bootstrap.php'))+";require "+repr(str(old/'app/migrations.php'))+";abc_migrate_a12(db());")
    cmd=[PHP]+(['-c',INI] if INI else [])+['-d','session.save_path='+str(r.tmp/'sessions'),str(script)]
    for i in range(2):
     p=subprocess.run(cmd,env=r.env,capture_output=True,text=True);assert p.returncode==0 and not p.stdout,p.stderr+p.stdout
    check(all(r.sql('SELECT '+columns[t]+' FROM abc_test.'+t)==before[t] for t in tables),'Migration 3.4.0 twice preserves original rows, units, money, costs and immutable invoice bytes')
    check(r.sql('SELECT public_item FROM abc_test.abc_quick_catalog')=='0' and r.sql('SELECT COUNT(*) FROM abc_test.abc_documents')=='0','Migration invents neither public business prices nor uploaded documents')
  finally:runtime.ROOT=old

def main():
 migration()
 with Runtime() as r:
  o=r.owner
  def call(file,action,p=None,c=o,status=200,**q):
   if p is not None:p={'request_key':key(),**p}
   st,d=c.api(file,action,p,**q);assert st==status,(action,st,d);return d
  def info(j,c=o):return call('mechanic_flow_api.php','info',c=c,id=j)
  def create(plate,**kw):return call('mechanic_flow_api.php','create',{'plate':plate,'services':['Oleje a filtry'],**kw})['id']
  def catalog(name,unit='úkon',price=300,kind='labor',**kw):return call('catalog_api.php','save',{'description':name,'category':'Oleje a filtry','kind':kind,'unit':unit,'unit_price':price,'active':1,**kw})['id']
  def crow(cid):return next(c for c in call('catalog_api.php','list')['items'] if c['id']==cid)
  def edit(cid,**kw):return call('catalog_api.php','save',{**crow(cid),**kw})
  hourly=catalog('Výměna oleje – hodinová sazba','hod',800,unit_cost=241,public_item=1);unknown=catalog('Konkrétní filtr bez ceny','ks','',kind='part',public_item=1);zero=catalog('Bezplatná kontrola','úkon',0,public_item=1);hidden=catalog('NEVEŘEJNÝ NÁKLAD','úkon',999,unit_cost=888,public_item=0)
  check(crow(unknown)['unit_price'] is None and float(crow(zero)['unit_price'])==0,'04: empty catalog price is unknown, deliberately entered zero remains zero')
  templates=call('phase_a_api.php','settings')['settings'];call('catalog_api.php','bind_template',{'revision':templates['revision'],'template_code':'oil-change','row_index':0,'catalog_id':hourly});settings=call('phase_a_api.php','settings')['settings'];row=next(t for t in settings['service_templates'] if t['code']=='oil-change')['rows'][0]
  check(row['unit']=='hod' and row['quantity'] is None and row['catalog_id']==hourly,'01: bound hourly card uses same catalog and never invents one hour')
  selection={'revision':settings['revision'],'codes':['oil-change','oil-filter'],'catalog_revisions':{str(hourly):crow(hourly)['revision']},'quantities':{'oil-change':{'0':'1.5'}}};j=create('CENIK350',manual_plan=selection);tasks=[t for t in info(j)['tasks'] if t['entry_type']=='work'];t=next(t for t in tasks if t['kind']=='labor');f=next(t for t in tasks if t['kind']=='part')
  check(float(t['quantity'])==1.5 and float(t['unit_price'])==800 and t['catalog_revision']==1 and t['price_origin']=='catalog' and f['unit_price'] is None,'01/04: clicked plan copies explicit hours and rate/source, generic filter stays unpriced and no category charge')
  check(info(j)['totals']['estimated_total']==1200 and info(j)['totals']['total']==0,'01: planned priced work is not performed or billed work')
  bad={**selection,'quantities':{}};empty=call('mechanic_flow_api.php','create',{'plate':'NOHOURS','services':['Oleje a filtry'],'manual_plan':bad})['id'];check(next(x for x in info(empty)['tasks'] if x['kind']=='labor' and x['entry_type']=='work')['quantity'] is None,'F350-01 regression: selected hourly work accepts unknown hours without a fictional quantity')
  edit(hourly,unit_price=900);check(float(next(x for x in info(j)['tasks'] if x['id']==t['id'])['unit_price'])==800,'02: catalog update does not reprice previously saved job')
  call('mechanic_flow_api.php','create',{'plate':'STALEPLAN','services':['Oleje a filtry'],'manual_plan':selection},status=409)
  call('mechanic_flow_api.php','add',{'id':j,'kind':'labor','description':'Stará sazba','catalog_id':hourly,'quantity':1,'unit':'hod','catalog_revision':1},status=409)
  call('mechanic_flow_api.php','add',{'id':j,'kind':'labor','description':'Bez revize','catalog_id':hourly,'quantity':1,'unit':'hod'},status=428)
  new=call('mechanic_flow_api.php','add',{'id':j,'kind':'labor','description':'Nová sazba','catalog_id':hourly,'catalog_revision':2,'quantity':2,'unit':'hod'})['line'];check(float(new['unit_price'])==900 and new['catalog_revision']==2,'02: new item takes current rate; stale or missing catalog revisions are rejected')
  prev=call('catalog_api.php','price_preview',job_id=j,task_id=t['id']);call('catalog_api.php','reprice',{'id':j,'revision':prev['line']['revision'],'job_revision':prev['job_revision'],'task_id':t['id'],'catalog_revision':prev['catalog']['revision'],'confirmed':True});check(float(next(x for x in info(j)['tasks'] if x['id']==t['id'])['unit_price'])==900,'02: explicit preview/confirmation reprices only chosen unlocked row with history')
  # User can change a job price but cannot change the global catalog.
  pw=key();assert o.form('save_user',name='Mechanik ceníku',email='cenik@350.test',password=pw,permissions=['create_jobs','edit_jobs','edit_lines','price_jobs','view_documents','print_documents'],rights_version=2)[0]==200;w=Client(r.url);w.login('cenik@350.test',pw);wid=int(r.sql("SELECT id FROM abc_test.users WHERE email='cenik@350.test'"))
  call('catalog_api.php','save',{**crow(hourly),'unit_price':1},c=w,status=403)
  st,own=w.api('mechanic_flow_api.php','create',{'plate':'MECHPRICE','services':['Brzdy'],'request_key':key()});assert st==200,own;own=own['id'];call('mechanic_flow_api.php','add',{'id':own,'kind':'labor','description':'Cena jen v zakázce','unit':'úkon','quantity':1,'unit_price':123},c=w)
  check(float(crow(hourly)['unit_price'])==900 and 'unit_cost' not in json.dumps(call('mechanic_api.php','catalog',c=w)),'03: per-job price right never grants global catalog writes or discloses purchase cost')
  # Finish a real job, invoice it and change catalog again.
  for x in [x for x in info(j)['tasks'] if x['entry_type']=='work' and x['kind']=='labor']:call('mechanic_api.php','quick_task_status',{'id':j,'task_id':x['id'],'revision':x['revision'],'status':'done'})
  call('api.php','set_status',{'id':j,'revision':info(j)['job']['revision'],'status':'done'});inv=call('office_api.php','issue_invoice',{'job_id':j,'revision':info(j)['job']['revision'],'customer_name':'Zákazník test','customer_address':'Test','due_days':14})['invoice_id'];before=r.sql('SELECT * FROM abc_test.office_invoices WHERE id='+str(inv));edit(hourly,unit_price=1000)
  check(r.sql('SELECT * FROM abc_test.office_invoices WHERE id='+str(inv))==before and info(j)['totals']['paid']==0,'02: rate changes preserve issued invoice bytes and never invent customer payment')
  # Exact tyre variant uses same catalog, distinguishing per-wheel and full-set quantities.
  wheel=catalog('Přezutí za kolo','kolo',250);setprice=catalog('Přezutí celé sady','sada',1000);valve=catalog('Ventilek','ks',30,kind='part');perjob=catalog('Příplatek jednou','úkon',50);perwheel=catalog('Příplatek za kolo','kolo',20)
  cfg=call('phase_a_api.php','settings')['settings'];cfg['tyres']=[{'operation':'complete','vehicle':'car','diameter':diameter,'balance':True,'runflat':False,'catalog_id':cid,'valve_catalog_id':valve} for diameter,cid in [(16,wheel),(17,setprice)]];cfg['tyre_extras']=[{'code':'once','label':'Jednou','catalog_id':perjob,'exclusive_group':'','per_wheel':False},{'code':'wheel','label':'Za kolo','catalog_id':perwheel,'exclusive_group':'','per_wheel':True}];call('phase_a_api.php','settings',{'settings':cfg,'revision':cfg['revision']});cfg=call('phase_a_api.php','settings')['settings']
  quoted={'settings_revision':cfg['revision'],'catalog_revisions':{str(c['id']):c['revision'] for c in call('mechanic_api.php','catalog')['items']}}
  tj=create('TYRE350');tyrep={'id':tj,'revision':info(tj)['job']['revision'],'operation':'complete','vehicle':'car','diameter':16,'balance':True,'count':4,'valves':True,'extras':['once','wheel'],**quoted};call('phase_a_api.php','tyres',tyrep)
  check(info(tj)['totals']['estimated_total']==1250 and info(tj)['totals']['total']==0,'05: four wheels, four valves, per-wheel and once-per-job extras calculated exactly once as planned rows')
  sj=create('SET350');call('phase_a_api.php','tyres',{**tyrep,'id':sj,'revision':info(sj)['job']['revision'],'diameter':17,'extras':['once']});setrow=next(x for x in info(sj)['tasks'] if x['entry_type']=='work' and x['unit']=='sada')
  check(info(sj)['totals']['estimated_total']==1170 and float(setrow['quantity'])==1,'05: whole-set price is charged once, not multiplied by four wheels')
  call('phase_a_api.php','tyres',{**tyrep,'revision':info(tj)['job']['revision']},status=409)
  missing=create('NO_VARIANT350');call('phase_a_api.php','tyres',{**tyrep,'id':missing,'revision':info(missing)['job']['revision'],'diameter':18},status=409)
  forbidden=call('phase_a_api.php','tyres',{**tyrep,'id':missing,'revision':info(missing)['job']['revision'],'vehicle':'van','runflat':True},status=409)
  check(forbidden.get('code')=='tyre_combination_forbidden' and info(missing)['totals']['estimated_total']==0,'05: included services, missing variants and forbidden van/runflat combination cannot create duplicate or invented prices')
  # Current public print contains only active/public sale data.
  edit(zero,active=0);s,html=o.request('catalog_print.php');check(s==200 and '1 000,00 Kč' in html and 'NEVEŘEJNÝ NÁKLAD' not in html and '888' not in html and 'Bezplatná kontrola' not in html and 'Nenaceněno' in html,'06: generated public price list uses current data, honest unknown and hides inactive/private/cost values')
  counts=r.sql('SELECT COUNT(*) FROM abc_test.jobs;SELECT COUNT(*) FROM abc_test.crm_customers;SELECT COUNT(*) FROM abc_test.crm_vehicles;SELECT COUNT(*) FROM abc_test.office_appointments;SELECT COUNT(*) FROM abc_test.office_invoices;SELECT COUNT(*) FROM abc_test.payments;');s,blank=o.request('blank_job_sheet.php');check(s==200 and 'ABC Autoslužby' in blank and 'CENIK350' not in blank and 'Zákazník test' not in blank and counts==r.sql('SELECT COUNT(*) FROM abc_test.jobs;SELECT COUNT(*) FROM abc_test.crm_customers;SELECT COUNT(*) FROM abc_test.crm_vehicles;SELECT COUNT(*) FROM abc_test.office_appointments;SELECT COUNT(*) FROM abc_test.office_invoices;SELECT COUNT(*) FROM abc_test.payments;'),'07: blank form prefills company only and creates no customer/car/job/booking/document/payment')
  # Valid real PDF, immutable versions, direct download and job scope.
  attached=create('SIGNED350');data=pdf('SIGNED ORIGINAL');fields={'title':'Podepsaná plná moc','category':'attachment','job_id':attached,'active':1,'request_key':key()};st,doc,_=upload(o,'save',fields,{'pdf':('podepsano.pdf',data,'application/pdf')});assert st==200,doc;did=doc['id']
  check(upload(o,'save',fields,{'pdf':('podepsano.pdf',data,'application/pdf')})[1]['id']==did and r.sql('SELECT COUNT(*) FROM abc_test.abc_document_versions')=='1','08: uploaded PDF bytes and metadata commit together; exact retry stores one version')
  st,raw,headers=binary(o,'document_file.php?id='+str(did));check(st==200 and raw==data and 'application/pdf' in headers['Content-Type'],'08: authorized direct download returns exact saved PDF with controlled MIME')
  check(binary(w,'document_file.php?id='+str(did))[0]==403 and w.api('documents_api.php','versions',id=did)[0]==403,'08: employee without job access cannot retrieve attachment or history by guessing ID')
  before_versions=r.sql('SELECT COUNT(*) FROM abc_test.abc_document_versions');st,err,_=upload(o,'save',{'title':'Špatný soubor','category':'form','active':1,'request_key':key()},{'pdf':('bad.php',b'<?php echo 1;','application/pdf')});check(st==415 and r.sql('SELECT COUNT(*) FROM abc_test.abc_document_versions')==before_versions,'Security: executable/wrong file rejected with no orphan metadata')
  check(upload(o,'save',{'title':'Bez CSRF','category':'form','request_key':key()},{'pdf':('x.pdf',data,'application/pdf')},csrf=False)[0]==403,'Security: multipart upload requires CSRF')
  check(upload(o,'save',{'title':'Příliš velký PDF','category':'form','request_key':key()},{'pdf':('big.pdf',data+b' '*6000000,'application/pdf')})[0]==413,'Security: oversized PDF fails without partial persistence')
  st,doc2,_=upload(o,'save',{'id':did,'revision':1,'title':'Podepsaná plná moc – nová verze','category':'attachment','job_id':attached,'active':1,'request_key':key()},{'pdf':('nova.pdf',pdf('SIGNED NEW'),'application/pdf')});assert st==200,doc2
  check(binary(o,'document_file.php?id='+str(did)+'&version=1')[1]==data and binary(o,'document_file.php?id='+str(did))[1]!=data,'09: replacing a PDF creates new version and preserves previously signed original bytes')
  st,_,_=upload(o,'save',{'id':did,'revision':1,'title':'Zastaralý editor','category':'attachment','job_id':attached,'active':1,'request_key':key()});check(st==409,'09: stale document editor cannot overwrite another version')
  dc=call('documents_api.php','list');s,meta,_=upload(o,'template',{'revision':1,'title':'Vlastní prázdný list','footer':'Vlastní schválený text servisu','show_vin':1,'show_phone':1,'show_mileage':1,'work_rows':20,'material_rows':20,'request_key':key()});assert s==200,meta
  check(binary(o,'document_file.php?id='+str(did)+'&version=1')[1]==data and 'Vlastní prázdný list' in o.request('blank_job_sheet.php')[1],'09: print template change cannot alter a signed job attachment')
  # A failed insert must roll the new document metadata and bytes back together.
  before_docs=r.sql('SELECT COUNT(*) FROM abc_test.abc_documents;SELECT COUNT(*) FROM abc_test.abc_document_versions;')
  r.sql("CREATE TRIGGER abc_test.test_fail_document BEFORE INSERT ON abc_test.abc_document_versions FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='controlled document persistence failure'")
  failed_fields={'title':'Přerušený zápis','category':'form','active':1,'request_key':key()}
  try:st,_,_=upload(o,'save',failed_fields,{'pdf':('rollback.pdf',data,'application/pdf')})
  finally:r.sql('DROP TRIGGER abc_test.test_fail_document')
  check(st==500 and before_docs==r.sql('SELECT COUNT(*) FROM abc_test.abc_documents;SELECT COUNT(*) FROM abc_test.abc_document_versions;'),'Security: forced DB failure leaves neither persisted PDF nor orphan document metadata')
  st,retry,_=upload(o,'save',failed_fields,{'pdf':('rollback.pdf',data,'application/pdf')});check(st==200,'Security: same operation key safely retries an actually rolled-back document save')
  active_pdf=data[:-6]+b'/JavaScript (evil)\n%%EOF'
  check(upload(o,'save',{'title':'Aktivní PDF','category':'form','active':1,'request_key':key()},{'pdf':('active.pdf',active_pdf,'application/pdf')})[0]==415,'Security: PDF with active JavaScript is not accepted')
  private_data=pdf('PRIVATE VERSION')
  st,private_doc,_=upload(o,'save',{'title':'Soukromá šablona','category':'form','active':1,'staff_visible':0,'request_key':key()},{'pdf':('private.pdf',private_data,'application/pdf')});assert st==200,private_doc
  st,_,_=upload(o,'save',{'id':private_doc['id'],'revision':1,'title':'Nová veřejná verze pro zaměstnance','category':'form','active':1,'staff_visible':1,'request_key':key()},{'pdf':('new.pdf',pdf('EMPLOYEE VERSION'),'application/pdf')});assert st==200
  check(binary(w,'document_file.php?id='+str(private_doc['id']))[0]==200 and binary(w,'document_file.php?id='+str(private_doc['id'])+'&version=1')[0]==403,'Security: publishing a new staff version never exposes a historically private version')
  import base64
  logo=base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aZl8AAAAASUVORK5CYII=')
  st,_,_=upload(o,'template',{'revision':2,'title':'Vlastní prázdný list','footer':'Vlastní schválený text servisu','show_vin':1,'show_phone':1,'show_mileage':1,'work_rows':20,'material_rows':20,'request_key':key()},{'logo':('logo.png',logo,'image/png')});assert st==200
  check('data:image/png;base64,'+base64.b64encode(logo).decode() in o.request('blank_job_sheet.php')[1] and 'data:image/png;base64,' not in o.request('blank_job_sheet.php?template_version=2')[1],'Template: configured logo prints in current blank form, historical template keeps its original logo')
  # Quote uses recorded row units/revisions and never turns unknown price into zero.
  qj=create('QUOTE350');q1=call('mechanic_flow_api.php','add',{'id':qj,'kind':'part','description':'Konkrétní filtr bez ceny','unit':'ks','quantity':1,'catalog_id':unknown,'catalog_revision':crow(unknown)['revision']})['task_id'];q2=call('mechanic_flow_api.php','add',{'id':qj,'kind':'labor','description':'Ruční odhad práce','unit':'hod','quantity':2})['task_id'];qi=call('mechanic_estimate_api.php','info',id=qj)
  check(next(x for x in qi['catalog'] if x['id']==unknown)['unit_price'] is None and next(x for x in qi['tasks'] if x['id']==q2)['unit']=='hod','Quote: unknown catalog price and actual row unit are preserved in estimate data')
  qlines=[{'task_id':x['id'],'revision':x['revision'],'min_price':'100' if x['id']==q2 else '', 'max_price':'200' if x['id']==q2 else ''} for x in qi['tasks']];qp={'id':qj,'job_revision':qi['job']['revision'],'lines':qlines,'origin':'manual','request_key':key()};saved=call('mechanic_estimate_api.php','save',qp)['quote_id'];call('mechanic_estimate_api.php','save',qp)
  check(r.sql('SELECT COUNT(*) FROM abc_test.abc_job_estimates WHERE job_id='+str(qj))=='1' and 'hod' in o.request('mechanic_estimate_print.php?id='+str(saved))[1],'Quote: human-reviewed estimate keeps its hourly unit and exact retry allocates one saved estimate')
  snapshot=r.sql('SELECT lines_json FROM abc_test.abc_job_estimates WHERE id='+str(saved));edit(unknown,unit_price=500);check(r.sql('SELECT lines_json FROM abc_test.abc_job_estimates WHERE id='+str(saved))==snapshot,'Quote: later catalog change never rewrites an agreed saved estimate')
  if os.environ.get('ABC_TEST_BROWSER')=='1':
   assert o.form('assign_job',id=attached,mechanic_id=wid,revision=info(attached)['job']['revision'])[0]==200
   from catalog_documents_browser import run_browser
   run_browser(r,check,{'hourly':hourly,'unknown':unknown,'job':attached,'document':did,'worker_id':wid,'worker_password':pw,'worker_job':own})
  errors=[l for l in (r.tmp/'php.log').read_text().splitlines() if any(tag in l for tag in ['PHP Warning','PHP Fatal','PHP Parse','PHP Deprecated'])];check(not errors,'No PHP warnings/fatal errors in catalog/document acceptance: '+str(errors[:2]))
  out=ROOT/'tests/evidence/350';out.mkdir(parents=True,exist_ok=True);(out/('results-wedos.json' if r.prefix else 'results.json')).write_text(json.dumps({'version':'3.5.0','passed':len(checks),'browser':os.environ.get('ABC_TEST_BROWSER')=='1','checks':checks},ensure_ascii=False,indent=2))
 print(json.dumps({'passed':len(checks)}))
if __name__=='__main__':main()
