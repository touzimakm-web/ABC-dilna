<?php
// Pouze pro místní HTTP testy; na Apache platí dodané .htaccess soubory.
// Test doručení: skutečný browser odešle původní multipart a aplikace jej COMMITne.
// Teprve po úspěšném zpracování testovací router zahodí potvrzení. Nikdy produkční kód.
if(getenv('ABC_TEST_DROP_REPLY')==='1'&&($_SERVER['HTTP_X_ABC_TEST_DROP_REPLY']??'')==='1'){
    ob_start();register_shutdown_function(static function(): void {
        if(http_response_code()===200){while(ob_get_level()>0)ob_end_clean();http_response_code(503);header('Content-Type: application/json');header('Content-Length: 0');}
    });
}
$path=rawurldecode(parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH)??'/');
$prefix=getenv('ABC_TEST_PUBLIC_PREFIX')?:'';
if($prefix!==''){
    if(!str_starts_with($path,$prefix.'/')){http_response_code(404);exit;}
    $path=substr($path,strlen($prefix));
}
if(preg_match('~^/(app|storage|sql|tests|docs)(/|$)|\.(sql|zip|log|ini|md|txt|py)$~i',$path)) {
    http_response_code(403);exit('Forbidden');
}
if($prefix!==''){
    if(str_ends_with($path,'/'))$path.='index.php';
    $base=realpath(dirname(__DIR__));$file=realpath($base.$path);
    if($file===false||!str_starts_with($file,$base.'/')||!is_file($file)){http_response_code(404);exit;}
    if(pathinfo($file,PATHINFO_EXTENSION)==='php'){
        $_SERVER['SCRIPT_NAME']='/domains/dilna.abcautosluzby.cz'.$prefix.$path;
        $_SERVER['PHP_SELF']=$_SERVER['SCRIPT_NAME'];
        $_SERVER['SCRIPT_FILENAME']=$file;
        require $file;
    }else{
        $types=['css'=>'text/css','js'=>'application/javascript'];
        header('Content-Type: '.($types[pathinfo($file,PATHINFO_EXTENSION)]??'application/octet-stream'));
        readfile($file);
    }
    return true;
}
return false;
