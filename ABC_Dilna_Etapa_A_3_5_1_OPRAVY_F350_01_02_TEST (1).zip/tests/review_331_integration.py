"""F01-F06: واقعی PHP/MariaDB workflows, migration from unchanged 3.3.0 and browser."""
from runtime import Runtime,Client,ROOT,PHP,INI
import runtime,json,secrets,subprocess,tempfile,zipfile,os,hashlib,concurrent.futures
checks=[]
def key():return secrets.token_hex(20)
def check(ok,label):
 if not ok:raise AssertionError(label)
 checks.append(label);print('OK '+label,flush=True)
def run_legacy():
 with tempfile.TemporaryDirectory(prefix='abc-330-source-') as folder:
  old=runtime.ROOT
  with zipfile.ZipFile(ROOT/'tests/fixtures/330_source.zip') as z:z.extractall(folder)
  runtime.ROOT=__import__('pathlib').Path(folder)
  try:
   with Runtime() as r:
    o=r.owner;s,d=o.api('mechanic_flow_api.php','create',{'plate':'LEGACY331','services':['Pneuservis'],'date':'2027-06-01','time':'10:00','duration':60,'request_key':key()});assert s==200,d;j=d['id']
    assert o.form('save_catalog',description='Stara sazba',category='Pneuservis',kind='labor',unit='ks',unit_price=250,unit_cost=40,active=1)[0]==200
    settings=o.api('phase_a_api.php','settings')[1]['settings'];settings['tyres']=[{'operation':'complete','vehicle':'car','diameter':16,'balance':True,'runflat':False,'catalog_id':1,'valve_catalog_id':None}]
    assert o.api('phase_a_api.php','settings',{'settings':settings,'revision':settings['revision'],'request_key':key()})[0]==200
    info=lambda:o.api('mechanic_flow_api.php','info',id=j)[1]
    assert o.api('phase_a_api.php','tyres',{'id':j,'revision':info()['job']['revision'],'operation':'complete','vehicle':'car','diameter':16,'balance':True,'count':4,'request_key':key()})[0]==200
    line=next(t for t in info()['tasks'] if t['entry_type']=='work');assert o.api('mechanic_api.php','quick_task_status',{'id':j,'task_id':line['id'],'revision':line['revision'],'status':'done','request_key':key()})[0]==200
    assert o.api('api.php','set_status',{'id':j,'status':'done','revision':info()['job']['revision'],'request_key':key()})[0]==200
    s,inv=o.api('office_api.php','issue_invoice',{'job_id':j,'revision':info()['job']['revision'],'customer_name':'Puvodni','customer_address':'Puvodni 1','due_days':14,'request_key':key()});assert s==200,inv
    assert o.api('api.php','add_payment',{'id':j,'amount':100,'method':'cash','request_key':key()})[0]==200
    tables=['items','office_invoices','payments','office_appointments'];columns={t:','.join(row.split('\t')[0] for row in r.sql('SHOW COLUMNS FROM abc_test.'+t).splitlines()) for t in tables};before={t:r.sql('SELECT '+columns[t]+' FROM abc_test.'+t) for t in tables}
    code="<?php require "+json.dumps(str(ROOT/'app/migrations.php'))+"; $db=new PDO('mysql:host='.getenv('ABC_DB_HOST').';port='.getenv('ABC_DB_PORT').';dbname='.getenv('ABC_DB_NAME'),getenv('ABC_DB_USER'),getenv('ABC_DB_PASSWORD'),[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]); abc_migrate_a12($db); abc_migrate_a12($db); echo 'OK';"
    p=subprocess.run([PHP]+(['-c',INI] if INI else []),input=code,text=True,capture_output=True,env=r.env)
    check(p.returncode==0 and p.stdout=='OK' and not p.stderr,'F02 migration from real 3.3.0 installer completes twice')
    check(all(r.sql('SELECT '+columns[t]+' FROM abc_test.'+t)==value for t,value in before.items()),'F02 migration preserves old items costs document bytes payments and exact reservations')
    check(r.sql('SELECT work_day FROM abc_test.jobs WHERE id='+str(j))=='NULL','F02 migration invents no historical working date')
    meta=json.loads(r.sql('SELECT bundle_meta FROM abc_test.abc_quick_tasks WHERE id='+str(line['id'])))
    check('wheel_balance' in meta['components'] and meta['scope_inferred'] is True,'F06 migrated tyre scope honestly records old configured coverage')
    stored=json.loads(r.sql('SELECT settings_json FROM abc_test.abc_workshop_settings'));check(stored['tyres'][0]['catalog_id']==1 and stored['tyre_van_runflat_exclusive'] is True and bool(stored['service_templates']),'F01 F04 migration preserves actual price rules and adds per-workshop templates and policy')
  finally:runtime.ROOT=old

def main():
 run_legacy()
 with Runtime() as r:
  o=r.owner
  def info(j,c=o):
   s,d=c.api('mechanic_flow_api.php','info',id=j);assert s==200,d;return d
  def create(plate,c=o,**kw):return c.api('mechanic_flow_api.php','create',{'plate':plate,'services':['Oleje a filtry','Brzdy'],'request_key':key(),**kw})
  def api(action,p=None,**kw):return o.safe_api('phase_a_api.php',action,p,**kw) if action=='tyres' else o.api('phase_a_api.php',action,p,**kw)
  def settings_update(change):
   s=api('settings')[1]['settings'];change(s);status,d=api('settings',{'settings':s,'revision':s['revision'],'request_key':key()});assert status==200,d;return api('settings')[1]['settings']
  base=api('settings')[1]['settings'];selection={'revision':base['revision'],'codes':['oil-change','oil-material','oil-filter','brakes-front-both','brakes-rear-pads'],'quantities':{'oil-material':{'0':'5'}}}
  payload={'plate':'REVIEW001','services':['Oleje a filtry','Brzdy'],'manual_plan':selection,'request_key':key()};s,d=o.api('mechanic_flow_api.php','create',payload);assert s==200,d;j=d['id'];tasks=[t for t in info(j)['tasks'] if t['entry_type']=='work']
  check(len(tasks)==8 and sum(t['kind']=='labor' for t in tasks)==3,'F01 confirmed oil front combination and rear pads create exactly three labor rows plus five parts')
  check(all(t['status']=='planned' and t['unit_price'] is None and t['item_id'] is None for t in tasks) and info(j)['totals']['total']==0,'F01 manual templates create planned unpriced work with no installed material or billing')
  check(next(t for t in tasks if t['description']=='Motorový olej')['quantity']=='5.000','F01 actual chosen oil quantity persists')
  check(o.api('mechanic_flow_api.php','create',payload)[1]['id']==j,'F01 repeated intake with same plan returns original job')
  check(r.sql('SELECT COUNT(*) FROM abc_test.items')=='0' and r.sql('SELECT COUNT(*) FROM abc_test.payments')=='0','F01 confirmed choices create neither stock debit money nor priced invoice items')
  p={'id':j,'revision':info(j)['job']['revision'],'selection':{'revision':base['revision'],'codes':['brakes-front-pads']},'request_key':key()};check(api('manual_plan',p)[0]==409,'F01 front alternative cannot duplicate labor already included in the front combination')
  s,d=create('REVIEW002');assert s==200;other=d['id'];p={'id':other,'revision':info(other)['job']['revision'],'selection':{'revision':base['revision'],'codes':['brakes-front-both','brakes-front-pads']},'request_key':key()};check(api('manual_plan',p)[0]==409 and len([t for t in info(other)['tasks'] if t['entry_type']=='work'])==0,'F01 incompatible pending alternatives fail atomically')
  p['selection']['codes']=['arm-both','diagnostics'];s,d=api('manual_plan',p);check(s==200 and len([t for t in info(other)['tasks'] if t['entry_type']=='work'])==4,'F01 both suspension sides and diagnostics add only their exact configured rows')
  check(api('manual_plan',p)[0]==200,'F01 manual confirmation retry is idempotent')
  for line in [t for t in info(other)['tasks'] if t['entry_type']=='work' and t['kind']=='labor']:assert o.api('mechanic_api.php','quick_task_status',{'id':other,'task_id':line['id'],'revision':line['revision'],'status':'done','request_key':key()})[0]==200
  assert o.api('api.php','set_status',{'id':other,'revision':info(other)['job']['revision'],'status':'done','request_key':key()})[0]==200
  check(api('manual_plan',{'id':other,'revision':info(other)['job']['revision'],'selection':{'revision':base['revision'],'codes':['oil-change']},'request_key':key()})[0]==200 and info(other)['job']['status']=='work','F01 confirming new unfinished plan visibly reopens the same completed unbilled repair')
  s,d=create('DAYONLY01',date='2027-08-02',time='');assert s==200,d;dayjob=d['id']
  check(d['scheduled'] is False and info(dayjob)['job']['work_day']=='2027-08-02' and r.sql('SELECT COUNT(*) FROM abc_test.office_appointments WHERE job_id='+str(dayjob))=='0','F02 future day without hour is stored on same job with no appointment')
  cal=api('calendar',month='2027-08')[1];check(any(x['id']==dayjob for x in cal['day_jobs']) and '2027-08-02' not in cal['days'],'F02 day-only job appears in calendar work list without affecting capacity')
  check(create('REALTIME01',date='2027-08-02',time='10:00',duration=60)[0]==200,'F02 day-only assignment blocks neither mechanic nor real time reservation')
  check(create('DAYONLY02',date='2027-08-02',time='',resource_id=1)[0]==400,'F02 no hidden resource reservation can be attached to day-only intake')
  s,d=create('DAYMOVE01',date='2027-08-03',time='11:00',duration=60);assert s==200;move=d['id'];p={'id':move,'revision':info(move)['job']['revision'],'date':'2027-08-04','time':'','request_key':key()};check(api('appointment',p)[0]==200 and r.sql("SELECT COUNT(*) FROM abc_test.office_appointments WHERE job_id="+str(move)+" AND status='confirmed'")=='0' and info(move)['job']['work_day']=='2027-08-04','F02 removing exact time preserves selected day and cancels former reservation')
  check(api('appointment',{**p,'date':'2027-08-05','request_key':key()})[0]==409,'F02 concurrent day edits retain revision conflict protection')
  # Workshop-owned template edit and stale confirmed choice.
  custom={'code':'custom-inspection','category':'Brzdy','label':'Vlastni kontrola','exclusive_group':'','rows':[{'kind':'labor','description':'Vlastni kontrola podle servisu','quantity':1,'unit':'úkon'}]}
  settings=settings_update(lambda s:s['service_templates'].append(custom));s,d=create('CUSTOM01');assert s==200;customj=d['id'];p={'id':customj,'revision':info(customj)['job']['revision'],'selection':{'revision':base['revision'],'codes':['oil-change']},'request_key':key()};check(api('manual_plan',p)[0]==409,'F01 changed workshop templates reject stale confirmation without silently substituting new data')
  p['selection']={'revision':settings['revision'],'codes':['custom-inspection']};p['request_key']=key();check(api('manual_plan',p)[0]==200 and any(t['description']==custom['rows'][0]['description'] for t in info(customj)['tasks']),'F01 owner-configured template drives actual new job rows')
  # Actual ceník rules, including forbidden base combination kept as old data.
  catalog=[]
  for name,kind,price in [('Kompletni prezuti','labor',250),('Samostatne vyvazeni','labor',100),('Ventilek','part',30)]:
   assert o.form('save_catalog',description=name,category='Pneuservis',kind=kind,unit='ks',unit_price=price,unit_cost=10,active=1)[0]==200;catalog.append(int(r.sql('SELECT MAX(id) FROM abc_test.abc_quick_catalog')))
  def rules(s):
   s['tyres']=[{'operation':op,'vehicle':vehicle,'diameter':16,'balance':True,'runflat':rf,'catalog_id':catalog[1] if op=='balance' else catalog[0],'valve_catalog_id':catalog[2]} for op,vehicle,rf in [('complete','car',False),('balance','car',False),('complete','van',True),('complete','van',False)]]
   s['tyres'].append({'operation':'complete','vehicle':'car','diameter':16,'balance':False,'runflat':False,'catalog_id':catalog[0],'valve_catalog_id':None})
  settings=settings_update(rules)
  def tyre(j,**kw):return api('tyres',{'id':j,'revision':info(j)['job']['revision'],'operation':'complete','vehicle':'car','diameter':16,'count':4,'balance':True,'runflat':False,'request_key':key(),**kw})
  s,d=create('FORBIDDEN01');assert s==200;ty=d['id'];check(tyre(ty,vehicle='van',runflat=True)[0]==409 and not [t for t in info(ty)['tasks'] if t['entry_type']=='work'],'F04 configured van/runflat exclusion is enforced by real server without rows or money')
  settings=settings_update(lambda s:s.update(tyre_van_runflat_exclusive=False));check(tyre(ty,vehicle='van',runflat=True)[0]==200,'F04 owner can explicitly permit combination for that workshop without source edits')
  settings=settings_update(lambda s:s.update(tyre_van_runflat_exclusive=True))
  s,d=create('OVERLAP01');assert s==200;ty=d['id'];check(tyre(ty)[0]==200,'F06 configured complete tyre service with balancing is added once')
  before=r.sql('SELECT COUNT(*) FROM abc_test.items WHERE job_id='+str(ty));s,d=tyre(ty,operation='balance');check(s==409 and d['code']=='tyre_overlap' and r.sql('SELECT COUNT(*) FROM abc_test.items WHERE job_id='+str(ty))==before,'F06 same-wheel standalone balance cannot silently charge included service again')
  check(tyre(ty,operation='balance',wheel_set='Zimni sada v kufru')[0]==200,'F06 explicitly different wheel set remains a legitimate distinct service')
  check(tyre(ty,operation='balance',wheel_set='  NA   VOZIDLE  ')[0]==409,'F06 case or whitespace changes cannot disguise the same wheel set')
  s,mount=create('MOUNT001');assert s==200;mountj=mount['id'];check(tyre(mountj,balance=False)[0]==200 and tyre(mountj,operation='balance')[0]==200,'F06 complete service without included balance permits a truly separate balancing operation')
  check(tyre(ty,operation='balance',repeat_reason='Kontrola po oprave')[0]==400,'F06 repetition requires explicit confirmation as well as a reason')
  check(tyre(ty,operation='balance',repeat_confirmed=True,repeat_reason='Nova oprava po poskozeni kola')[0]==200,'F06 explicitly explained actual repeat is accepted and audited')
  metadata=json.loads(r.sql("SELECT bundle_meta FROM abc_test.abc_quick_tasks WHERE job_id="+str(ty)+" AND description LIKE 'Samostatne%' ORDER BY id DESC LIMIT 1"));check(metadata['repeat_confirmed'] and metadata['repeat_reason']=='Nova oprava po poskozeni kola','F06 repeated work retains its explanation in the same job history')
  # New APIs preserve permissions and the original financial lock.
  pw=secrets.token_hex(12);assert o.form('save_user',name='Bez editace',email='review-read@example.test',password=pw,permissions=['create_jobs'],rights_version=2)[0]==200;c=Client(r.url);assert c.login('review-read@example.test',pw)[0]==200
  s,d=create('NOEDIT01',c);assert s==200;check(c.api('phase_a_api.php','manual_plan',{'id':d['id'],'revision':1,'selection':{'revision':settings['revision'],'codes':['oil-change']},'request_key':key()})[0]==403,'F01 new plan action cannot bypass individual edit permission')
  check(o.request('phase_a_api.php?action=manual_plan',{'id':j},api=True,token=False)[0]==403,'F01 new confirmation still requires CSRF')
  if os.environ.get('ABC_TEST_BROWSER')=='1':
   from review_331_browser import run_browser
   run_browser(r,check,catalog)
  r.weblog.flush();log=(r.tmp/'php.log').read_text();errors=[line for line in log.splitlines() if any(tag in line for tag in ['PHP Warning','PHP Fatal','PHP Parse','PHP Deprecated'])];
  if errors:print('\n'.join(errors))
  check(not errors,'No PHP runtime warnings or errors in F01-F06 acceptance')
  out=ROOT/'tests/evidence/340/regression331';out.mkdir(parents=True,exist_ok=True);(out/('results-wedos.json' if r.prefix else 'results.json')).write_text(json.dumps({'version':'3.4.0-regression331','passed':len(checks),'checks':checks,'browser':os.environ.get('ABC_TEST_BROWSER')=='1','wedos_rewrite':bool(r.prefix)},ensure_ascii=False,indent=2))
 print(json.dumps({'passed':len(checks)}))
if __name__=='__main__':main()
