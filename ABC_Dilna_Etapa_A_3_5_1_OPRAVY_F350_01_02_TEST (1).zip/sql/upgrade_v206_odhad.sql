-- ABC Dílna 2.0.6: samostatné uložené předběžné cenové odhady.
-- Nepřepisuje žádné existující zakázky, položky, faktury ani platby.
CREATE TABLE IF NOT EXISTS abc_job_estimates (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  job_id INT NOT NULL,
  created_by INT NOT NULL,
  lower_total DECIMAL(12,2) NOT NULL DEFAULT 0,
  upper_total DECIMAL(12,2) NOT NULL DEFAULT 0,
  lines_json LONGTEXT NOT NULL,
  note VARCHAR(500) NOT NULL DEFAULT '',
  origin VARCHAR(24) NOT NULL DEFAULT 'manual',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX abc_estimates_job_idx (job_id,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
