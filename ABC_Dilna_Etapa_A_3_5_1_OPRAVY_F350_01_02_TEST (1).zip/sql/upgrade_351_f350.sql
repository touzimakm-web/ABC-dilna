-- Pouze samostatná KOPIE známé klientské databáze 3.5.0, nikoli platformní DB.
-- Doporučené je upgrade.php, které ověří i předchozí schéma a získá zámek.
-- Tento ruční SQL soubor spouštějte jednou; PHP migrace je opakovatelná.
-- DDL v MariaDB/MySQL provádí implicitní COMMIT. Nejprve úplná záloha.
-- Žádné UPDATE provozních řádků, žádné mazání nebo přepočet historických cen.
ALTER TABLE abc_quick_tasks MODIFY quantity DECIMAL(10,3) NULL DEFAULT 1;
ALTER TABLE items MODIFY quantity DECIMAL(10,3) NULL DEFAULT 1;
ALTER TABLE abc_price_history MODIFY quantity DECIMAL(10,3) NULL;
ALTER TABLE abc_quick_tasks ADD CONSTRAINT abc_tasks_hourly_quantity
    CHECK (quantity IS NOT NULL OR (kind='labor' AND unit='hod'));
ALTER TABLE items ADD CONSTRAINT abc_items_hourly_quantity
    CHECK (quantity IS NOT NULL OR (kind='labor' AND unit='hod'));
INSERT IGNORE INTO schema_meta(version) VALUES ('3.5.1-f350');
