-- M02 pro existující TESTOVACÍ databázi konkrétního servisu (ne platformní databázi).
-- Předem vytvořit zálohu. Spustit JEDNOU, před použitím upraveného PHP/JS.
-- Nově zřizované servisy používají upravené sql/schema.sql a migraci nepotřebují.
ALTER TABLE items ADD COLUMN unit VARCHAR(12) NOT NULL DEFAULT 'ks' AFTER quantity;
ALTER TABLE abc_quick_tasks ADD COLUMN unit VARCHAR(12) NOT NULL DEFAULT 'ks' AFTER quantity;
-- Starší pracovní úkony představovaly jednu činnost, nikoliv odpracovanou hodinu.
UPDATE items SET unit='úkon' WHERE kind='labor';
UPDATE abc_quick_tasks SET unit='úkon' WHERE kind='labor';
